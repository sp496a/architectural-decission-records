package com.hp.stratus.pendingassociations.action.associateconsent;

import com.hp.stratus.pendingassociations.exceptions.ActionExecutionException;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.ResourceType;

/** Executor for associating resources. */
public interface AssociateConsentResourceExecutor {

  /**
   * Gets the device resource type handled by this executor.
   *
   * @return The resource type supported by this executor.
   */
  ResourceType getDeviceResourceType();

  /**
   * Executes the executor.
   *
   * @param userId The user ID to associate.
   * @param deviceId The device ID to associate.
   * @param association The association.
   * @param actionIndex The action index of the association.
   * @throws ActionExecutionException When action execution fails.
   */
  void execute(String userId, String deviceId, Association association, int actionIndex)
      throws ActionExecutionException;
}
