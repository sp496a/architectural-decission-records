package com.hp.stratus.pendingassociations.repository;

import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.ConditionComparator;
import com.hp.stratus.pendingassociations.model.aggregation.AggregatePointerResult;
import com.hp.stratus.pendingassociations.model.aggregation.ConditionValueField;
import java.util.List;

/** Repository for actions related to criteria. */
public interface CriteriaRepository {

  /**
   * Executes an aggregate query, which extracts the relevant JSON pointers for the given event in
   * the DB. This allows us to extract those values from the event, and then perform efficient
   * searches to find matching associations.
   *
   * @param resource The event resource.
   * @param type The event type.
   * @return List of unique pointers/comparators to assist with future queries.
   */
  List<AggregatePointerResult> findUniquePendingEventPointers(
      ExternalEventResource resource, ExternalEventType type);

  /**
   * Executes an aggregate query to retrieve a list of Associations in Pending state with existing
   * 'criteria.conditions' field. A temporary solution to support Chromebooks.
   *
   * @param resource The event resource.
   * @param type The event type.
   * @return List of unique pointers/comparators to assist with future queries.
   */
  List<Association> findAssociationsWithConditions(ExternalEventResource resource, ExternalEventType type);

  /**
   * Resolves associations that have a criteria with the specified value.
   *
   * @param value The value to use for comparison.
   * @param compareValue The value to compare against.
   * @param comparator The comparator to use.
   * @param resolutionObject The object to resolve the criteria with.
   * @return The number of updated associations.
   */
  long resolvePendingCriteria(
      String value,
      ConditionValueField compareValue,
      ConditionComparator comparator,
      Object resolutionObject);

  /**
   * Finds all associations in a pending state with completed criteria.
   *
   * @return The list of associations.
   */
  List<Association> getPendingAssociationsWithCompletedCriteria();

  /**
   * Saves the association object to DB
   *
   * @param association Association to save
   */
  void save(Association association);
}
