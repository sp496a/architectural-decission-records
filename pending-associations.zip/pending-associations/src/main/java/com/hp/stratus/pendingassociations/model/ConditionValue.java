package com.hp.stratus.pendingassociations.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/** The value for a condition */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ConditionValue {
  private ConditionValueType type;
  private String value;
}
