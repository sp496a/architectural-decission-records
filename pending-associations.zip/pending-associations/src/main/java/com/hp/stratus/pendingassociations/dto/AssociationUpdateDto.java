package com.hp.stratus.pendingassociations.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hp.stratus.pendingassociations.validation.JsonFieldValidation;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

import java.util.List;
import java.util.Map;

@Data
@Validated
public class AssociationUpdateDto {
  @JsonProperty("state")
  private State state;

  @JsonProperty("tenantId")
  @NotBlank(groups = {PostAssociation.class, PutAssociation.class})
  private String tenantId;

  @JsonProperty("actions")
  @Valid
  @NotNull(groups = {PostAssociation.class, PutAssociation.class})
  private List<AssociationUpdateActionsDto> actions;

  @JsonProperty("criteria")
  @Valid
  @NotNull(groups = {PostAssociation.class, PutAssociation.class})
  private List<CriteriaUpdateDto> criteria;

  @JsonProperty("metadata")
  @Valid
  @JsonFieldValidation(
      groups = {PostAssociation.class, PutAssociation.class, PatchAssociation.class})
  private Map<String, Object> metadata;

  public interface PostAssociation {}

  public interface PatchAssociation {}

  public interface PutAssociation {}
}
