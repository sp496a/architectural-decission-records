package com.hp.stratus.pendingassociations.model.cache;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/** Defines a simple holder class for association ID and action index. */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class PrinterAssociationActionInformation {

  @JsonProperty("associationId")
  private UUID associationId;

  @JsonProperty("actionIndex")
  private int actionIndex;
}
