package com.hp.stratus.pendingassociations.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

/** DTO for conditions. */
@Validated
@Data
public class ConditionsDto {

  @JsonProperty("operator")
  @NotNull
  private ConditionsOperatorDto operator;

  @JsonProperty("values")
  @NotNull
  private ConditionDto[] values;
}
