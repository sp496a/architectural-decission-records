package com.hp.stratus.pendingassociations.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

/** Represents a common api error response */
@Data
@AllArgsConstructor
public class ApiError {
  private String code;
  private String message;
}
