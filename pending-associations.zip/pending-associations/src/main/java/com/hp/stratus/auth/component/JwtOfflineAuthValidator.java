package com.hp.stratus.auth.component;

import com.hp.stratus.controller.TokenValidatorController;
import com.hp.stratus.response.TokenResponse;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class JwtOfflineAuthValidator implements JwtAuthValidator {

  private final TokenValidatorController tokenValidatorController;

  /**
   * Validate token contents
   *
   * @param token : jwt token applied for authentication check
   * @param permission : permission scope list used to check if the token contains any one of the
   *     scope
   * @return true if validated. Otherwise, throws Exception
   */
  @Override
  public boolean validate(@NotNull String token, List<String> permission) {
    try {
      TokenResponse tokenResponse = tokenValidatorController.validateToken(token, permission);

      log.debug("auth pass: {}, {}, {} ", permission, token, tokenResponse.toString());
      return true;

    } catch (Exception exc) {
      log.debug("auth failed with exception: {}, {}", permission, exc.getMessage());
      throw new org.springframework.security.access.AccessDeniedException(
          exc.getMessage(),
          exc); // AccessDeniedException will be handled by BoxSecurityFilterExceptionHandler
    }
  }
}
