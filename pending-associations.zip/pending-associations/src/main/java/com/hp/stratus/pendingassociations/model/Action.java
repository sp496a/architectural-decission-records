package com.hp.stratus.pendingassociations.model;

import lombok.Data;

import java.time.LocalDateTime;

/** Action to take when associating/disassociating. */
@Data
public class Action {
  private Operation operation;
  private Resource resource;
  private Resources resources;
  private LocalDateTime completedAt;
  private Object completedWith;
}
