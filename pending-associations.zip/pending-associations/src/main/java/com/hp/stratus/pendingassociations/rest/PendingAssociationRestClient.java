/*
 * Copyright (c) 2022, HP Development Company, L.P. All rights reserved. This software contains
 * confidential and proprietary information of HP. The user of this software agrees not to disclose,
 * disseminate or copy such Confidential Information and shall use the software only in accordance
 * with the terms of the license agreement the user entered into with HP.
 */

package com.hp.stratus.pendingassociations.rest;

import com.hp.stratus.http.client.config.RestTemplateFactory;
import com.hp.stratus.http.client.utils.HttpClient;
import com.hp.stratus.pendingassociations.dto.HealthResponse;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponentsBuilder;

/** Pending Association Svc client for unified access to stratus collection API */
@Slf4j
public class PendingAssociationRestClient {

  // TODO: Temporary class for example purpose only and shall be removed when actual api client is
  // available for use.

  // pending association
  public static final String PENDING_ASSOCIATION_CORE_URL = "/pending-associations";
  public static final String PENDING_ASSOCIATION_SVC_ENDPOINT =
      PENDING_ASSOCIATION_CORE_URL + "/associations";
  public static final String LOG_PENDING_ASSOCIATION_SVC_CLIENT = "pendingAssociationsClient: ";

  private final String stratusBaseUrl;
  private final HttpClient httpClient;

  /**
   * Pending Association Svc Rest Client constructor {@link PendingAssociationRestClient}
   *
   * @param stratusBaseUrl Stratus base URL to be used in requests
   * @param environment {@link Environment} instance. Used to set proxy settings. No proxy is
   *     applied if null.
   */
  public PendingAssociationRestClient(@NonNull String stratusBaseUrl, Environment environment) {
    log.debug(LOG_PENDING_ASSOCIATION_SVC_CLIENT + "ping instance : URL : {}", stratusBaseUrl);
    this.stratusBaseUrl = stratusBaseUrl;
    this.httpClient = new HttpClient(RestTemplateFactory.initRestTemplate(environment));
  }

  /**
   * Ping api rest endpoint
   *
   * @param token The token to use
   * @return The response
   */
  public HealthResponse ping(String token) {
    var apiUrl =
        UriComponentsBuilder.fromUriString(stratusBaseUrl).path("/ping").build().toString();
    ResponseEntity<HealthResponse> response;
    try {
      response = httpClient.get(apiUrl, token, new ParameterizedTypeReference<>() {});
      if (response.getStatusCode() != HttpStatus.OK) {
        log.warn(
            LOG_PENDING_ASSOCIATION_SVC_CLIENT
                + "ping pending association svc : response code : {} : apiUrl {}",
            response.getStatusCode(),
            apiUrl);
        return null;
      }
    } catch (Exception e) {
      log.warn(
          LOG_PENDING_ASSOCIATION_SVC_CLIENT
              + "ping pending association svc : error : apiUrl {} : exception {}",
          apiUrl,
          e.getMessage());
      return null;
    }

    log.debug(LOG_PENDING_ASSOCIATION_SVC_CLIENT + "ping pending association svc : end");
    return response.getBody();
  }
}
