package com.hp.stratus.pendingassociations.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Arrays;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

/** The type of condition value */
@AllArgsConstructor
public enum ConditionValueType {
  @JsonProperty("pointer")
  POINTER("pointer"),
  @JsonProperty("string")
  STRING("string"),
  @JsonProperty("path")
  PATH("path");

  @Getter private final String value;

  @JsonCreator
  public static ConditionValueType fromValue(String text) {
    return Arrays.stream(values())
        .filter(val -> StringUtils.equalsIgnoreCase(val.getValue(), text))
        .findAny()
        .orElse(null);
  }
}
