package com.hp.stratus.pendingassociations.model.converter;

import com.hp.stratus.pendingassociations.model.Operation;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;

@ReadingConverter
public class OperationReadConverter implements Converter<String, Operation> {

  @Override
  public Operation convert(String source) {
    return Operation.fromValue(source);
  }
}
