package com.hp.stratus.pendingassociations.dto.event.internal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/** Defines a basic internal event. */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class InternalEvent {

  /** Defines the app ID of an internal event. */
  public static final String INTERNAL_EVENT_APP_ID = "pending-associations";

  @JsonProperty("type")
  private InternalEventType type;

  @JsonProperty("association")
  private UUID association;
}
