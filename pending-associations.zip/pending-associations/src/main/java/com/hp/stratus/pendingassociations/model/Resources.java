package com.hp.stratus.pendingassociations.model;

import lombok.Data;

import java.util.Map;

/** Multiple resources that are involved in operation. */
@Data
public class Resources {
  private Resource user;
  private Resource device;
  private Map<String, ResourceId> untypedResources;
}
