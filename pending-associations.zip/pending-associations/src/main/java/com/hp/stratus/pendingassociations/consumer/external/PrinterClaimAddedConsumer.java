package com.hp.stratus.pendingassociations.consumer.external;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.action.associate.AssociatePrinterExecutor;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventAttribute;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventEnvelope;
import com.hp.stratus.pendingassociations.service.EventService;
import com.hp.stratus.pendingassociations.utils.EventUtils;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.stereotype.Component;

import java.util.Map;

/** A basic abstract consumer for events, indicating the type of events it handles. */
@Component
@Slf4j
@RequiredArgsConstructor
public class PrinterClaimAddedConsumer implements ExternalEventConsumer {

  /** The device ID key name. */
  private static final String DEVICE_ID_ATTRIBUTE = "deviceId";

  /** Service for evaluating criteria. */
  private final AssociatePrinterExecutor associatePrinterExecutor;

  /** Service for subscribing to events. */
  private final EventService eventService;

  /** JSON Mapper. */
  private final ObjectMapper objectMapper;

  /** Indicates the resource name this consumer handles. */
  @Override
  public ExternalEventResource eventResource() {
    return ExternalEventResource.PRINTER_CLAIM;
  }

  /** Indicates the event types this consumer handles. */
  @Override
  public ExternalEventType eventType() {
    return ExternalEventType.ADDED;
  }

  /** Subscribe automatically to the required resource. */
  @PostConstruct
  public void subscribeToResource() {
    eventService.subscribeToResource(eventResource());
  }

  /**
   * Handles the events.
   *
   * @param event The event to handle.
   */
  @Override
  public void handleEvent(StratusEventEnvelope event) {

    // Extract the event object attribute
    StratusEventAttribute eventObject = EventUtils.getEventObjectAttribute(event);
    if (eventObject == null) {
      log.warn("No event object found in printer claim event, ignoring...");
      throw new AmqpRejectAndDontRequeueException("No event object found in printer claim event");
    }

    // Parse the resolution object into a map
    Map<String, Object> resolutionObject = EventUtils.getEventDetailMap(objectMapper, eventObject);
    if (resolutionObject == null) {
      log.warn("Failed to read printer claim event details into a map, ignoring...");
      throw new AmqpRejectAndDontRequeueException(
          "Failed to read printer claim event details into a map");
    }

    // Extract the device ID attribute
    StratusEventAttribute deviceIdAttribute =
        EventUtils.getEventAttribute(event, DEVICE_ID_ATTRIBUTE);
    if (deviceIdAttribute == null || deviceIdAttribute.getStringValue() == null) {
      log.warn("Failed to extract device ID from printer claim event, ignoring...");
      throw new AmqpRejectAndDontRequeueException(
          "Failed to extract device ID from printer claim event");
    }

    // Complete the claim action
    associatePrinterExecutor.completeClaim(deviceIdAttribute.getStringValue(), resolutionObject);
  }
}
