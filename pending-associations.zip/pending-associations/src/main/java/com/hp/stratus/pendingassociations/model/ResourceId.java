package com.hp.stratus.pendingassociations.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Defines a resource ID. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ResourceId {
  private ResourceIdType type;
  private String value;
}
