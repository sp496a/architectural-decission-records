package com.hp.stratus.pendingassociations.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;

/** The type of resource ID */
@AllArgsConstructor
public enum ResourceIdType {
  @JsonProperty("pointer")
  POINTER("pointer"),
  @JsonProperty("string")
  STRING("string"),
  @JsonProperty("path")
  PATH("path");

  @Getter private final String value;

  public static ResourceIdType fromValue(String text) {
    for (ResourceIdType r : ResourceIdType.values()) {
      if (r.getValue().equals(text)) {
        return r;
      }
    }
    return null;
  }
}
