package com.hp.stratus.pendingassociations.model.converter;

import com.hp.stratus.pendingassociations.model.CriteriaType;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;

@ReadingConverter
public class CriteriaTypeReadConverter implements Converter<String, CriteriaType> {

  @Override
  public CriteriaType convert(String source) {
    return CriteriaType.fromValue(source);
  }
}
