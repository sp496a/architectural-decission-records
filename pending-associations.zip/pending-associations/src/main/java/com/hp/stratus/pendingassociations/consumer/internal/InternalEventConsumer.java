package com.hp.stratus.pendingassociations.consumer.internal;

import com.hp.stratus.pendingassociations.dto.event.internal.InternalEvent;
import com.hp.stratus.pendingassociations.dto.event.internal.InternalEventType;

/** Defines an event consumer for internal events. */
public interface InternalEventConsumer {

  /** Indicates the event type the consumer supports. */
  InternalEventType eventType();

  /** Handles the event. */
  void handleEvent(InternalEvent event);
}
