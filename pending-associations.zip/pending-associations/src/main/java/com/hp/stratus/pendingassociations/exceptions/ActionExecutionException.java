package com.hp.stratus.pendingassociations.exceptions;

/** Exception that is thrown when action execution fails */
public class ActionExecutionException extends RuntimeException {

  private final boolean retryable;

  public ActionExecutionException(boolean retryable) {
    super();
    this.retryable = retryable;
  }

  public ActionExecutionException(boolean retryable, String message) {
    super(message);
    this.retryable = retryable;
  }

  public ActionExecutionException(boolean retryable, String message, Throwable cause) {
    super(message, cause);
    this.retryable = retryable;
  }

  public boolean isRetryable() {
    return retryable;
  }
}
