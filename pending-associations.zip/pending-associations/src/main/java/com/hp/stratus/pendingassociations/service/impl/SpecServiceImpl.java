package com.hp.stratus.pendingassociations.service.impl;

import com.hp.stratus.pendingassociations.Application;
import com.hp.stratus.pendingassociations.service.SpecService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

/** Simple specification fetcher for the service. */
@Slf4j
@Service
public class SpecServiceImpl implements SpecService {

  /**
   * Retrieves the specification for the service.
   *
   * @return The JSON representation of the spec.
   * @throws IOException If the file can't be read.
   */
  @Override
  @Cacheable("swagger")
  public String getSpec() throws IOException {
    var resource = new ClassPathResource("/" + "swagger.json", Application.class);
    var inputStream = resource.getInputStream();
    return new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
  }
}
