package com.hp.stratus.pendingassociations.consumer.external;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventEnvelope;
import com.hp.stratus.pendingassociations.service.CriteriaService;
import com.hp.stratus.pendingassociations.service.EventService;
import com.hp.stratus.pendingassociations.utils.EventUtils;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.stereotype.Component;

import javax.json.JsonStructure;
import java.util.Map;

/** Consumer for fulfillment trade order update events */
@Component
@Slf4j
@RequiredArgsConstructor
public class FulfillmentTradeOrderUpdatedConsumer implements ExternalEventConsumer {

  /** JSON Mapper. */
  private final ObjectMapper objectMapper;

  private final CriteriaService criteriaService;

  /** Service for subscribing to events. */
  private final EventService eventService;

  /** Indicates the resource name this consumer handles. */
  @Override
  public ExternalEventResource eventResource() {
    return ExternalEventResource.FULFILLMENT_TRADE_ORDER;
  }

  /** Indicates the event types this consumer handles. */
  @Override
  public ExternalEventType eventType() {
    return ExternalEventType.UPDATED;
  }

  /** Subscribe automatically to the required resource. */
  @PostConstruct
  public void subscribeToResource() {
    eventService.subscribeToResource(eventResource());
  }

  /** Handles the events. */
  @Override
  public void handleEvent(StratusEventEnvelope event) {

    // Convert the map of attributes to a JSON map
    Map<String, Object> eventMap = EventUtils.getEventAttributeMap(objectMapper, event);
    if (eventMap.isEmpty()) {
      log.warn("No event attributes found in fulfillment event, ignoring...");
      throw new AmqpRejectAndDontRequeueException("No event attributes found in fulfillment event");
    }

    // Create a JSON structure from the map
    JsonStructure eventStructure = EventUtils.convertToJsonStructure(objectMapper, eventMap);
    if (eventStructure == null) {
      log.warn("Unable to convert event attributes to a JSON structure, ignoring...");
      throw new AmqpRejectAndDontRequeueException(
          "Unable to convert event attributes to a JSON structure");
    }

    criteriaService.resolveConditionCriteriaHack(
        ExternalEventResource.FULFILLMENT_TRADE_ORDER,
        ExternalEventType.UPDATED,
        eventMap,
        eventStructure);
  }
}
