package com.hp.stratus.pendingassociations.dto;

import lombok.Getter;
import lombok.Setter;

/** Represents the create association api response */
@Getter
@Setter
public class CreateAssociationResponse extends AssociationDto {}
