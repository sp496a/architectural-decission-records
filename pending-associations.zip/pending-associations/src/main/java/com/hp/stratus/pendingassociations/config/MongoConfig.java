package com.hp.stratus.pendingassociations.config;

import com.google.common.annotations.VisibleForTesting;
import com.hp.stratus.pendingassociations.model.converter.*;
import com.mongodb.*;
import com.mongodb.MongoClientSettings.Builder;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.NotImplementedException;
import org.bson.UuidRepresentation;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.config.AbstractMongoClientConfiguration;
import org.springframework.data.mongodb.core.convert.MongoCustomConversions;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.auth.credentials.AwsSessionCredentials;

import java.util.List;
import java.util.function.Supplier;

/** Configures Mongo DB settings. */
@Component
@RequiredArgsConstructor
public class MongoConfig extends AbstractMongoClientConfiguration {

  /** Autowired credential supplier for AWS credentials. */
  private final Supplier<AwsSessionCredentials> awsCredentialSupplier;

  /** Specifies the host for the DB */
  @Value("${mongodb.host}")
  private final String host;

  /** Specifies the database name */
  @Value("${mongodb.database}")
  private final String database;

  /** Specifies the replica set to use. Not required for deployments. */
  @Value("${mongodb.replicaset}")
  private final String replicaSet;

  /** Specifies the auth mechanism to use. Not required for local development. */
  @Value("${mongodb.auth.mechanism}")
  private final String authMechanism;

  /**
   * Constructs the mongo DB client.
   *
   * @return The mongo client to use for connections.
   */
  @Override
  @NotNull
  public MongoClient mongoClient() {
    return MongoClients.create(buildMongoSettings());
  }

  /**
   * Gets the database name.
   *
   * @return The DB name.
   */
  @Override
  @NotNull
  protected String getDatabaseName() {
    return database;
  }

  /**
   * Configure mongo conversion settings.
   *
   * @param adapter The mongo conversion adapter.
   */
  @Override
  protected void configureConverters(
      MongoCustomConversions.MongoConverterConfigurationAdapter adapter) {
    adapter.registerConverters(
        List.of(
            new ConditionComparatorReadConverter(),
            new ConditionComparatorWriteConverter(),
            new ConditionsOperatorReadConverter(),
            new ConditionsOperatorWriteConverter(),
            new ConditionValueTypeReadConverter(),
            new ConditionValueTypeWriteConverter(),
            new CriteriaStateReadConverter(),
            new CriteriaStateWriteConverter(),
            new CriteriaTypeReadConverter(),
            new CriteriaTypeWriteConverter(),
            new OperationReadConverter(),
            new OperationWriteConverter(),
            new ResourceIdTypeReadConverter(),
            new ResourceIdTypeWriteConverter(),
            new ResourceTypeReadConverter(),
            new ResourceTypeWriteConverter(),
            new StateReadConverter(),
            new StateWriteConverter()));
  }

  /**
   * Constructs the mongo settings object.
   *
   * @return The mongo settings.
   */
  @VisibleForTesting
  protected MongoClientSettings buildMongoSettings() {

    // Prepare the connection string
    ConnectionString connectionString = new ConnectionString(host);

    // Set basic settings
    Builder builder = MongoClientSettings.builder().applyConnectionString(connectionString);
    builder.uuidRepresentation(UuidRepresentation.JAVA_LEGACY);

    // Set the replica set if present
    applyReplicaSet(builder);

    // Set the auth mechanism
    applyAuthMechanism(builder);

    return builder.build();
  }

  /**
   * Applies replica set configuration to the supplied builder.
   *
   * @param builder The builder.
   */
  private void applyReplicaSet(Builder builder) {

    // If no replica set configuration was supplied, do nothing
    if (replicaSet == null) {
      return;
    }

    // Apply the desired replica set configuration
    builder.applyToClusterSettings(b -> b.requiredReplicaSetName(replicaSet));
  }

  /**
   * Applies auth mechanism configuration to the supplied builder.
   *
   * @param builder The builder.
   */
  private void applyAuthMechanism(Builder builder) {

    // If no auth mechanism was supplied, do nothing
    if (authMechanism == null) {
      return;
    }

    // Switch on available auth mechanisms
    switch (AuthenticationMechanism.fromMechanismName(authMechanism)) {
      case MONGODB_AWS:
        applyAwsAuthMechanism(builder);
        break;

      case GSSAPI:
      case MONGODB_X509:
      case PLAIN:
      case SCRAM_SHA_1:
      case SCRAM_SHA_256:
      default:
        throw new NotImplementedException("Unsupported authMechanism: " + authMechanism);
    }
  }

  /**
   * Applies the AWS auth mechanism to the supplied builder.
   *
   * @param builder The builder.
   */
  private void applyAwsAuthMechanism(Builder builder) {
    builder.credential(
        MongoCredential.createAwsCredential(null, null)
            .withMechanismProperty(
                MongoCredential.AWS_CREDENTIAL_PROVIDER_KEY,
                (Supplier<AwsCredential>)
                    () -> {
                      AwsSessionCredentials sessionCredentials = awsCredentialSupplier.get();
                      return new AwsCredential(
                          sessionCredentials.accessKeyId(),
                          sessionCredentials.secretAccessKey(),
                          sessionCredentials.sessionToken());
                    }));
  }
}
