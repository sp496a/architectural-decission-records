package com.hp.stratus.pendingassociations.dto.event.external;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Getter;

/** Defines the types of stratus events. */
@AllArgsConstructor
public enum ExternalEventType {
  ADDED("ADDED"),
  DELETED("DELETED"),
  UPDATED("UPDATED");

  @Getter @JsonValue private final String value;

  @JsonCreator
  public static ExternalEventType fromValue(String text) {
    for (ExternalEventType type : ExternalEventType.values()) {
      if (String.valueOf(type.value).equals(text)) {
        return type;
      }
    }
    return null;
  }
}
