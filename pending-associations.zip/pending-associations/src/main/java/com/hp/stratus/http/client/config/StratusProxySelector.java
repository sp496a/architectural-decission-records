/*
 * Copyright (c) 2021, HP Development Company, L.P. All rights reserved. This software contains
 * confidential and proprietary information of HP. The user of this software agrees not to disclose,
 * disseminate or copy such Confidential Information and shall use the software only in accordance
 * with the terms of the license agreement the user entered into with HP.
 */

package com.hp.stratus.http.client.config;

import lombok.NonNull;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.env.Environment;

import java.io.IOException;
import java.net.*;
import java.util.*;

import static com.hp.stratus.http.client.utils.HttpConstants.*;

public class StratusProxySelector extends ProxySelector {
  private final List<Proxy> noProxyList = new ArrayList<>();
  private final List<Proxy> proxyList = new ArrayList<>();
  private final Set<String> supportedProtocols = new HashSet<>();
  private final Set<String> nonProxyHosts = new HashSet<>();

  private final ProxySelector defaultSelector;
  private final Environment environment;

  public StratusProxySelector(Environment environment) {
    this.defaultSelector = ProxySelector.getDefault();
    this.environment = environment;

    noProxyList.add(Proxy.NO_PROXY);
    populateProxyList();
    populateNonProxyHosts();
  }

  @Override
  public List<Proxy> select(@NonNull URI uri) {
    if (CollectionUtils.isNotEmpty(nonProxyHosts)) {
      for (String nph : nonProxyHosts) {
        if (uri.getHost().toLowerCase(Locale.ROOT).matches(nph)) {
          return noProxyList;
        }
      }
    }

    if (supportedProtocols.contains(uri.getScheme())) {
      return proxyList;
    }

    if (defaultSelector != null) {
      return defaultSelector.select(uri);
    }
    return noProxyList;
  }

  @Override
  public void connectFailed(URI uri, SocketAddress sa, IOException ioe) {
    // Nothing to do
  }

  private void populateNonProxyHosts() {
    var nonProxyHostString = environment.getProperty(HTTP_NON_PROXY_KEY);
    if (StringUtils.isNotEmpty(nonProxyHostString)) {
      nonProxyHosts.addAll(Arrays.asList(nonProxyHostString.split("\\|")));
    }
  }

  private void populateProxyList() {
    var httpProxy = createProxy(HTTP_PROXY_HOST_KEY, HTTP_PROXY_PORT_KEY, HTTP_PROXY_PORT_DEFAULT);
    if (httpProxy != null) {
      proxyList.add(httpProxy);
      supportedProtocols.add(URL_SCHEME_HTTP);
    }
    var httpsProxy =
        createProxy(HTTPS_PROXY_HOST_KEY, HTTPS_PROXY_PORT_KEY, HTTPS_PROXY_PORT_DEFAULT);
    if (httpsProxy != null) {
      proxyList.add(httpsProxy);
      supportedProtocols.add(URL_SCHEME_HTTPS);
    }
  }

  private Proxy createProxy(String proxyHostKey, String httpPortKey, int defaultPort) {
    String host = environment.getProperty(proxyHostKey);
    if (StringUtils.isEmpty(host)) {
      return null;
    }
    String port = environment.getProperty(httpPortKey, String.valueOf(defaultPort));
    var proxyPort = Integer.parseInt(port);
    return new Proxy(Proxy.Type.HTTP, new InetSocketAddress(host, proxyPort));
  }
}
