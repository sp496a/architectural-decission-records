package com.hp.stratus.pendingassociations.dto.event.external;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Getter;

/** Defines available fully qualified resource names. */
@AllArgsConstructor
public enum ExternalEventResource {
  PRINTER_REGISTRATION("com.hp.stratus.iot.device.registration"),
  PRINTER_CLAIM("com.hp.stratus.iot.claim"),
  PC_REGISTRATION("com.hp.onecloud.iot.registration"),
  PC_CLAIM("com.hp.onecloud.iot.claim"),
  FULFILLMENT_TRADE_ORDER("com.hp.stratus.fulfillment.tradeorder"),
  PENDING_ASSOCIATION("com.hp.stratus.pendingassociation");

  @Getter @JsonValue private final String value;

  @JsonCreator
  public static ExternalEventResource fromValue(String text) {
    for (ExternalEventResource resource : ExternalEventResource.values()) {
      if (String.valueOf(resource.value).equals(text)) {
        return resource;
      }
    }
    return null;
  }
}
