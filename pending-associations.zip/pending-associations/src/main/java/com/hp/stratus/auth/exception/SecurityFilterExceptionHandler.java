package com.hp.stratus.auth.exception;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class SecurityFilterExceptionHandler
    implements AuthenticationEntryPoint, AccessDeniedHandler {

  private ObjectMapper mapper = new ObjectMapper();

  @Override
  public void commence(
      HttpServletRequest request,
      HttpServletResponse response,
      AuthenticationException authException)
      throws IOException, ServletException {
    filterExceptionHandler(request, response, authException);
  }

  @Override
  public void handle(
      HttpServletRequest request,
      HttpServletResponse response,
      AccessDeniedException accessDeniedException)
      throws IOException, ServletException {
    filterExceptionHandler(request, response, accessDeniedException);
  }

  private void filterExceptionHandler(
      HttpServletRequest request, HttpServletResponse response, Exception exception)
      throws IOException, ServletException {
    log.debug("Catch exception from security filter, {}", exception.getMessage());
    String exMessage = exception.getMessage();

    AuthErrorResponse errorResponse;

    List<AuthErrorMessage> errMessageList = new ArrayList<>();
    if (exception instanceof AuthenticationException) {
      if (exception instanceof OAuth2AuthenticationException) {
        OAuth2Error error = ((OAuth2AuthenticationException) exception).getError();
        if (StringUtils.isNotBlank(error.getDescription())) {
          exMessage = error.getDescription();
        }
      }
      errorResponse = createAuthErrorResponse(ErrorCodeAndMessage.UNAUTHORIZED, exMessage);
    } else { // if exception instanceof AccessDeniedException
      Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

      if (authentication != null && !authentication.isAuthenticated()) {
        errorResponse = createAuthErrorResponse(ErrorCodeAndMessage.UNAUTHORIZED, exMessage);
      } else {
        errorResponse = createAuthErrorResponse(ErrorCodeAndMessage.NOT_ALLOWED_ACCESS, exMessage);
      }
    }

    respondToRequest(response, errorResponse);
  }

  private void respondToRequest(HttpServletResponse response, AuthErrorResponse errorResponse)
      throws IOException {
    response.setStatus(errorResponse.getHttpStatusCode());
    response.setContentType(MediaType.APPLICATION_JSON_VALUE);

    String responseString = "";
    try {
      responseString = mapper.writeValueAsString(errorResponse);
    } catch (JsonProcessingException e) {
      log.info("Cannot convert error object to JSON string:{}", errorResponse);
    } finally {
      response.getWriter().write(responseString);
      response.getWriter().flush();
      response.getWriter().close();
    }
  }

  @NotNull
  private AuthErrorResponse createAuthErrorResponse(
      ErrorCodeAndMessage errorCodeAndMessage, String exMessage) {
    List<AuthErrorMessage> errMessageList = new ArrayList<>();
    AuthErrorResponse errorResponse;
    errMessageList.add(new AuthErrorMessage(errorCodeAndMessage.getMessageCode(), exMessage));
    errorResponse =
        new AuthErrorResponse(
            AuthErrorResponse.VERSION, errorCodeAndMessage.getHttpStatusCode(), errMessageList);
    return errorResponse;
  }
}
