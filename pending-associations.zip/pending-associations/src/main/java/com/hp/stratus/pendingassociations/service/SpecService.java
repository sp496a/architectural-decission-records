package com.hp.stratus.pendingassociations.service;

import java.io.IOException;

/** A simple service for getting API specifications. */
public interface SpecService {

  /**
   * Retrieves the specification for the service.
   *
   * @return The JSON representation of the spec.
   * @throws IOException If the file can't be read.
   */
  String getSpec() throws IOException;
}
