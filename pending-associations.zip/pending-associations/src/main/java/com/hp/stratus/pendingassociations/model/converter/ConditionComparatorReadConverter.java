package com.hp.stratus.pendingassociations.model.converter;

import com.hp.stratus.pendingassociations.model.ConditionComparator;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;

@ReadingConverter
public class ConditionComparatorReadConverter implements Converter<String, ConditionComparator> {

  @Override
  public ConditionComparator convert(String source) {
    return ConditionComparator.fromValue(source);
  }
}
