package com.hp.stratus.pendingassociations.exceptions;

/** Basic exception that is thrown when a resource cannot be resolved. */
public class ResourceResolutionException extends RuntimeException {

  public ResourceResolutionException() {
    super();
  }

  public ResourceResolutionException(String message) {
    super(message);
  }

  public ResourceResolutionException(String message, Throwable cause) {
    super(message, cause);
  }
}
