package com.hp.stratus.pendingassociations;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication(scanBasePackages = {"com.hp.stratus"})
@EnableCaching
public class Application {

  public static final String APP_EXTERNAL_PROPERTIES_CONFIG =
      "spring.config.location=classpath:/"
          + ",classpath:config/application.properties"
          + ",classpath:logging.yml";

  public static void main(String[] args) {
    new SpringApplicationBuilder(Application.class)
        .properties(APP_EXTERNAL_PROPERTIES_CONFIG)
        .run(args);
  }
}
