package com.hp.stratus.pendingassociations.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;

/** The type of criteria */
@AllArgsConstructor
public enum CriteriaType {
  @JsonProperty("eventReceived")
  EVENT_RECEIVED("eventReceived");

  @Getter private final String value;

  public static CriteriaType fromValue(String text) {
    for (CriteriaType c : CriteriaType.values()) {
      if (c.getValue().equals(text)) {
        return c;
      }
    }
    return null;
  }
}
