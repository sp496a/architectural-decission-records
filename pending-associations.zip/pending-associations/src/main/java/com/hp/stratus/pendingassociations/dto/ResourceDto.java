package com.hp.stratus.pendingassociations.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

/** The resource to apply the action to */
@Data
@Validated
public class ResourceDto {

  @JsonProperty("type")
  private ResourceType type;

  @JsonProperty("serial")
  private ResourceIdDto serial;

  @JsonProperty("model")
  private ResourceIdDto model;

  @JsonProperty("id")
  private ResourceIdDto id;
}
