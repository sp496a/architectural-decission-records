package com.hp.stratus.pendingassociations.model.converter;

import com.hp.stratus.pendingassociations.model.State;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.WritingConverter;

@WritingConverter
public class StateWriteConverter implements Converter<State, String> {

  @Override
  public String convert(State source) {
    return source.getValue();
  }
}
