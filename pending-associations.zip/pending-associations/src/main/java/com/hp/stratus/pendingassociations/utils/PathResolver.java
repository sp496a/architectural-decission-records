package com.hp.stratus.pendingassociations.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import com.jayway.jsonpath.spi.json.JacksonJsonProvider;
import com.jayway.jsonpath.spi.json.JsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;
import com.jayway.jsonpath.spi.mapper.MappingProvider;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.json.JsonStructure;
import java.util.List;
import java.util.Set;

/** Simple utility class for dealing with json paths. */
@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class PathResolver {

  private final ObjectMapper objectMapper;

  /** Prepares the json path library for use. */
  @PostConstruct
  public void setup() {
    Configuration.setDefaults(
        new Configuration.Defaults() {
          @Override
          public JsonProvider jsonProvider() {
            return new JacksonJsonProvider(objectMapper);
          }

          @Override
          public MappingProvider mappingProvider() {
            return new JacksonMappingProvider(objectMapper);
          }

          @Override
          public Set<Option> options() {
            // Ensure we always return a list when resolving paths, even if the path cannot be
            // resolved.
            return Set.of(Option.ALWAYS_RETURN_LIST, Option.SUPPRESS_EXCEPTIONS);
          }
        });
  }

  /**
   * Resolves the given path in the given json structure.
   *
   * @param path The path to resolve.
   * @param json The json structure to resolve the path in.
   * @return The resolved values.
   */
  public List<String> resolvePath(String path, JsonStructure json) {

    // TODO: stringifying this structure isn't ideal from a performance perspective. Ideally, we'd
    // come up with an internal wrapper for our json object that supports pointer and path lookups
    // and pass that around in consumers instead.
    return JsonPath.parse(json.toString()).read(path);
  }
}
