package com.hp.stratus.pendingassociations.model.converter;

import com.hp.stratus.pendingassociations.model.ConditionsOperator;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;

@ReadingConverter
public class ConditionsOperatorReadConverter implements Converter<String, ConditionsOperator> {

  @Override
  public ConditionsOperator convert(String source) {
    return ConditionsOperator.fromValue(source);
  }
}
