package com.hp.stratus.http.client.utils;

public class HttpConstants {

  public static final String URL_SCHEME_HTTP = "http";
  public static final String URL_SCHEME_HTTPS = "https";

  // Proxy
  public static final String HTTP_PROXY_HOST_KEY = "http.proxyHost";
  public static final String HTTP_PROXY_PORT_KEY = "http.proxyPort";
  public static final String HTTPS_PROXY_HOST_KEY = "https.proxyHost";
  public static final String HTTPS_PROXY_PORT_KEY = "https.proxyPort";
  public static final String HTTP_NON_PROXY_KEY = "http.nonProxyHosts";
  public static final int HTTP_PROXY_PORT_DEFAULT = 80;
  public static final int HTTPS_PROXY_PORT_DEFAULT = 443;
}
