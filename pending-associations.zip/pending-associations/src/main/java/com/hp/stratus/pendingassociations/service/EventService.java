package com.hp.stratus.pendingassociations.service;

import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource;
import com.hp.stratus.pendingassociations.exceptions.BadGatewayException;
import com.hp.stratus.pendingassociations.exceptions.BadRequestException;
import com.hp.stratus.pendingassociations.model.Association;

import java.util.UUID;

/** Service for interacting with events. */
public interface EventService {

  /**
   * Subscribes to the supplied resource.
   *
   * @param resource The resource to subscribe to.
   */
  void subscribeToResource(ExternalEventResource resource);

  /**
   * Publishes an association update event.
   *
   * @param association The association.
   * @throws BadGatewayException When event management responds with a 5xx.
   * @throws BadRequestException When event management responds with a non-5xx error.
   */
  void publishAssociationUpdate(Association association)
      throws BadGatewayException, BadRequestException;

  /**
   * Fires an internal criteria resolved event.
   *
   * @param associationId The association ID.
   */
  void publishCriteriaResolved(UUID associationId);

  /**
   * Fires and internal execute next action event.
   *
   * @param associationId The association ID.
   */
  void publishExecuteNextAction(UUID associationId);

  /**
   * Publishes an association update event.
   *
   * @param associationId The association ID to publish.
   */
  void publishFireAssociationUpdate(UUID associationId);
}
