package com.hp.stratus.pendingassociations.model;

import lombok.Data;

/** Details for a criteria */
@Data
public class CriteriaDetails {
  private String resource;
  private String type;
}
