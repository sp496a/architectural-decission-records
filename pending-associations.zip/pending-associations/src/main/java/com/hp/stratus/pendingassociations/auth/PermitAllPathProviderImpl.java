package com.hp.stratus.pendingassociations.auth;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

/**
 * implement a new bean of PermitAllPathService when the application needs a different permit all
 * paths other than com.hp.stratus.box1.auth.path.DefaultPermitAllPathService
 *
 * @see com.hp.stratus.auth.path.PermitAllPathProvider
 */
@Primary
@Slf4j
@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class PermitAllPathProviderImpl implements com.hp.stratus.auth.path.PermitAllPathProvider {

  /**
   * Returns the list of paths that are always permitted.
   *
   * @return The list of paths.
   */
  public List<String> getPathForPermitAll() {
    return Arrays.asList("/ping", "/pending-associations/health", "/pending-associations/spec");
  }
}
