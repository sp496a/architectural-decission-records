package com.hp.stratus.pendingassociations.model.converter;

import com.hp.stratus.pendingassociations.model.ResourceIdType;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.WritingConverter;

@WritingConverter
public class ResourceIdTypeWriteConverter implements Converter<ResourceIdType, String> {

  @Override
  public String convert(ResourceIdType source) {
    return source.getValue();
  }
}
