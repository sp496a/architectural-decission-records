package com.hp.stratus.pendingassociations.config;

import com.launchdarkly.sdk.server.LDClient;
import jakarta.annotation.PreDestroy;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
@RequiredArgsConstructor
public class LaunchDarklyConfig {

  @Value("${launchdarkly.sdkKey}")
  private final String ldSdkKey;

  private LDClient ldClient;

  /** Creates LaunchDarkly client instance using SDK Key. */
  @Bean(name = "ldClient")
  @Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
  public LDClient getLaunchdarklyClient() {
    this.ldClient = new LDClient(ldSdkKey);
    return this.ldClient;
  }

  /** Closes LaunchDarkly client instance during service down. */
  @PreDestroy
  public void destroy() throws IOException {
    this.ldClient.close();
  }
}
