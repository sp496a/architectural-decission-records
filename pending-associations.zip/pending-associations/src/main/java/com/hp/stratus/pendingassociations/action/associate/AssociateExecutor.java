package com.hp.stratus.pendingassociations.action.associate;

import com.hp.stratus.pendingassociations.action.ActionExecutor;
import com.hp.stratus.pendingassociations.exceptions.ActionExecutionException;
import com.hp.stratus.pendingassociations.exceptions.ResourceResolutionException;
import com.hp.stratus.pendingassociations.model.Action;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.Operation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.NotImplementedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/** Executor for association actions. */
@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
@Slf4j
public class AssociateExecutor implements ActionExecutor {

  /** List of type resource type specific executors. */
  private final List<AssociateResourceExecutor> resourceExecutors;

  /**
   * Indicates that this executor only supports the associate operation.
   *
   * @return The association operation.
   */
  @Override
  public Operation getOperation() {
    return Operation.ASSOCIATE;
  }

  /**
   * Executes the associate action, handing the resource off to the relevant sub-executor.
   *
   * @param association The association.
   * @param action The action to execute.
   * @param actionIndex The index of the action.
   * @throws ResourceResolutionException Thrown when resource resolution fails.
   * @throws NotImplementedException Thrown if an unsupported resource is supplied.
   * @throws ActionExecutionException Thrown if the action fails.
   */
  @Override
  public void execute(Association association, Action action, int actionIndex)
      throws ResourceResolutionException, NotImplementedException, ActionExecutionException {

    // Associate actions only accept a single resource
    if (action.getResource() == null) {
      throw new ResourceResolutionException(
          "Only single resource definitions are allowed for associate actions");
    }

    // Find the correct resource executor
    AssociateResourceExecutor executor =
        resourceExecutors.stream()
            .filter(e -> e.getResourceType() == action.getResource().getType())
            .findFirst()
            .orElseThrow(
                () ->
                    new NotImplementedException(
                        "No executor found for association of resource "
                            + action.getResource().getType().toString()));

    // And execute the executor
    executor.execute(action.getResource(), association, actionIndex);
  }
}
