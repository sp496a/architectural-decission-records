package com.hp.stratus.pendingassociations.model.aggregation;

import com.hp.stratus.pendingassociations.model.ConditionComparator;
import lombok.Data;

/** Represents the result of an aggregate event pointer lookup. */
@Data
public class AggregatePointerResult {
  private String pointer;
  private ConditionComparator comparator;
  private ConditionValueField compareTo;
}
