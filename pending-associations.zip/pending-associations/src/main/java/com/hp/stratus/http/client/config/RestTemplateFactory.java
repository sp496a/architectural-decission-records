/*
 * Copyright (c) 2021, HP Development Company, L.P. All rights reserved. This software contains
 * confidential and proprietary information of HP. The user of this software agrees not to disclose,
 * disseminate or copy such Confidential Information and shall use the software only in accordance
 * with the terms of the license agreement the user entered into with HP.
 */

package com.hp.stratus.http.client.config;

import static com.hp.stratus.http.client.utils.HttpConstants.URL_SCHEME_HTTP;
import static com.hp.stratus.http.client.utils.HttpConstants.URL_SCHEME_HTTPS;

import com.hp.stratus.pendingassociations.exceptions.ResourceNotFoundException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.Iterator;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.hc.client5.http.ConnectionKeepAliveStrategy;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.BasicHttpClientConnectionManager;
import org.apache.hc.client5.http.impl.routing.SystemDefaultRoutePlanner;
import org.apache.hc.client5.http.socket.ConnectionSocketFactory;
import org.apache.hc.client5.http.socket.PlainConnectionSocketFactory;
import org.apache.hc.client5.http.ssl.NoopHostnameVerifier;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactory;
import org.apache.hc.core5.http.Header;
import org.apache.hc.core5.http.HeaderElement;
import org.apache.hc.core5.http.config.Registry;
import org.apache.hc.core5.http.config.RegistryBuilder;
import org.apache.hc.core5.http.message.BasicHeaderElementIterator;
import org.apache.hc.core5.ssl.SSLContexts;
import org.apache.hc.core5.ssl.TrustStrategy;
import org.apache.hc.core5.util.TimeValue;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.core.env.Environment;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class RestTemplateFactory {
  private static final String CONN_KEEP_ALIVE = "Keep-Alive";
  public static final int DEFAULT_KEEP_ALIVE_TIME = 20 * 1000; // 20 sec
  /**
   * Rest template configuration
   *
   * @param environment
   * @return RestTemplate
   */
  public static RestTemplate initRestTemplate(Environment environment) {
    var restTemplateBuilder = new RestTemplateBuilder();

    final SSLConnectionSocketFactory sslSocketFactory;
    final Registry<ConnectionSocketFactory> socketFactoryRegistry;

    TrustStrategy acceptingTrustStrategy = (cert, authType) -> true;
    SSLContext sslContext;
    try {
      sslContext = SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
    } catch (NoSuchAlgorithmException | KeyStoreException | KeyManagementException e) {
      throw new ResourceNotFoundException(e.getMessage());
    }
    sslSocketFactory = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);
    socketFactoryRegistry =
        RegistryBuilder.<ConnectionSocketFactory>create()
            .register(URL_SCHEME_HTTPS, sslSocketFactory)
            .register(URL_SCHEME_HTTP, new PlainConnectionSocketFactory())
            .build();

    var connectionManager = new BasicHttpClientConnectionManager(socketFactoryRegistry);
    var httpClientBuilder =
        HttpClients.custom()
            .setConnectionManager(connectionManager)
            .setKeepAliveStrategy(connectionKeepAliveStrategy());

    if (environment != null) {
      var planner = new SystemDefaultRoutePlanner(new StratusProxySelector(environment));
      httpClientBuilder.setRoutePlanner(planner);
    }
    var clientHttpRequestFactory =
        new HttpComponentsClientHttpRequestFactory(httpClientBuilder.build());
    return restTemplateBuilder.requestFactory(() -> clientHttpRequestFactory).build();
  }

  public static ConnectionKeepAliveStrategy connectionKeepAliveStrategy() {
    return (httpResponse, httpContext) -> {
      Iterator<Header> headerIterator = httpResponse.headerIterator(CONN_KEEP_ALIVE);
      BasicHeaderElementIterator elementIterator = new BasicHeaderElementIterator(headerIterator);

      while (elementIterator.hasNext()) {
        HeaderElement element = elementIterator.next();
        String param = element.getName();
        String value = element.getValue();
        if (value != null && param.equalsIgnoreCase("timeout")) {
          return TimeValue.ofMilliseconds(Long.parseLong(value) * 1000);
        }
      }

      return TimeValue.ofMilliseconds(DEFAULT_KEEP_ALIVE_TIME);
    };
  }
}
