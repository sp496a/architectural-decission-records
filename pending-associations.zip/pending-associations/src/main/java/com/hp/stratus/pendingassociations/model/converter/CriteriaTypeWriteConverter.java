package com.hp.stratus.pendingassociations.model.converter;

import com.hp.stratus.pendingassociations.model.CriteriaType;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.WritingConverter;

@WritingConverter
public class CriteriaTypeWriteConverter implements Converter<CriteriaType, String> {

  @Override
  public String convert(CriteriaType source) {
    return source.getValue();
  }
}
