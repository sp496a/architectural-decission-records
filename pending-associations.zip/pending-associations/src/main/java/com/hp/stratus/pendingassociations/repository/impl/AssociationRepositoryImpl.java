package com.hp.stratus.pendingassociations.repository.impl;

import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.repository.AssociationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.support.PageableExecutionUtils;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

import static com.hp.stratus.pendingassociations.data.Constants.ID;

@Repository
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class AssociationRepositoryImpl implements AssociationRepository {

  /** The mongo template to use for queries. */
  private final MongoTemplate mongoTemplate;

  /**
   * Creates a new association.
   *
   * @param association The association to create.
   * @return The created association
   */
  @Override
  public Association insert(Association association) {
    return mongoTemplate.insert(association);
  }

  /**
   * Finds an association by ID.
   *
   * @param id The association ID.
   * @return The matching association.
   */
  @Override
  public Association findById(UUID id) {

    Criteria criteria = Criteria.where(ID).is(id);
    Query query = Query.query(criteria);
    return mongoTemplate.findOne(query, Association.class);
  }

  /**
   * Writes the supplied association to the DB.
   *
   * @param association The association to save.
   * @return The saved association.
   */
  @Override
  public Association save(Association association) {
    return mongoTemplate.save(association);
  }

  /**
   * Retrieves associations with pagination.
   *
   * @param pageable Pagination settings.
   * @return Paged association list.
   */
  @Override
  public Page<Association> getPagedAssociationList(Pageable pageable) {
    Query query = new Query().with(pageable);
    List<Association> result = mongoTemplate.find(query, Association.class);
    return PageableExecutionUtils.getPage(
        result,
        pageable,
        () -> mongoTemplate.count(Query.of(query).limit(-1).skip(-1), Association.class));
  }

  /**
   * Searches associations with the supplied criteria.
   *
   * @param pageable Pagination settings.
   * @param criteria The search criteria.
   * @param value The value to compare against.
   * @return Paged association list.
   */
  @Override
  public Page<Association> getGenericSearchPagedAssociationList(
      Pageable pageable, String criteria, String value) {
    Query query = new Query().with(pageable);
    if (criteria != null && value != null) query.addCriteria(Criteria.where(criteria).is(value));
    List<Association> result = mongoTemplate.find(query, Association.class);
    return PageableExecutionUtils.getPage(
        result,
        pageable,
        () -> mongoTemplate.count(Query.of(query).limit(-1).skip(-1), Association.class));
  }

  /**
   * Gets the total count of associations.
   *
   * @return total number of associations.
   */
  @Override
  public long count() {
    return mongoTemplate.count(new Query(), Association.class);
  }
}
