package com.hp.stratus.pendingassociations.model;

import java.util.Arrays;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonProperty;

/** Operator to use for conditions. */
@AllArgsConstructor
public enum ConditionsOperator {
  @JsonProperty("and")
  AND("and");

  @Getter private final String value;

  public static ConditionsOperator fromValue(String text) {
  return Arrays.stream(values())
        .filter(val -> StringUtils.equalsIgnoreCase(val.getValue(), text))
        .findAny()
        .orElse(null);
  }
}
