package com.hp.stratus.pendingassociations.validation;

import com.hp.stratus.pendingassociations.dto.AssociationUpdateActionsDto;
import com.hp.stratus.pendingassociations.dto.ResourceType;
import com.hp.stratus.pendingassociations.exceptions.BadRequestException;

import java.util.List;
import java.util.Set;

import static com.hp.stratus.pendingassociations.dto.ResourceType.*;

/** Validator for actions. */
public class ActionValidator {
  private static final Set<ResourceType> SUPPORTED_RESOURCE_TYPES = Set.of(PC, PRINTER, CHROMEBOOK);
  /**
   * Applies validation in bulk.
   *
   * @param actions The actions to validate.
   */
  public static void validate(List<AssociationUpdateActionsDto> actions) {
    for (AssociationUpdateActionsDto action : actions) {
      validate(action);
    }
  }

  /**
   * Validates the supplied action.
   *
   * @param action The action.
   */
  public static void validate(AssociationUpdateActionsDto action) {
    switch (action.getOperation()) {
      case ASSOCIATE -> {
        // Associate actions must have a single resource field
        if (action.getResource() == null || action.getResources() != null) {
          throw new BadRequestException("associate actions must have a single resource");
        }
        // Associate actions must refer to a device
        if (!SUPPORTED_RESOURCE_TYPES.contains(action.getResource().getType())) {
          throw new BadRequestException("associate actions can only refer to devices");
        }
      }
      case ASSOCIATE_CONSENT -> {
        // Associate consent actions must have a resources field
        if (action.getResources() == null || action.getResource() != null) {
          throw new BadRequestException("associateConsent actions must have multiple resources");
        }
        // Associate consent actions must refer to a user
        if (action.getResources().getUser().getType() != ResourceType.USER) {
          throw new BadRequestException("associateConsent actions must refer to a user");
        }
        // Associate consent actions must refer to a device
        if (!SUPPORTED_RESOURCE_TYPES.contains(action.getResources().getDevice().getType())) {
          throw new BadRequestException("associateConsent actions must refer to a device");
        }
      }
      case UPDATE_METADATA -> {
          // Update metadata actions must have a resources field with some values
          if (action.getResources() == null || action.getResources().getUntypedResources().isEmpty()) {
            throw new BadRequestException("updateMetadata actions must refer to a set of resources");
          }
      }
      default -> throw new BadRequestException(
          "Unknown action operation: " + action.getOperation().getValue());
    }
  }
}
