package com.hp.stratus.pendingassociations.dto.event.external;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/** Defines a stratus event attribute. */
@Data
public class StratusEventAttribute {

  @JsonProperty("dataType")
  private String dataType;

  @JsonProperty("stringValue")
  private String stringValue;
}
