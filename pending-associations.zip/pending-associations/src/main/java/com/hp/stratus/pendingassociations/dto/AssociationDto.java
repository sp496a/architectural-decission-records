package com.hp.stratus.pendingassociations.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@Data
@Validated
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssociationDto {
  @JsonProperty("id")
  private UUID id;

  @JsonProperty("state")
  private State state;

  @JsonProperty("tenantId")
  @NotNull
  private String tenantId;

  @JsonProperty("actions")
  private List<AssociationUpdateActionsDto> actions;

  @JsonProperty("criteria")
  private List<CriteriaDto> criteria;

  @JsonProperty("metadata")
  private Map<String, Object> metadata;
}
