package com.hp.stratus.auth.path;

import com.hp.stratus.auth.conf.SecurityConfig;

import java.util.List;

/**
 * Provide a list of urls which permits all access The bean of this interface type will be used by
 * SecurityConfig
 *
 * @see SecurityConfig
 */
public interface PermitAllPathProvider {

  /**
   * @return a list of urls which permits all access
   */
  List<String> getPathForPermitAll();
}
