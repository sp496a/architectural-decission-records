package com.hp.stratus.pendingassociations.action.associate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.http.client.utils.HttpClient;
import com.hp.stratus.pendingassociations.dto.client.PcClaimRequest;
import com.hp.stratus.pendingassociations.exceptions.ActionExecutionException;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.Resource;
import com.hp.stratus.pendingassociations.model.ResourceType;
import com.hp.stratus.pendingassociations.model.cache.PcAssociationActionInformation;
import com.hp.stratus.pendingassociations.repository.ActionRepository;
import com.hp.stratus.pendingassociations.service.EventService;
import com.hp.stratus.pendingassociations.utils.PathResolver;
import com.hp.stratus.pendingassociations.utils.ResourceUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

/** A simple executor for pc association actions. */
@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
@Slf4j
public class AssociatePcExecutor implements AssociateResourceExecutor {

  /** The object mapper to use for extracting resource details. */
  private final ObjectMapper objectMapper;

  /** The path resolver to use for json path resources. */
  private final PathResolver pathResolver;

  /** The action repository for updating actions in the DB. */
  private final ActionRepository actionRepository;

  /** The service for firing events. */
  private final EventService eventService;

  /** Template for storing values in Redis. */
  private final RedisTemplate<String, PcAssociationActionInformation> redis;

  /** Basic HTTP client. */
  private final HttpClient client;

  /** Supplier for JWT tokens. */
  @Qualifier("jwtSupplier")
  private final Supplier<String> jwtSupplier;

  /** Base URL for stratus services. */
  @Value("${pc.device.base.url}")
  private final String baseUrl;

  /** Endpoint for device ownership. */
  @Value("${pc.device.ownership.endpoint}")
  private final String ownershipEndpoint;

  /**
   * Indicates that this executor only supports a pc resource type.
   *
   * @return The pc resource type.
   */
  @Override
  public ResourceType getResourceType() {
    return ResourceType.PC;
  }

  /**
   * Executes the association.
   *
   * @param deviceResource The device resource.
   * @param association The association to execute the action on.
   * @param actionIndex The index of the action to execute.
   * @throws ActionExecutionException Thrown if execution fails.
   */
  public void execute(Resource deviceResource, Association association, int actionIndex)
      throws ActionExecutionException {
    log.debug(
        "Executing association action {} for association {}", actionIndex, association.getId());

    // Resolve the resource and throw an exception if the resolution can't be done
    String deviceId =
        ResourceUtils.resolveResource(
            objectMapper, pathResolver, association, deviceResource.getId());

    // Write the device and association IDs to redis, so we can complete the action later
    redis
        .opsForValue()
        .set(deviceId, new PcAssociationActionInformation(association.getId(), actionIndex));

    // Construct the registration URI
    String uri = UriComponentsBuilder.fromUriString(baseUrl).path(ownershipEndpoint).toUriString();

    // Build the request
    PcClaimRequest req =
        PcClaimRequest.builder().deviceId(deviceId).tenantId(association.getTenantId()).build();

    // Make the request
    try {
      client.post(uri, jwtSupplier.get(), req, new ParameterizedTypeReference<>() {});
      log.info("Successfully initiated claim process for PC {}", deviceId);
    } catch (HttpClientErrorException e) {
      handleClientError(
          HttpStatus.valueOf(e.getStatusCode().value()),
          deviceId,
          association.getId(),
          actionIndex);
    } catch (HttpServerErrorException e) {
      handleServerError(HttpStatus.valueOf(e.getStatusCode().value()), deviceId);
    } catch (Exception e) {
      handleNetworkError(deviceId, e.getMessage());
    }
  }

  /**
   * Completes a claim for the supplied device ID and resolution object.
   *
   * @param deviceId The device ID.
   * @param resolutionObject The resolution object.
   */
  public void completeClaim(String deviceId, Map<String, Object> resolutionObject) {

    // Fetch the association ID from redis
    PcAssociationActionInformation actionInformation = redis.opsForValue().getAndDelete(deviceId);
    if (actionInformation == null) {
      log.debug("No pending claim found for PC {}", deviceId);
      return;
    }
    // Resolve the action
    resolveAction(
        deviceId,
        actionInformation.getAssociationId(),
        actionInformation.getActionIndex(),
        resolutionObject);
  }

  /**
   * Resolves the supplied action and fires the next action event.
   *
   * @param deviceId The device ID.
   * @param associationId The association ID.
   * @param actionIndex The action index to resolve.
   * @param resolutionObject The resolution object to use.
   */
  private void resolveAction(
      String deviceId, UUID associationId, int actionIndex, Object resolutionObject) {

    // Update the action
    boolean resolved = actionRepository.resolveAction(associationId, actionIndex, resolutionObject);
    if (!resolved) {
      log.warn("Failed to find association matching claim for PC {}", deviceId);
      return;
    }

    // Fire off the event to execute the next action
    eventService.publishExecuteNextAction(associationId);
  }

  /**
   * Handles a 4xx client error during claim.
   *
   * @param status The status code.
   * @param deviceId The device ID.
   * @param associationId The association ID.
   * @param actionIndex The index of the action.
   * @throws ActionExecutionException if the client error caused the execution to fail.
   */
  private void handleClientError(
      HttpStatus status, String deviceId, UUID associationId, int actionIndex)
      throws ActionExecutionException {

    // Clear out the redis field for waiting for a claim, it won't come
    redis.delete(deviceId);

    // If the status is anything but a conflict, we can't complete the association or retry
    if (status != HttpStatus.CONFLICT) {
      log.warn("Failed to initiate claim for PC {}: Response code={}", deviceId, status);
      throw new ActionExecutionException(
          false, "Client error when initiating claim for PC " + deviceId);
    }

    // The status is a conflict, resolve it with a resolution object indicating that
    log.info("PC with ID {} is already claimed, resolving...", deviceId);
    Map<String, Object> resolution =
        Map.of("message", "PC with ID " + deviceId + " is already claimed");
    resolveAction(deviceId, associationId, actionIndex, resolution);
    log.info("Successfully completed claim action for PC {}", deviceId);
  }

  /**
   * Handles a 5xx server error during claim.
   *
   * @param status The status code.
   * @param deviceId The device ID.
   * @throws ActionExecutionException Indicating that the action execution failed.
   */
  private void handleServerError(HttpStatus status, String deviceId)
      throws ActionExecutionException {
    redis.delete(deviceId);
    log.warn("Failed to initiate claim for PC {}: Response code={}. Retrying...", deviceId, status);
    throw new ActionExecutionException(
        true, "Server error when initiating claim for PC " + deviceId);
  }

  /**
   * Handles a network error during claim.
   *
   * @param deviceId The device ID.
   * @throws ActionExecutionException Indicating that action execution failed.
   */
  private void handleNetworkError(String deviceId, String message) throws ActionExecutionException {
    redis.delete(deviceId);
    log.warn("Failed to initiate claim for PC {}: {} Retrying...", deviceId, message);
    throw new ActionExecutionException(
        true, "Network error when initiating claim for PC " + deviceId);
  }
}
