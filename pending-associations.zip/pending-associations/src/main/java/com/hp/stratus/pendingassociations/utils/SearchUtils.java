package com.hp.stratus.pendingassociations.utils;

/** Basic class to help with searching. */
public class SearchUtils {

  /**
   * Splits the search string into criteria string and value strings.
   *
   * @param search Search string to split.
   * @return String[] array for criteria and value.
   */
  public static String[] splitSearchString(String search) {

    if (search == null) {
      return new String[2];
    }

    return search.split(":");
  }
}
