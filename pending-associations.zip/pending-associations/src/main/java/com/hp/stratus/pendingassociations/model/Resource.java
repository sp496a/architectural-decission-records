package com.hp.stratus.pendingassociations.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** The resource to apply an action to. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Resource {
  private ResourceType type;
  private ResourceId serial;
  private ResourceId model;
  private ResourceId id;
}
