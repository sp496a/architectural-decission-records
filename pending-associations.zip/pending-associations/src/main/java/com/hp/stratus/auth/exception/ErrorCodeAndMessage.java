package com.hp.stratus.auth.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@AllArgsConstructor
@ToString
public enum ErrorCodeAndMessage {
  /*
   Status Code:
     401 = Returned by framework if client is not Authenticated
     403 = Returned by framework if client is not Authorized
  */
  NOT_ALLOWED_ACCESS(
      "E", 403, "U", "0002", "Not allowed to access the resource or perform operation."),
  UNAUTHORIZED("E", 401, "U", "0008", "The request is unauthorized."),
  ;

  public static final String ELEMENT_CODE = "0101"; // service identification number for auth

  private String messageType;
  private Integer httpStatusCode;
  private String severity;
  private String messageNumber;
  private String message;

  public String getMessageCode() {
    return String.format("%S%S%S%S", messageType, ELEMENT_CODE, severity, messageNumber);
  }
}
