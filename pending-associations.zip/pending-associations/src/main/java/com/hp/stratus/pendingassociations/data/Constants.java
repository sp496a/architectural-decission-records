package com.hp.stratus.pendingassociations.data;

public class Constants {
  public static final String ID = "id";
  public static final String PENDING_ASSOCIATIONS_SERVICE_API_TITLE =
      "Pending Associations Service API";
  public static final String PENDING_ASSOCIATIONS_SERVICE_API_VERSION = "v1.0.0";
}
