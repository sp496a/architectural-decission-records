package com.hp.stratus.pendingassociations.utils;

import javax.json.*;

/** Simple utility class for dealing with JSON pointers. */
public class PointerUtils {

  /**
   * Resolves the supplied json pointer to a string.
   *
   * @param pointer The pointer value
   * @param json The JSON to search.
   * @return The string value.
   */
  public static String resolvePointer(String pointer, JsonStructure json) {

    // Ensure the pointer starts with /
    String sanitizedPointer = pointer;
    if (!sanitizedPointer.startsWith("/")) {
      sanitizedPointer = "/" + sanitizedPointer;
    }

    try {

      // Check that it's contained in the supplied JSON
      JsonPointer ptr = Json.createPointer(sanitizedPointer);
      if (!ptr.containsValue(json)) {
        return null;
      }

      // Grab it as a raw string if possible
      JsonValue resolved = ptr.getValue(json);
      if (JsonValue.ValueType.STRING.equals(resolved.getValueType())) {
        return ((JsonString) resolved).getString();
      }

      // Return it as a converted JSON string
      return resolved.toString();

    } catch (JsonException e) {

      // a JsonException is thrown when the supplied pointer references something inside a
      // non-object property. Treat that as though the structure doesn't contain the value
      return null;
    }
  }
}
