package com.hp.stratus.pendingassociations.service.impl;

import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.Condition;
import com.hp.stratus.pendingassociations.model.ConditionComparator;
import com.hp.stratus.pendingassociations.model.ConditionValue;
import com.hp.stratus.pendingassociations.model.Conditions;
import com.hp.stratus.pendingassociations.model.Criteria;
import com.hp.stratus.pendingassociations.model.CriteriaState;
import com.hp.stratus.pendingassociations.model.aggregation.AggregatePointerResult;
import com.hp.stratus.pendingassociations.repository.CriteriaRepository;
import com.hp.stratus.pendingassociations.service.CriteriaService;
import com.hp.stratus.pendingassociations.service.EventService;
import com.hp.stratus.pendingassociations.utils.PathResolver;
import com.hp.stratus.pendingassociations.utils.PointerUtils;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import javax.json.JsonStructure;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/** Service for executing criteria actions. */
@Slf4j
@Service
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class CriteriaServiceImpl implements CriteriaService {

  /** The criteria repository. */
  private final CriteriaRepository criteriaRepository;

  /** The service for firing events. */
  private final EventService eventService;

  private final PathResolver pathResolver;

  /**
   * Resolves event-based criteria.
   *
   * @param resource The event resource.
   * @param type The event type.
   * @param event The event body.
   * @param resolutionObject The resolution object to use.
   */
  public void resolveEventBasedCriteria(
      ExternalEventResource resource,
      ExternalEventType type,
      JsonStructure event,
      Object resolutionObject) {

    // Get all unique json pointers for the event resource/type
    log.debug("Finding unique event pointer criteria...");
    List<AggregatePointerResult> pointers =
        criteriaRepository.findUniquePendingEventPointers(resource, type);
    log.debug("Found {} unique event pointer criteria", pointers.size());

    // Loop over the pointers and execute the queries to find matching associations
    for (AggregatePointerResult pointer : pointers) {

      // Resolve the pointer, and check that it's contained in the event
      log.debug("Evaluating event pointer {}...", pointer.getPointer());
      String resolvedPointer = PointerUtils.resolvePointer(pointer.getPointer(), event);
      if (resolvedPointer == null) {
        log.debug("No value found for event pointer {}", pointer.getPointer());
        continue;
      }
      log.debug("Successfully extracted string value for event pointer {}", pointer.getPointer());

      // Update associations
      log.debug("Resolving criteria for event pointer {}...", pointer.getPointer());
      long updatedCount =
          criteriaRepository.resolvePendingCriteria(
              resolvedPointer, pointer.getCompareTo(), pointer.getComparator(), resolutionObject);
      log.debug("Resolved criteria in {} associations", updatedCount);

      // If nothing was updated, we're done
      if (updatedCount == 0) {
        log.debug("No matching associations for event {}", resource.getValue());
        continue;
      }

      // Fetch associations ready for action execution
      log.debug("Retrieving associations with completed criteria...");
      List<Association> updatedAssociations =
          criteriaRepository.getPendingAssociationsWithCompletedCriteria();
      log.debug("Retrieved {} completed associations", updatedAssociations.size());

      // Fire an internal event for each association that's now ready for execution
      log.debug(
          "Firing criteria resolved events for {} completed associations",
          updatedAssociations.size());
      for (Association association : updatedAssociations) {
        eventService.publishCriteriaResolved(association.getId());
      }
      log.debug(
          "Successfully fired {} criteria resolved events for completed associations",
          updatedAssociations.size());
    }
  }

  /**
   * Resolves criteria for chromebooks. TODO: this is a hack
   *
   * @param resource The event resource.
   * @param type The event type.
   * @param eventMap A map representation of the event.
   * @param eventStructure A structure representation of the event.
   */
  @Override
  public void resolveConditionCriteriaHack(
      ExternalEventResource resource,
      ExternalEventType type,
      Map<String, Object> eventMap,
      JsonStructure eventStructure) {

    // Get all Associations in Pending state with existing 'criteria.conditions' field
    List<Association> associations = criteriaRepository.findAssociationsWithConditions(resource, type);

    // For each association, extract the paths/pointers from the event structure supplied
    for (Association association : associations) {
      boolean isResolved = false;
      for (Criteria criteria : association.getCriteria()) {
        if (matchCondition(criteria.getConditions(), eventStructure)
            && criteria.getState() == CriteriaState.PENDING) {
          // For matching criteria, stick the event map into resolvedWith, and update the
          // state/resolvedWith/resolvedAt fields
          criteria.setState(CriteriaState.RESOLVED);
          criteria.setResolvedAt(LocalDateTime.now());
          criteria.setResolvedWith(eventMap);
          isResolved = true;
        }
      }
      if (isResolved) {
        // Save the association if it has resolved criteria(s).
        criteriaRepository.save(association);
        log.debug(
            "Firing criteria resolved events for completed association with id: {}",
            association.getId());
        // Fire the actions for associations whose criteria are now completed
        eventService.publishCriteriaResolved(association.getId());
        log.debug(
            "Successfully fired criteria resolved event for completed association with id: {}",
            association.getId());
      }
    }
  }

  private boolean matchCondition(Conditions conditions, JsonStructure eventStructure) {
    if (conditions == null) {
      return false;
    }
    // TODO: Add some extra logic for "operator" other than "and"
    for (Condition value : conditions.getValues()) {
      if (!matchPointerOrPath(
              value.getValue1(), value.getValue2(), value.getComparator(), eventStructure)
          && !matchPointerOrPath(
              value.getValue2(), value.getValue1(), value.getComparator(), eventStructure)) {
        return false;
      }
    }
    return true;
  }

  private boolean matchPointerOrPath(
      ConditionValue value1,
      ConditionValue value2,
      ConditionComparator comparator,
      JsonStructure eventStructure) {
    return switch (value1.getType()) {
      case POINTER -> matchPointer(
          value1.getValue(), value2.getValue(), comparator, eventStructure);
      case PATH -> matchPath(value1.getValue(), value2.getValue(), comparator, eventStructure);
      case STRING -> false;
    };
  }

  private boolean matchPointer(
      String pointer, String value, ConditionComparator comparator, JsonStructure eventStructure) {
    String resolvedPointer = PointerUtils.resolvePointer(pointer, eventStructure);
    return switch (comparator) {
      case EQUALS -> StringUtils.equals(value, resolvedPointer);
    };
  }

  private boolean matchPath(
      String path, String value, ConditionComparator comparator, JsonStructure eventStructure) {
    List<String> resolvedPath = pathResolver.resolvePath(path, eventStructure);
    return switch (comparator) {
      case EQUALS -> resolvedPath.contains(value);
    };
  }
}
