package com.hp.stratus.pendingassociations.repository.impl;

import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType;
import com.hp.stratus.pendingassociations.model.*;
import com.hp.stratus.pendingassociations.model.aggregation.AggregatePointerResult;
import com.hp.stratus.pendingassociations.model.aggregation.ConditionValueField;
import com.hp.stratus.pendingassociations.repository.CriteriaRepository;
import java.time.LocalDateTime;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.ListUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

@Repository
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class CriteriaRepositoryImpl implements CriteriaRepository {

  /** State of the association. */
  private static final String STATE = "state";
  /** Query criteria. */
  private static final String CRITERIA = "criteria";
  /** Query criteria condition. */
  private static final String CRITERIA_CONDITION = CRITERIA + ".condition.";
  /** The pc unique id key name. */
  private static final String VALUE = ".value";
  /** The mongo template to use for queries. */
  private final MongoTemplate mongoTemplate;

  /**
   * Executes an aggregate query, which extracts the relevant JSON pointers for the given event in
   * the DB. This allows us to extract those values from the event, and then perform efficient
   * searches to find matching associations.
   *
   * @param resource The event resource.
   * @param type The event type.
   * @return List of unique pointers/comparators to assist with future queries.
   */
  @Override
  public List<AggregatePointerResult> findUniquePendingEventPointers(
      ExternalEventResource resource, ExternalEventType type) {

    AggregationResults<AggregatePointerResult> value1Pointers =
        mongoTemplate.aggregate(
            createCriteriaEventPointerAggregation(resource, type, ConditionValueField.value1),
            Association.class,
            AggregatePointerResult.class);

    AggregationResults<AggregatePointerResult> value2Pointers =
        mongoTemplate.aggregate(
            createCriteriaEventPointerAggregation(resource, type, ConditionValueField.value2),
            Association.class,
            AggregatePointerResult.class);

    return ListUtils.union(value1Pointers.getMappedResults(), value2Pointers.getMappedResults());
  }

  @Override
  public List<Association> findAssociationsWithConditions(
      ExternalEventResource resource, ExternalEventType type) {
    Query query = new Query();
    query.addCriteria(
        Criteria.where(STATE)
            .is(CriteriaState.PENDING.getValue())
            .and(CRITERIA)
            .elemMatch(
                Criteria.where("type")
                    .is(CriteriaType.EVENT_RECEIVED.getValue())
                    .and("details.resource")
                    .is(resource.getValue())
                    .and("details.type")
                    .is(type.getValue())
                    .and("conditions")
                    .exists(true)));
    return mongoTemplate.find(query, Association.class);
  }

  /**
   * Resolves associations that have a criteria with the specified value.
   *
   * @param value The value to use for comparison.
   * @param compareValue The value to compare against.
   * @param comparator The comparator to use.
   * @param resolutionObject The object to resolve the criteria with.
   * @return The number of updated associations.
   */
  @Override
  public long resolvePendingCriteria(
      String value,
      ConditionValueField compareValue,
      ConditionComparator comparator,
      Object resolutionObject) {
    switch (comparator) {
      case EQUALS:
        return resolvePendingCriteriaWithEquality(value, compareValue, resolutionObject);

      default:
        // Unsupported comparator, nothing to update
        return 0;
    }
  }

  /**
   * Gets all associations with completed criteria.
   *
   * @return The list of associations.
   */
  @Override
  public List<Association> getPendingAssociationsWithCompletedCriteria() {
    Query query = new Query();
    query.addCriteria(
        Criteria.where(STATE)
            .is(CriteriaState.PENDING.getValue())
            .and(CRITERIA)
            .not()
            .elemMatch(Criteria.where(STATE).is(CriteriaState.PENDING.getValue())));

    return mongoTemplate.find(query, Association.class);
  }

  @Override
  public void save(Association association) {
    mongoTemplate.save(association);
  }

  /**
   * Creates an aggregation capable of finding distinct pointer/comparator pairs for a given event
   * and value.
   *
   * @param resource The event resource.
   * @param type The event type.
   * @param value The value to search.
   * @return The aggregation.
   */
  private Aggregation createCriteriaEventPointerAggregation(
      ExternalEventResource resource, ExternalEventType type, ConditionValueField value) {

    // Look for associations in the pending state
    MatchOperation pendingAssociationsMatch =
        Aggregation.match(Criteria.where(STATE).is(State.PENDING));

    // Unwind the criteria
    UnwindOperation criteriaUnwind = Aggregation.unwind(CRITERIA);

    // Match the criteria details
    MatchOperation matchCriteria =
        Aggregation.match(
            Criteria.where("criteria.state")
                .is(CriteriaState.PENDING.getValue())
                .and("criteria.type")
                .is(CriteriaType.EVENT_RECEIVED.getValue())
                .and("criteria.details.resource")
                .is(resource.getValue())
                .and("criteria.details.type")
                .is(type.getValue())
                .and(CRITERIA_CONDITION + value + ".type")
                .is(ConditionValueType.POINTER.getValue()));

    // Group it into distinct values
    GroupOperation groupOperation =
        Aggregation.group(
            Fields.from(
                Fields.field("pointer", CRITERIA_CONDITION + value + VALUE),
                Fields.field("comparator", "criteria.condition.comparator")));

    // Project it onto a new object, extracting the pointer and comparator
    ProjectionOperation projectionOperation =
        Aggregation.project(
            Fields.from(
                Fields.field("pointer", "_id.pointer"),
                Fields.field("comparator", "_id.comparator")));

    // Add a compareTo field
    AddFieldsOperation addFieldsOperation =
        Aggregation.addFields()
            .addFieldWithValue(
                "compareTo",
                value == ConditionValueField.value1
                    ? ConditionValueField.value2
                    : ConditionValueField.value1)
            .build();

    // Build the pipeline
    return Aggregation.newAggregation(
        pendingAssociationsMatch,
        criteriaUnwind,
        matchCriteria,
        groupOperation,
        projectionOperation,
        addFieldsOperation);
  }

  /**
   * Resolves pending event criteria using an equality operator.
   *
   * @param value The value to look for.
   * @param compareValue The value to compare to.
   * @param resolutionObject The object to resolve with.
   * @return Associations with resolved criteria.
   */
  private long resolvePendingCriteriaWithEquality(
      String value, ConditionValueField compareValue, Object resolutionObject) {

    // Construct the query
    Query query = new Query();
    query.addCriteria(
        Criteria.where(STATE)
            .is(State.PENDING.getValue())
            .and(CRITERIA)
            .elemMatch(
                Criteria.where(STATE)
                    .is(CriteriaState.PENDING.getValue())
                    .and("condition." + compareValue + VALUE)
                    .is(value)
                    .and("condition.comparator")
                    .is(ConditionComparator.EQUALS.getValue())));

    // Construct the update definition
    Update update = new Update();
    update.set("criteria.$[criteria].state", CriteriaState.RESOLVED.getValue());
    update.set("criteria.$[criteria].resolvedAt", LocalDateTime.now());
    update.set("criteria.$[criteria].resolvedWith", resolutionObject);
    update.filterArray(
        Criteria.where("criteria.state")
            .is(CriteriaState.PENDING.getValue())
            .and(CRITERIA_CONDITION + compareValue + VALUE)
            .is(value)
            .and("criteria.condition.comparator")
            .is(ConditionComparator.EQUALS.getValue()));

    return mongoTemplate.updateMulti(query, update, Association.class).getModifiedCount();
  }
}
