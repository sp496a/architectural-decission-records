package com.hp.stratus.pendingassociations.action.associateconsent;

import com.hp.stratus.http.client.utils.HttpClient;
import com.hp.stratus.pendingassociations.dto.client.CmsConsentAssociationRequest;
import com.hp.stratus.pendingassociations.dto.client.PcManufacturingCatalogDevice;
import com.hp.stratus.pendingassociations.dto.client.PcManufacturingCatalogResponse;
import com.hp.stratus.pendingassociations.exceptions.ActionExecutionException;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.ResourceType;
import com.hp.stratus.pendingassociations.repository.ActionRepository;
import com.hp.stratus.pendingassociations.service.EventService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.UUID;
import java.util.function.Supplier;

/** A simple executor for consent association actions. */
@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
@Slf4j
public class AssociateConsentPcExecutor implements AssociateConsentResourceExecutor {

  /** The action repository for updating actions in the DB. */
  private final ActionRepository actionRepository;

  /** The service for firing events. */
  private final EventService eventService;

  /** Basic HTTP client. */
  private final HttpClient client;

  /** Supplier for JWT tokens. */
  @Qualifier("jwtSupplier")
  private final Supplier<String> jwtSupplier;

  /** Base URL for stratus services. */
  @Value("${stratus.base.url}")
  private final String stratusBaseUrl;

  /** Endpoint for consent service. */
  @Value("${stratus.cms.association.endpoint}")
  private final String cmsAssociationEndpoint;

  /** Base url to PC Manufacturing. */
  @Value("${pc.manufacturing.base.url}")
  private final String pcManufacturingBaseUrl;

  /** Endpoint to get device detail from PC Manufacturing. */
  @Value("${pc.manufacturing.device.endpoint}")
  private final String pcManufacturingDeviceEndpoint;

  /**
   * Indicates that this executor only supports a pc resource type.
   *
   * @return The pc resource type.
   */
  @Override
  public ResourceType getDeviceResourceType() {
    return ResourceType.PC;
  }

  /**
   * Executes the association.
   *
   * @param userId The user ID.
   * @param deviceId The device ID.
   * @param association The association to execute the action on.
   * @param actionIndex The index of the action to execute.
   * @throws ActionExecutionException Thrown when action execution fails.
   */
  public void execute(String userId, String deviceId, Association association, int actionIndex)
      throws ActionExecutionException {
    log.debug(
        "Executing association action {} for association {}", actionIndex, association.getId());

    // Get the device serial number
    PcManufacturingCatalogDevice device = getDeviceDetail(deviceId);

    // Lowercase the device ID before copying the consents to the device. HPSmart assumes all app
    // instance IDs are lowercase, so we need to lowercase the device ID to allow the HPOne agent to
    // interact with those consents through HPSmart APIs (HP1WA-1666, HP1SV-521).
    String deviceUuid = device.getUuid();
    if (deviceUuid != null) {
      deviceUuid = deviceUuid.toLowerCase();
    }

    // Prepare the request for CMS
    String uri =
        UriComponentsBuilder.fromUriString(stratusBaseUrl)
            .path(cmsAssociationEndpoint)
            .toUriString();
    CmsConsentAssociationRequest req =
        CmsConsentAssociationRequest.builder()
            .userId(userId)
            .tenantId(association.getTenantId())
            .deviceUUID(deviceUuid)
            .deviceSerialNumber(device.getSerialNumber())
            .build();

    // Make the request
    try {
      client.patch(uri, jwtSupplier.get(), req, new ParameterizedTypeReference<>() {});
      log.info(
          "Successfully associated consent for action {} in association {}",
          actionIndex,
          association.getId());
      resolveAction(association.getId(), actionIndex, null);
    } catch (HttpClientErrorException e) {
      log.warn("Client error when associating consent for device {}:", deviceId, e);
      throw new ActionExecutionException(
          false, "Client error when associating consent for device " + deviceId);
    } catch (HttpServerErrorException e) {
      log.warn("Server error when associating consent for device {}:", deviceId, e);
      throw new ActionExecutionException(
          true, "Server error when associating consent for device " + deviceId);
    } catch (Exception e) {
      log.warn("Network error when associating consent for device {}:", deviceId, e);
      throw new ActionExecutionException(
          true, "Network error when associating consent for device " + deviceId);
    }
  }

  /**
   * This method calls pc manufacturing device endpoint to get device serial number or other detail
   * of the pc as needed to call cms
   *
   * @param deviceId unique Id
   * @return device SerialNumber
   * @throws ActionExecutionException If fetching the details fails.
   */
  private PcManufacturingCatalogDevice getDeviceDetail(String deviceId)
      throws ActionExecutionException {

    // Construct the pc manufacturing URI
    String uri =
        UriComponentsBuilder.fromUriString(pcManufacturingBaseUrl)
            .path(pcManufacturingDeviceEndpoint)
            .query("deviceUniqueId=" + deviceId)
            .toUriString();

    // Make the request
    ResponseEntity<PcManufacturingCatalogResponse> response;
    try {
      response = client.get(uri, jwtSupplier.get(), new ParameterizedTypeReference<>() {});
    } catch (HttpClientErrorException e) {
      log.warn("Client error when retrieving device details for device {}:", deviceId, e);
      throw new ActionExecutionException(
          false, "Client error when retrieving device details for device " + deviceId);
    } catch (HttpServerErrorException e) {
      log.warn("Server error when retrieving device details for device {}:", deviceId, e);
      throw new ActionExecutionException(
          true, "Server error when retrieving device details for device " + deviceId);
    } catch (Exception e) {
      log.warn("Network error when retrieving device details for device {}:", deviceId, e);
      throw new ActionExecutionException(
          true, "Network error when retrieving device details for device " + deviceId);
    }

    // Check that we have devices
    PcManufacturingCatalogResponse deviceDetail = response.getBody();
    if (deviceDetail == null) {
      log.warn("Received an empty response from PC MFG for device {}", deviceId);
      throw new ActionExecutionException(
          false, "Received an empty response from PC MFG for device " + deviceId);
    }

    PcManufacturingCatalogDevice device =
        deviceDetail.getDevices().stream().findFirst().orElse(null);
    if (device == null) {
      log.warn("Received an empty device list from PC MFG for device {}", deviceId);
      throw new ActionExecutionException(
          false, "Received an empty device list from PC MFG for device " + deviceId);
    }

    return device;
  }

  /**
   * Resolves the supplied action and fires the next action event.
   *
   * @param associationId The association ID.
   * @param actionIndex The action index to resolve.
   * @param resolutionObject The resolution object to use.
   */
  private void resolveAction(UUID associationId, int actionIndex, Object resolutionObject) {

    // Update the action
    boolean resolved = actionRepository.resolveAction(associationId, actionIndex, resolutionObject);
    if (!resolved) {
      log.warn("Failed to find action {} for association {}", actionIndex, associationId);
      return;
    }

    // Fire off the event to execute the next action
    eventService.publishExecuteNextAction(associationId);
  }
}
