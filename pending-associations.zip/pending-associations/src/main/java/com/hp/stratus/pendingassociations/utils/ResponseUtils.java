package com.hp.stratus.pendingassociations.utils;

import com.hp.stratus.pendingassociations.dto.PagedResponse;

import java.util.List;

/** read file as resources */
public class ResponseUtils {
  private ResponseUtils() {}

  /**
   * Generate a {@link PagedResponse}.
   *
   * @param item item list
   * @param size total size
   * @return generated {@link PagedResponse}
   */
  public static <T> PagedResponse<T> generatePagedResponse(List<T> item, int size) {
    PagedResponse<T> pagedResponse = new PagedResponse<>();
    pagedResponse.setContents(item);
    pagedResponse.setTotalSize(size);
    return pagedResponse;
  }
}
