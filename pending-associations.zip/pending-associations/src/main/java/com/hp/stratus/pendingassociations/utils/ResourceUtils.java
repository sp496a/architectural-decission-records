package com.hp.stratus.pendingassociations.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.exceptions.ResourceResolutionException;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.ResourceId;

import javax.json.Json;
import javax.json.JsonReader;
import javax.json.JsonStructure;
import java.io.StringReader;
import java.util.List;

/** Helper for resolving resources. */
public class ResourceUtils {

  /**
   * Helper for resolving resources.
   *
   * @param objectMapper The object mapper to use.
   * @param pathResolver The resolver to use for path-based resources.
   * @param association The association.
   * @param resource The resource to resolve.
   * @return The resolved resource.
   */
  public static String resolveResource(
      ObjectMapper objectMapper,
      PathResolver pathResolver,
      Association association,
      ResourceId resource)
      throws ResourceResolutionException {

    switch (resource.getType()) {
      case STRING:
        return resource.getValue();

      case POINTER:

        // Parse the association into a structure
        JsonStructure pointerStructure = parseAssociation(objectMapper, association);

        // And resolve the pointer
        String resolvedPointer = PointerUtils.resolvePointer(resource.getValue(), pointerStructure);

        // Resolution was successful, return the resolved value
        if (resolvedPointer != null) {
          return resolvedPointer;
        }

        // Resolution failed, throw a resolution exception
        throw new ResourceResolutionException(
            "Failed to resolve pointer resource "
                + resource.getValue()
                + " in "
                + association.getId().toString());

      case PATH:

        // Parse the association into a structure
        JsonStructure pathStructure = parseAssociation(objectMapper, association);

        // And resolve the path
        List<String> resolvedPath = pathResolver.resolvePath(resource.getValue(), pathStructure);

        // If we have a single resolved path, return it
        if (resolvedPath != null && resolvedPath.size() == 1) {
          return resolvedPath.get(0);
        }

        // Resolution failed
        throw new ResourceResolutionException(
            "Failed to resolve path resource "
                + resource.getValue()
                + " in "
                + association.getId().toString());

      default:
        throw new ResourceResolutionException("Invalid resource ID type " + resource.getType());
    }
  }

  /**
   * Parses the supplied association into a JSON structure.
   *
   * @param mapper The object mapper to use.
   * @param association The association to parse.
   * @throws ResourceResolutionException If the association could not be parsed.
   * @return The parsed JSON structure.
   */
  private static JsonStructure parseAssociation(ObjectMapper mapper, Association association)
      throws ResourceResolutionException {
    try (JsonReader reader =
        Json.createReader(new StringReader(mapper.writeValueAsString(association)))) {
      return reader.read();
    } catch (JsonProcessingException e) {
      throw new ResourceResolutionException("Failed to parse association JSON structure", e);
    }
  }
}
