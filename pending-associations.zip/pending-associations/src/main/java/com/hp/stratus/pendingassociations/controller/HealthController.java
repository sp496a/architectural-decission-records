package com.hp.stratus.pendingassociations.controller;

import com.hp.stratus.pendingassociations.data.Health;
import com.hp.stratus.pendingassociations.service.SpecService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

import static org.springframework.web.bind.annotation.RequestMethod.GET;

@Slf4j
@RestController
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class HealthController {

  private final SpecService specService;

  @RequestMapping(method = GET, value = "/ping")
  public Health getPing() {
    log.debug("Test log: HealthController.getPing method invocation");
    return new Health("pending-associations", "healthy");
  }

  @GetMapping(value = "/pending-associations/health")
  public Health getHealth() {
    log.debug("Test log: HealthController.getHealth method invocation");
    return new Health("pending-associations", "healthy");
  }

  /**
   * Get Json format of swagger spec file
   *
   * @return Json file
   */
  @GetMapping(value = "/pending-associations/spec", produces = MediaType.APPLICATION_JSON_VALUE)
  public String getSpec() throws IOException {
    return specService.getSpec();
  }
}
