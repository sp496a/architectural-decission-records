package com.hp.stratus.pendingassociations.controller;

import com.hp.stratus.pendingassociations.dto.*;
import com.hp.stratus.pendingassociations.service.AssociationService;
import com.hp.stratus.pendingassociations.utils.DataConverterUtils;
import com.hp.stratus.pendingassociations.utils.ResponseUtils;
import com.hp.stratus.pendingassociations.validation.ActionValidator;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@Slf4j
@RestController
@Validated
@RequestMapping(value = "pending-associations/v1")
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class AssociationRestController {

  private final AssociationService associationService;

  /**
   * Defines a post route for creating an association from a createAssociationRequest
   *
   * @param createAssociationRequest api request for create the association
   * @return createAssociationRes api response for the creation of association
   */
  @PreAuthorize("hasPermission('scope', T(com.hp.stratus.pendingassociations.auth.Scope).CREATE )")
  @PostMapping(value = "/associations")
  public ResponseEntity<CreateAssociationResponse> create(
      @NotNull @Validated(AssociationUpdateDto.PostAssociation.class) @RequestBody
          CreateAssociationRequest createAssociationRequest) {
    log.debug("Begin : {} : create ", this.getClass().getName());
    // Validate the supplied actions
    ActionValidator.validate(createAssociationRequest.getActions());

    CreateAssociationResponse createAssociationRes =
        associationService.create(createAssociationRequest);
    log.debug("End : {} : create ", this.getClass().getName());
    return new ResponseEntity<>(createAssociationRes, HttpStatus.CREATED);
  }

  /**
   * Defines a get route for retrieving an association by its id
   *
   * @param associationId unique id represents the association to be retrieved
   * @return associationDto represent the associatino dto object
   */
  @PreAuthorize("hasPermission('scope', T(com.hp.stratus.pendingassociations.auth.Scope).READ )")
  @GetMapping("/associations/{associationId}")
  public ResponseEntity<AssociationDto> get(@PathVariable("associationId") UUID associationId) {
    log.debug("Controller : begin : associationId : {} ", associationId);
    AssociationDto associationDto = associationService.get(associationId);
    log.debug("Controller : exit : association: {} ", associationDto);
    return new ResponseEntity<>(associationDto, HttpStatus.OK);
  }

  /**
   * Retrieves the paged list of Association available to the user.
   *
   * @param offset 0-based offset to start page from
   * @param limit number of items to include in the current page. Default is -1 (include all).
   * @param sortStrings array of sort strings
   * @param searchString key:value pair string
   * @return list of {@link ResponseEntity}
   */
  @PreAuthorize("hasPermission('scope', T(com.hp.stratus.pendingassociations.auth.Scope).READ )")
  @GetMapping(value = "/associations")
  public ResponseEntity<PagedResponse<AssociationDto>> getPagedAssociationList(
      @Valid @RequestParam(value = "offset", required = false, defaultValue = "0") @Min(0)
          Integer offset,
      @Valid @RequestParam(value = "limit", required = false, defaultValue = "20") @Min(1)
          Integer limit,
      @RequestParam(value = "sortBy", required = false) String[] sortStrings,
      @RequestParam(value = "search", required = false) String searchString) {
    Sort sort = sortStrings == null ? null : DataConverterUtils.convertToSort(List.of(sortStrings));
    Page<AssociationDto> result =
        associationService.getPaginatedAssociationList(offset, limit, sort, searchString);
    PagedResponse<AssociationDto> pagedResponse =
        ResponseUtils.generatePagedResponse(result.getContent(), (int) result.getTotalElements());
    return new ResponseEntity<>(pagedResponse, HttpStatus.OK);
  }

  /**
   * Put an association by its id
   *
   * @param associationId unique id of the association
   * @param putAssociationRequest put association request DTO object
   * @return PutAssociationResponse put association response DTO object
   */
  @PreAuthorize("hasPermission('scope', T(com.hp.stratus.pendingassociations.auth.Scope).UPDATE )")
  @PutMapping("/associations/{associationId}")
  public ResponseEntity<PutAssociationResponse> put(
      @NotNull @Valid @PathVariable("associationId") UUID associationId,
      @NotNull @Validated(AssociationUpdateDto.PutAssociation.class) @RequestBody
          PutAssociationRequest putAssociationRequest) {
    log.debug(
        "Controller : begin : associationId : {}, putAssociationRequest : {}",
        associationId,
        putAssociationRequest);

    PutAssociationResponse putAssociationResponse =
        associationService.put(associationId, putAssociationRequest);

    log.debug("Controller : exit : putAssociationResponse: {} ", putAssociationResponse);
    return new ResponseEntity<>(putAssociationResponse, HttpStatus.OK);
  }

  /**
   * Delete an association by its id
   *
   * @param associationId unique id of the association
   */
  @PreAuthorize("hasPermission('scope', T(com.hp.stratus.pendingassociations.auth.Scope).DELETE )")
  @DeleteMapping("/associations/{associationId}")
  public void delete(@NotNull @Valid @PathVariable("associationId") UUID associationId) {
    log.debug("Begin : {} : delete ", this.getClass().getName());

    long numOfRecordsDeleted = associationService.delete(associationId);

    log.debug(" No of records deleted for {} is {} ", associationId, numOfRecordsDeleted);

    log.debug("End : {} : delete ", this.getClass().getName());
  }

  /**
   * Patch existing association with partial association content
   *
   * @param associationId : the UUID of the association to be updated
   * @param patchAssociationRequest : the partial association to be updated
   * @return PatchAssociationResponse the patch association dto object
   */
  @PreAuthorize("hasPermission('scope', T(com.hp.stratus.pendingassociations.auth.Scope).UPDATE )")
  @PatchMapping("/associations/{associationId}")
  public ResponseEntity<PatchAssociationResponse> patch(
      @NotNull @Valid @PathVariable UUID associationId,
      @NotNull @Validated(AssociationUpdateDto.PatchAssociation.class) @RequestBody
          PatchAssociationRequest patchAssociationRequest) {

    // Validate any supplied actions
    if (patchAssociationRequest.getActions() != null) {
      ActionValidator.validate(patchAssociationRequest.getActions());
    }

    PatchAssociationResponse patchAssociationResponse =
        associationService.patch(associationId, patchAssociationRequest);

    return ResponseEntity.ok(patchAssociationResponse);
  }

  /**
   * Counts all association by paginated list
   *
   * @return {@link ResponseEntity}
   */
  @PreAuthorize("hasPermission('scope', T(com.hp.stratus.pendingassociations.auth.Scope).READ )")
  @RequestMapping(value = "/associations", method = RequestMethod.HEAD)
  public ResponseEntity<String> head(
      @Valid @RequestParam(value = "offset", required = false, defaultValue = "0") @Min(0)
          Integer offset,
      @Valid @RequestParam(value = "limit", required = false, defaultValue = "20") @Min(1)
          Integer limit) {
    var headers = new HttpHeaders();
    String contentRange = associationService.head(offset, limit);
    headers.add("contentRange", contentRange);

    return ResponseEntity.ok().headers(headers).body(null);
  }
}
