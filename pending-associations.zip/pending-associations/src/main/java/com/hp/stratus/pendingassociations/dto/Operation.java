package com.hp.stratus.pendingassociations.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.util.Arrays;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

@AllArgsConstructor
public enum Operation {
  ASSOCIATE("associate"),
  ASSOCIATE_CONSENT("associateConsent"),
  UPDATE_METADATA("updateMetadata");

  @Getter @JsonValue private final String value;

  @JsonCreator
  public static Operation fromValue(String text) {
    return Arrays.stream(values())
        .filter(val -> StringUtils.equalsIgnoreCase(val.getValue(), text))
        .findAny()
        .orElse(null);
  }
}
