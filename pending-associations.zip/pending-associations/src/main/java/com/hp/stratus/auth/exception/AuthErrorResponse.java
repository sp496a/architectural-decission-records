package com.hp.stratus.auth.exception;

import lombok.*;

import java.util.List;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class
AuthErrorResponse {

  public static final String VERSION = "1.0.0";
  private String stratusVersion;
  private Integer httpStatusCode;
  private List<AuthErrorMessage> errors;
}
