package com.hp.stratus.pendingassociations.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

@Validated
@Data
public class CriteriaDetailsDto {

  @JsonProperty("resource")
  private String resource;

  @JsonProperty("type")
  private ExternalEventType type;
}
