package com.hp.stratus.pendingassociations.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;

/** State of the association */
@AllArgsConstructor
public enum State {
  @JsonProperty("open")
  OPEN("open"),
  @JsonProperty("pending")
  PENDING("pending"),
  @JsonProperty("cancelled")
  CANCELLED("cancelled"),
  @JsonProperty("completed")
  COMPLETED("completed");

  @Getter private final String value;

  public static State fromValue(String text) {
    for (State s : State.values()) {
      if (s.getValue().equals(text)) {
        return s;
      }
    }
    return null;
  }
}
