package com.hp.stratus.pendingassociations.action.updateMetadata;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.action.ActionExecutor;
import com.hp.stratus.pendingassociations.exceptions.ActionExecutionException;
import com.hp.stratus.pendingassociations.exceptions.ResourceResolutionException;
import com.hp.stratus.pendingassociations.model.Action;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.Operation;
import com.hp.stratus.pendingassociations.model.ResourceId;
import com.hp.stratus.pendingassociations.repository.ActionRepository;
import com.hp.stratus.pendingassociations.repository.AssociationRepository;
import com.hp.stratus.pendingassociations.service.EventService;
import com.hp.stratus.pendingassociations.utils.PathResolver;
import com.hp.stratus.pendingassociations.utils.ResourceUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.NotImplementedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Executor for update-metadata actions. */
@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
@Slf4j
public class UpdateMetadataExecutor implements ActionExecutor {

  /** Repository to use for DB actions. */
  private final AssociationRepository associationRepository;

  /** The action repository for updating actions in the DB. */
  private final ActionRepository actionRepository;

  /** The object mapper to use for extracting resource details. */
  private final ObjectMapper objectMapper;

  /** The path resolver to use for json path resources. */
  private final PathResolver pathResolver;

  /** The service for firing events. */
  private final EventService eventService;

  /**
   * Indicates that this executor only supports the associate operation.
   *
   * @return The association operation.
   */
  @Override
  public Operation getOperation() {
    return Operation.UPDATE_METADATA;
  }

  /**
   * Executes the associate action, handing the resource off to the relevant sub-executor.
   *
   * @param association The association.
   * @param action The action to execute.
   * @param actionIndex The index of the action.
   * @throws ResourceResolutionException Thrown when resource resolution fails.
   * @throws NotImplementedException Thrown if an unsupported resource is supplied.
   * @throws ActionExecutionException Thrown if the action fails.
   */
  @Override
  public void execute(Association association, Action action, int actionIndex)
      throws ResourceResolutionException, ActionExecutionException {

    // Associate actions only accepts multiple resources
    if (action.getResources() == null) {
      throw new ResourceResolutionException(
          "Only multiple resource definitions are allowed for update metadata actions");
    }

    if (action.getResources().getUntypedResources() == null
        || action.getResources().getUntypedResources().isEmpty()) {
      throw new ResourceResolutionException(
          "One or more resources must be supplied in update metadata actions");
    }

    try {

      // If we have no metadata in the association, initialize the map
      if (association.getMetadata() == null) {
        association.setMetadata(new HashMap<>());
      }

      // Loop over the resources in the action
      for (Map.Entry<String, ResourceId> resource :
          action.getResources().getUntypedResources().entrySet()) {

        // Resolve the resource and add it to the metadata
        association
            .getMetadata()
            .put(
                resource.getKey(),
                ResourceUtils.resolveResource(
                    objectMapper, pathResolver, association, resource.getValue()));
      }

      // Save the updates
      associationRepository.save(association);

      // And resolve the action
      log.info(
          "Successfully updated metadata for action {} in association {}",
          actionIndex,
          association.getId());
      resolveAction(association.getId(), actionIndex, null);

    } catch (Exception e) {
      log.warn("Error when updating metadata for association {}: ", association.getId(), e);
      throw new ActionExecutionException(
          false, "Error when updating metadata for association " + association.getId());
    }
  }

  /**
   * Resolves the supplied action and fires the next action event.
   *
   * @param associationId The association ID.
   * @param actionIndex The action index to resolve.
   * @param resolutionObject The resolution object to use.
   */
  private void resolveAction(UUID associationId, int actionIndex, Object resolutionObject) {

    // Update the action
    boolean resolved = actionRepository.resolveAction(associationId, actionIndex, resolutionObject);
    if (!resolved) {
      log.warn("Failed to find action {} for association {}", actionIndex, associationId);
      return;
    }

    // Fire off the event to execute the next action
    eventService.publishExecuteNextAction(associationId);
  }
}
