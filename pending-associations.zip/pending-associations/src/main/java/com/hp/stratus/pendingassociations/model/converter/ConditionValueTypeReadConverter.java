package com.hp.stratus.pendingassociations.model.converter;

import com.hp.stratus.pendingassociations.model.ConditionValueType;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;

@ReadingConverter
public class ConditionValueTypeReadConverter implements Converter<String, ConditionValueType> {

  @Override
  public ConditionValueType convert(String source) {
    return ConditionValueType.fromValue(source);
  }
}
