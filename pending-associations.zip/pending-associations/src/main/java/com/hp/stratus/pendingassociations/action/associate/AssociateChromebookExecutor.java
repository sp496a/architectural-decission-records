package com.hp.stratus.pendingassociations.action.associate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.http.client.utils.HttpClient;
import com.hp.stratus.pendingassociations.dto.client.ChromebookClaimRequest;
import com.hp.stratus.pendingassociations.dto.client.PcManufacturingCatalogDevice;
import com.hp.stratus.pendingassociations.dto.client.PcManufacturingCatalogResponse;
import com.hp.stratus.pendingassociations.exceptions.ActionExecutionException;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.Resource;
import com.hp.stratus.pendingassociations.model.ResourceType;
import com.hp.stratus.pendingassociations.repository.ActionRepository;
import com.hp.stratus.pendingassociations.service.EventService;
import com.hp.stratus.pendingassociations.utils.PathResolver;
import com.hp.stratus.pendingassociations.utils.ResourceUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

/** A simple executor for printer association actions. */
@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
@Slf4j
public class AssociateChromebookExecutor implements AssociateResourceExecutor {

  /** The object mapper to use for extracting resource details. */
  private final ObjectMapper objectMapper;

  /** The path resolver to use for json path resources. */
  private final PathResolver pathResolver;

  /** The action repository for updating actions in the DB. */
  private final ActionRepository actionRepository;

  /** The service for firing events. */
  private final EventService eventService;

  /** Basic HTTP client. */
  private final HttpClient client;

  /** Supplier for JWT tokens. */
  @Qualifier("jwtSupplier")
  private final Supplier<String> jwtSupplier;

  /** Base URL for stratus services. */
  @Value("${chromebook.device.base.url}")
  private final String baseUrl;

  /** Endpoint for device ownership. */
  @Value("${chromebook.device.ownership.endpoint}")
  private final String ownershipEndpoint;

  /** Base url to PC Manufacturing. */
  @Value("${pc.manufacturing.base.url}")
  private final String pcManufacturingBaseUrl;

  /** Endpoint to get device detail from PC Manufacturing. */
  @Value("${pc.manufacturing.device.endpoint}")
  private final String pcManufacturingDeviceEndpoint;

  /**
   * Indicates that this executor only supports a chromebook resource type.
   *
   * @return The chromebook resource type.
   */
  public ResourceType getResourceType() {
    return ResourceType.CHROMEBOOK;
  }

  /**
   * Executes the association.
   *
   * @param deviceResource The device resource.
   * @param association The association to execute the action on.
   * @param actionIndex The index of the action to execute.
   * @throws ActionExecutionException Thrown if execution fails.
   */
  public void execute(Resource deviceResource, Association association, int actionIndex)
      throws ActionExecutionException {
    log.debug(
        "Executing association action {} for association {}", actionIndex, association.getId());

    // Resolve the serial number from the device resource
    String serial =
        ResourceUtils.resolveResource(
            objectMapper, pathResolver, association, deviceResource.getSerial());

    // Extract the model from the device resource
    String model =
        ResourceUtils.resolveResource(
            objectMapper, pathResolver, association, deviceResource.getModel());

    // Get the device id from pc manufacturing
    String deviceId = getDeviceUniqueId(serial, model);

    // Construct the registration URI
    String uri = UriComponentsBuilder.fromUriString(baseUrl).path(ownershipEndpoint).toUriString();

    // Build the request
    ChromebookClaimRequest req =
        ChromebookClaimRequest.builder()
            .deviceUniqueId(deviceId)
            .tenantId(association.getTenantId())
            .build();

    // Make the request
    try {
      ResponseEntity<Map<String, Object>> response =
          client.post(uri, jwtSupplier.get(), req, new ParameterizedTypeReference<>() {});
      log.info("Successfully completed claim action for chromebook {}", deviceId);
      resolveAction(association.getId(), actionIndex, response.getBody());
    } catch (HttpClientErrorException e) {
      handleClientError(
          HttpStatus.valueOf(e.getStatusCode().value()),
          deviceId,
          association.getId(),
          actionIndex);
    } catch (HttpServerErrorException e) {
      handleServerError(HttpStatus.valueOf(e.getStatusCode().value()), deviceId);
    } catch (Exception e) {
      handleNetworkError(deviceId, e.getMessage());
    }
  }

  /**
   * Resolves the supplied action and fires the next action event.
   *
   * @param associationId The association ID.
   * @param actionIndex The action index to resolve.
   * @param resolutionObject The resolution object to use.
   */
  private void resolveAction(UUID associationId, int actionIndex, Object resolutionObject) {

    // Update the action
    boolean resolved = actionRepository.resolveAction(associationId, actionIndex, resolutionObject);
    if (!resolved) {
      log.warn("Failed to find action {} for association {}", actionIndex, associationId);
      return;
    }

    // Fire off the event to execute the next action
    eventService.publishExecuteNextAction(associationId);
  }

  /**
   * Handles a 4xx client error during claim.
   *
   * @param status The status code.
   * @param deviceId The device ID.
   * @param associationId The association ID.
   * @param actionIndex The index of the action.
   * @throws ActionExecutionException if the client error caused the execution to fail.
   */
  private void handleClientError(
      HttpStatus status, String deviceId, UUID associationId, int actionIndex)
      throws ActionExecutionException {

    // If the status is anything but a conflict, we can't complete the association or retry
    if (status != HttpStatus.CONFLICT) {
      log.warn("Failed to initiate claim for chromebook {}: Response code={}", deviceId, status);
      throw new ActionExecutionException(
          false, "Client error when initiating claim for chromebook " + deviceId);
    }

    // The status is a conflict, resolve it with a resolution object indicating that
    log.info("chromebook with ID {} is already claimed, resolving...", deviceId);
    Map<String, Object> resolution =
        Map.of("message", "chromebook with ID " + deviceId + " is already claimed");
    resolveAction(associationId, actionIndex, resolution);
    log.info("Successfully completed claim action for chromebook {}", deviceId);
  }

  /**
   * Handles a 5xx server error during claim.
   *
   * @param status The status code.
   * @param deviceId The device ID.
   * @throws ActionExecutionException Indicating that the action execution failed.
   */
  private void handleServerError(HttpStatus status, String deviceId)
      throws ActionExecutionException {
    log.warn(
        "Failed to initiate claim for chromebook {}: Response code={}. Retrying...",
        deviceId,
        status);
    throw new ActionExecutionException(
        true, "Server error when initiating claim for chromebook " + deviceId);
  }

  /**
   * Handles a network error during claim.
   *
   * @param deviceId The device ID.
   * @throws ActionExecutionException Indicating that action execution failed.
   */
  private void handleNetworkError(String deviceId, String message) throws ActionExecutionException {
    log.warn("Failed to initiate claim for chromebook {}: {} Retrying...", deviceId, message);
    throw new ActionExecutionException(
        true, "Network error when initiating claim for chromebook " + deviceId);
  }

  /**
   * Gets the device unique ID from the PC manufacturing catalog.
   *
   * @param serialNumber The device's serial number
   * @param productNumber The device's product number
   * @return device UniqueId
   * @throws ActionExecutionException If fetching the details fails.
   */
  private String getDeviceUniqueId(String serialNumber, String productNumber)
      throws ActionExecutionException {

    // Construct the pc manufacturing URI
    URI uri =
        UriComponentsBuilder.fromUriString(pcManufacturingBaseUrl)
            .path(pcManufacturingDeviceEndpoint)
            .query("serialNumber=" + serialNumber)
            .query("productNumber=" + productNumber)
            .build()
            .toUri();

    // Make the request
    ResponseEntity<PcManufacturingCatalogResponse> response;
    try {
      response = client.get(uri, jwtSupplier.get(), new ParameterizedTypeReference<>() {});
    } catch (HttpClientErrorException e) {
      log.warn(
          "Client error when retrieving device with serial number {}, product number {} :",
          serialNumber,
          productNumber,
          e);
      throw new ActionExecutionException(
          false,
          "Client error when retrieving device details for device with serial number "
              + serialNumber);
    } catch (HttpServerErrorException e) {
      log.warn(
          "Server error when retrieving device details for device with serial number {} and product number {}:",
          serialNumber,
          productNumber,
          e);
      throw new ActionExecutionException(
          true,
          "Server error when retrieving device details for device with serial number "
              + serialNumber);
    } catch (Exception e) {
      log.warn(
          "Network error when retrieving device details for device with serial number {} and product number {}:",
          serialNumber,
          productNumber,
          e);
      throw new ActionExecutionException(
          true,
          "Network error when retrieving device details for device with serial number "
              + serialNumber);
    }

    // Check that we have devices
    PcManufacturingCatalogResponse deviceDetail = response.getBody();
    if (deviceDetail == null) {
      log.warn(
          "Received an empty response from PC MFG for serial number {} and product number {}: ",
          serialNumber,
          productNumber);
      throw new ActionExecutionException(
          false,
          "Received an empty response from PC MFG for device with serial number" + serialNumber);
    }

    PcManufacturingCatalogDevice device =
        deviceDetail.getDevices().stream().findFirst().orElse(null);
    if (device == null) {
      log.warn(
          "Received an empty device list from PC MFG for device with serial number {} and product number {}:",
          serialNumber,
          productNumber);
      throw new ActionExecutionException(
          false,
          "Received an empty device list from PC MFG for device with serial number "
              + serialNumber);
    }

    return device.getDeviceUniqueId();
  }
}
