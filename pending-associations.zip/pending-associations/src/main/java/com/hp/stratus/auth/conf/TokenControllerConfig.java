package com.hp.stratus.auth.conf;

import com.hp.stratus.TokenValidatorFactory;
import com.hp.stratus.config.TokenValidatorConfig;
import com.hp.stratus.controller.TokenValidatorController;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
@EnableAutoConfiguration
public class TokenControllerConfig {

  /**
   * Create bean TokenValidatorController for JwtOfflineAuthValidator
   *
   * @param issuer : hp authz jwt issuer-uri
   * @param svcName: service name of application registered in hp authz
   */
  @Bean
  public TokenValidatorController createTokenValidatorController(
      @Value("${spring.security.oauth2.resourceserver.jwt.issuer-uri:NO_ISSUER}") String issuer,
      @Value("${authz.service.name:HP_BOX1_DUMMY}") String svcName) {
    log.debug(
        "spring.security.oauth2.resourceserver.jwt.issuer-uri={}, authz.service.name={} ",
        issuer,
        svcName);
    return TokenValidatorFactory.getTokenValidatorController(
        new TokenValidatorConfig(issuer, svcName, null), null);
  }
}
