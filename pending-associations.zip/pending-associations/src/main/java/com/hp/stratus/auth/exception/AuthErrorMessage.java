package com.hp.stratus.auth.exception;

import lombok.*;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class AuthErrorMessage {
  private String code;
  private String message;
}
