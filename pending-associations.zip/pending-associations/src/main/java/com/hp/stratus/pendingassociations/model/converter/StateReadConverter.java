package com.hp.stratus.pendingassociations.model.converter;

import com.hp.stratus.pendingassociations.model.State;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;

@ReadingConverter
public class StateReadConverter implements Converter<String, State> {

  @Override
  public State convert(String source) {
    return State.fromValue(source);
  }
}
