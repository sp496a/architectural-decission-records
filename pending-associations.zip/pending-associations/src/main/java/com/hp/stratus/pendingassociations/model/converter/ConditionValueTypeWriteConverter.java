package com.hp.stratus.pendingassociations.model.converter;

import com.hp.stratus.pendingassociations.model.ConditionValueType;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.WritingConverter;

@WritingConverter
public class ConditionValueTypeWriteConverter implements Converter<ConditionValueType, String> {

  @Override
  public String convert(ConditionValueType source) {
    return source.getValue();
  }
}
