package com.hp.stratus.pendingassociations.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Information about a pending association */
@Data
@Document("association")
public class Association {
  @Id private UUID id;
  private State state;
  private String tenantId;
  private List<Action> actions;
  private List<Criteria> criteria;
  private Map<String, Object> metadata;
}
