package com.hp.stratus.pendingassociations.dto;

import jakarta.validation.constraints.NotNull;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.util.Optional;

/** Pageable object with searching. */
public class OffsetSearchPageRequest implements Pageable {

  /** Default search value. */
  private static final Sort DEFAULT_SORT = Sort.by(Sort.Direction.DESC, "id");

  /** Desired query offset. */
  private final int offset;

  /** Desired query limit. */
  private final int limit;

  /** Desired sort. */
  private final Sort sort;

  /** Desired search string */
  private final String search;

  /**
   * Constructs the request.
   *
   * @param offset The offset.
   * @param pageSize The page size.
   * @param sort The sortint to apply.
   * @param search The search to apply.
   */
  public OffsetSearchPageRequest(int offset, int pageSize, Sort sort, String search) {
    this.offset = offset;
    this.limit = pageSize;
    this.sort = Optional.ofNullable(sort).orElse(DEFAULT_SORT);
    this.search = Optional.ofNullable(search).orElse("");
  }

  /**
   * Gets the current page number.
   *
   * @return The page number.
   */
  @Override
  public int getPageNumber() {
    return offset / limit;
  }

  /**
   * Gets the current page size.
   *
   * @return The page size.
   */
  @Override
  public int getPageSize() {
    return limit;
  }

  /**
   * Gets the current offset.
   *
   * @return The offset.
   */
  @Override
  public long getOffset() {
    return offset;
  }

  /**
   * Gets the current sort.
   *
   * @return The sort.
   */
  @NotNull
  @Override
  public Sort getSort() {
    return sort;
  }

  /**
   * Gets the current search.
   *
   * @return The search.
   */
  public String getSearch() {
    return search;
  }

  /**
   * Constructs the request for the next page.
   *
   * @return The next page request.
   */
  @NotNull
  @Override
  public Pageable next() {
    return new OffsetSearchPageRequest(
        (int) (getOffset() + getPageSize()), getPageSize(), getSort(), getSearch());
  }

  /**
   * Constructs the request for the previous page.
   *
   * @return The previous page request.
   */
  public Pageable previous() {
    return hasPrevious()
        ? new OffsetSearchPageRequest(
            (int) (getOffset() - getPageSize()), getPageSize(), getSort(), getSearch())
        : this;
  }

  /**
   * Constructs the request for previous (or first) page.
   *
   * @return The nest page request.
   */
  @NotNull
  @Override
  public Pageable previousOrFirst() {
    return hasPrevious() ? previous() : first();
  }

  /**
   * Constructs the request for the first page.
   *
   * @return The first page request.
   */
  @NotNull
  @Override
  public Pageable first() {
    return new OffsetSearchPageRequest(0, getPageSize(), getSort(), getSearch());
  }

  /**
   * Unimplemented.
   *
   * @param pageNumber The page number.
   * @return The request for that page.
   */
  @NotNull
  @Override
  public Pageable withPage(int pageNumber) {
    return new OffsetSearchPageRequest(0, 0, null, null);
  }

  /**
   * Determines if there's a previous page.
   *
   * @return true if there's a previous page.
   */
  @Override
  public boolean hasPrevious() {
    return offset > limit;
  }
}
