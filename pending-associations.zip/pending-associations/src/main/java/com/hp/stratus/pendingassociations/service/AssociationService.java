package com.hp.stratus.pendingassociations.service;

import com.hp.stratus.pendingassociations.dto.*;
import com.hp.stratus.pendingassociations.exceptions.BadGatewayException;
import com.hp.stratus.pendingassociations.exceptions.BadRequestException;
import com.hp.stratus.pendingassociations.model.Association;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;

import java.util.UUID;

public interface AssociationService {

  /**
   * Creates a new association.
   *
   * @param createAssociationRequest Request used to create the association.
   * @return The creation response.
   */
  CreateAssociationResponse create(CreateAssociationRequest createAssociationRequest);

  /**
   * @param id unique id representing the association
   * @return AssociationDto response DTO object
   */
  AssociationDto get(UUID id);

  /**
   * @param id unique id representing the association
   * @param putAssociationRequest the put association request DTO object
   * @return PutAssociationResponse put association response DTO object
   */
  PutAssociationResponse put(UUID id, PutAssociationRequest putAssociationRequest);

  /**
   * Deletes the association with the supplied ID.
   *
   * @param uuid The association ID.
   * @return The count of deleted records.
   */
  long delete(UUID uuid);

  /**
   * Patches the association with the supplied ID.
   *
   * @param UUID The association ID.
   * @param patchAssociationRequest The patch request.
   * @return The updated association response.
   */
  PatchAssociationResponse patch(UUID UUID, PatchAssociationRequest patchAssociationRequest);

  /**
   * @param offset Offset of first item to return in result set.
   * @param limit Max limit of items to return in payload.
   * @param sort Sorting to use in pagination.
   * @param search Key:Value pair string used for generic search
   * @return {@link Page} of {@link AssociationDto}
   */
  Page<AssociationDto> getPaginatedAssociationList(int offset, int limit, Sort sort, String search);

  /**
   * Retrieve count range
   *
   * @param offset The offset to begin the page
   * @param limit The size of the page to return
   * @return Content range
   */
  String head(int offset, int limit);

  /**
   * Completes the supplied association.
   *
   * @param association The association to complete.
   */
  void completeAssociation(Association association);

  /**
   * Cancels the supplied association.
   *
   * @param association The association to cancel.
   */
  void cancelAssociation(Association association);

  /**
   * Fires an association update event to the rest of stratus.
   *
   * @param associationId The association ID.
   * @throws BadGatewayException When event management responds with a 5xx.
   * @throws BadRequestException When event management responds with a non-5xx error.
   */
  void fireAssociationUpdate(UUID associationId) throws BadGatewayException, BadRequestException;
}
