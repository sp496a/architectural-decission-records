package com.hp.stratus.pendingassociations.utils;

import com.hp.stratus.pendingassociations.dto.*;
import com.hp.stratus.pendingassociations.model.Action;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.Criteria;
import com.hp.stratus.pendingassociations.model.State;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.modelmapper.ModelMapper;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/** Maps between association models and DTOs. */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public abstract class AssociationMapper {

  /** Mapper to use internally. */
  private static final ModelMapper modelMapper = new ModelMapper();

  /**
   * Converts an association model to an association DTO.
   *
   * @param association The association model.
   * @return The association DTO.
   */
  public static AssociationDto toAssociationDto(Association association) {
    return toDto(association, AssociationDto.class);
  }

  /**
   * Converts an association model to a CreateAssociationResponse DTO.
   *
   * @param model The association model object from the database.
   * @return The DTO object.
   */
  public static CreateAssociationResponse toCreateAssociationResponse(Association model) {
    return toDto(model, CreateAssociationResponse.class);
  }

  /**
   * Converts an association model to a PatchAssociationResponse DTO.
   *
   * @param model The association model object from the database.
   * @return The DTO object.
   */
  public static PatchAssociationResponse toPatchAssociationResponse(Association model) {
    return toDto(model, PatchAssociationResponse.class);
  }

  /**
   * Converts an association model to a PatchAssociationResponse DTO.
   *
   * @param model The association model object from the database.
   * @return The DTO object.
   */
  public static PutAssociationResponse toPutAssociationResponse(Association model) {
    return toDto(model, PutAssociationResponse.class);
  }

  /**
   * Converts a CreateAssociationRequest DTO to an Association model.
   *
   * @param request Request DTO.
   * @return Association model object.
   */
  public static Association toModel(AssociationUpdateDto request) {

    // If we have no request, return null
    if (request == null) {
      return null;
    }

    // Create the association
    Association association = new Association();
    association.setTenantId(request.getTenantId());
    association.setActions(toActionModels(request.getActions()));
    association.setCriteria(toCriteriaModels(request.getCriteria()));
    association.setState(toStateModel(request.getState()));
    association.setMetadata(request.getMetadata());

    return association;
  }

  /**
   * Converts a list of Association actions DTOs to a list of action models.
   *
   * @param actionsDtos The action DTOs.
   * @return The list of action models.
   */
  public static List<Action> toActionModels(List<AssociationUpdateActionsDto> actionsDtos) {

    // If there are no actions, return an empty list
    if (actionsDtos == null || actionsDtos.isEmpty()) {
      return new ArrayList<>();
    }

    // Map each action
    return actionsDtos.stream()
        .map(dto -> modelMapper.map(dto, Action.class))
        .collect(Collectors.toList());
  }

  /**
   * Converts a list of criteria update DTOs to a list of criteria models.
   *
   * @param criteriaDtos The DTOs to convert.
   * @return The criteria model list.
   */
  public static List<Criteria> toCriteriaModels(List<CriteriaUpdateDto> criteriaDtos) {

    // If there are no criteria, return an empty list
    if (criteriaDtos == null || criteriaDtos.isEmpty()) {
      return new ArrayList<>();
    }

    // Map each criteria
    return criteriaDtos.stream()
        .map(AssociationMapper::toCriteriaModel)
        .collect(Collectors.toList());
  }

  /**
   * Converts a state DTO to a State model.
   *
   * @param dto The state DTO.
   * @return The state model.
   */
  public static State toStateModel(com.hp.stratus.pendingassociations.dto.State dto) {

    // Nothing to map, return null
    if (dto == null) {
      return null;
    }

    // Map the state
    return State.fromValue(dto.getValue());
  }

  /**
   * Converts a criteria update DTO to a criteria model.
   *
   * @param dto The DTO to convert.
   * @return The criteria model.
   */
  private static Criteria toCriteriaModel(CriteriaUpdateDto dto) {
    return modelMapper.map(dto, Criteria.class);
  }

  /**
   * Converts the supplied association model to the specified DTO type.
   *
   * @param model The association model.
   * @param dtoType The requested type.
   * @param <T> Generic type.
   * @return The mapped DTO.
   */
  private static <T> T toDto(Association model, Class<T> dtoType) {

    // If the model is null, return null
    if (model == null) {
      return null;
    }

    // Otherwise, map it
    return modelMapper.map(model, dtoType);
  }
}
