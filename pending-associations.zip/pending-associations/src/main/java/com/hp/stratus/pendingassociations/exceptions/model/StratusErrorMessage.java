package com.hp.stratus.pendingassociations.exceptions.model;

import lombok.*;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class StratusErrorMessage {
  private String code;
  private String message;

  public static final String PAGINATION_SORTBY_FORMAT_ERROR_MESSAGE =
      "sortby format is not correct";
  public static final String PAGINATION_OffSET_ERROR_MESSAGE = "Offset cannot be negative";
  public static final String PAGINATION_lIMIT_ERROR_MESSAGE = "Limit cannot be < 1";
}
