package com.hp.stratus.pendingassociations.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.util.Arrays;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

/** Gets or Sets resourceType */
@AllArgsConstructor
public enum ResourceType {
  PRINTER("printer"),
  PC("pc"),
  USER("user"),
  CHROMEBOOK("chromebook");

  @Getter @JsonValue private final String value;

  @JsonCreator
  public static ResourceType fromValue(String text) {
    return Arrays.stream(values())
        .filter(val -> StringUtils.equalsIgnoreCase(val.getValue(), text))
        .findAny()
        .orElse(null);
  }
}
