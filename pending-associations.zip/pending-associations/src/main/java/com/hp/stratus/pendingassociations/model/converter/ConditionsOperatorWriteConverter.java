package com.hp.stratus.pendingassociations.model.converter;

import com.hp.stratus.pendingassociations.model.ConditionsOperator;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.WritingConverter;

@WritingConverter
public class ConditionsOperatorWriteConverter implements Converter<ConditionsOperator, String> {

  @Override
  public String convert(ConditionsOperator source) {
    return source.getValue();
  }
}
