/*-
 * Copyright (c) 2021, HP Development Company, L.P. All rights reserved.
 * This software contains confidential and proprietary information of HP.
 * The user of this software agrees not to disclose, disseminate or copy
 * such Confidential Information and shall use the software only in accordance
 * with the terms of the license agreement the user entered into with HP.
 */
package com.hp.stratus.pendingassociations.utils;

import com.hp.stratus.pendingassociations.exceptions.PendingAssociationException;
import com.hp.stratus.pendingassociations.exceptions.model.StratusErrorMessage;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.http.HttpStatus;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/** Custom Jackson data converter utils */
public class DataConverterUtils {
  private DataConverterUtils() {}

  /**
   * Convert a list of sort strings into {@link Sort}.
   *
   * @param sortStrings list of sort strings
   * @return Sort {@link Sort}
   */
  public static Sort convertToSort(List<String> sortStrings) {
    if (CollectionUtils.isEmpty(sortStrings)) {
      return null;
    }
    final List<Order> orders = new ArrayList<>();
    try {
      sortStrings.forEach(
          sortString -> {
            String[] splitedStrings = sortString.split(":");
            if (splitedStrings.length > 1) {
              // sort string contains "field:direction"
              orders.add(
                  new Order(
                      Direction.fromString(splitedStrings[1].trim()), splitedStrings[0].trim()));
            } else {
              // sort string contains "field"
              orders.add(new Order(Direction.ASC, splitedStrings[0].trim()));
            }
          });
    } catch (IllegalArgumentException illegalArgumentException) {
      throw new PendingAssociationException(
          StratusErrorMessage.PAGINATION_SORTBY_FORMAT_ERROR_MESSAGE, HttpStatus.BAD_REQUEST);
    }

    return Sort.by(orders);
  }
}
