package com.hp.stratus.pendingassociations.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hp.stratus.pendingassociations.model.ResourceIdType;
import lombok.Data;

@Data
public class ResourceIdDto {
  @JsonProperty("type")
  private ResourceIdType type;

  @JsonProperty("value")
  private String value;
}
