package com.hp.stratus.pendingassociations.model.converter;

import com.hp.stratus.pendingassociations.model.CriteriaState;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;

@ReadingConverter
public class CriteriaStateReadConverter implements Converter<String, CriteriaState> {

  @Override
  public CriteriaState convert(String source) {
    return CriteriaState.fromValue(source);
  }
}
