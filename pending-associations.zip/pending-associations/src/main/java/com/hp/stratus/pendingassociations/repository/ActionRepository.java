package com.hp.stratus.pendingassociations.repository;

import java.util.UUID;

/** Repository for actions related to association actions. */
public interface ActionRepository {

  /**
   * Resolves an action based on its index.
   *
   * @param associationId The association ID.
   * @param actionIndex The index of the action.
   * @param resolutionObject The resolution object to set.
   * @return The number of updated records.
   */
  boolean resolveAction(UUID associationId, int actionIndex, Object resolutionObject);
}
