package com.hp.stratus.pendingassociations.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hp.stratus.pendingassociations.model.ConditionComparator;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import org.springframework.validation.annotation.Validated;


@Validated
@Data
public class ConditionDto {

  @JsonProperty("value1")
  @NotNull
  private ConditionValueDto value1;

  @JsonProperty("value2")
  @NotNull
  private ConditionValueDto value2;

  @JsonProperty("comparator")
  @NotNull
  private ConditionComparator comparator;
}
