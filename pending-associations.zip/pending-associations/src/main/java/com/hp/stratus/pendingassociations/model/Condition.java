package com.hp.stratus.pendingassociations.model;

import lombok.Data;

/** Condition value to compare */
@Data
public class Condition {
  private ConditionValue value1;
  private ConditionValue value2;
  private ConditionComparator comparator;
}
