package com.hp.stratus.pendingassociations.consumer.external;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.action.associate.AssociatePcExecutor;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventAttribute;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventEnvelope;
import com.hp.stratus.pendingassociations.service.EventService;
import com.hp.stratus.pendingassociations.utils.EventUtils;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.stereotype.Component;

import java.util.Map;

/** A basic abstract consumer for events, indicating the type of events it handles. */
@Component
@Slf4j
@RequiredArgsConstructor
public class PcClaimAddedConsumer implements ExternalEventConsumer {

  /** The pc unique id key name. */
  private static final String DEVICE_UNIQUE_ID_KEY = "deviceUniqueId";

  /** Service for evaluating criteria. */
  private final AssociatePcExecutor associatePcExecutor;

  /** Service for subscribing to events. */
  private final EventService eventService;

  /** JSON Mapper. */
  private final ObjectMapper objectMapper;

  /** Indicates the resource name this consumer handles. */
  @Override
  public ExternalEventResource eventResource() {
    return ExternalEventResource.PC_CLAIM;
  }

  /** Indicates the event types this consumer handles. */
  @Override
  public ExternalEventType eventType() {
    return ExternalEventType.ADDED;
  }

  /** Subscribe automatically to the required resource. */
  @PostConstruct
  public void subscribeToResource() {
    eventService.subscribeToResource(eventResource());
  }

  @Override
  public void handleEvent(StratusEventEnvelope event) {

    // Extract the event object attribute
    StratusEventAttribute eventObject = EventUtils.getEventObjectAttribute(event);
    if (eventObject == null) {
      log.warn("No event object found in pc claim event, ignoring...");
      throw new AmqpRejectAndDontRequeueException("No event object found in PC claim event");
    }

    // Parse the resolution object into a map
    Map<String, Object> resolutionObject = EventUtils.getEventDetailMap(objectMapper, eventObject);
    if (resolutionObject == null) {
      log.warn("Failed to read pc claim event details into a map, ignoring...");
      throw new AmqpRejectAndDontRequeueException(
          "Failed to read pc claim event details into a map");
    }

    // Extract the deviceUnique ID attribute
    Object deviceUniqueId = resolutionObject.get(DEVICE_UNIQUE_ID_KEY);

    // Check if device unique id is null or type String and it's not empty or blank
    // If once of these check fails, then reject event and move on without DLQ
    if (deviceUniqueId == null
        || deviceUniqueId.toString().isEmpty()
        || deviceUniqueId.toString().isBlank()) {
      log.warn("Failed to extract pc Serial Number from pc claim event, ignoring...");
      throw new AmqpRejectAndDontRequeueException(
          "Failed to extract device ID from pc claim event");
    }

    // Complete the claim action
    associatePcExecutor.completeClaim(deviceUniqueId.toString(), resolutionObject);
  }
}