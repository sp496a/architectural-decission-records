package com.hp.stratus.pendingassociations.config;

import com.hp.stratus.library.log.ILogger;
import com.hp.stratus.library.log.LoggerFactory;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** Configuration for logging. */
@Configuration
@RequiredArgsConstructor
public class LoggingConfig {

  /** The service name. */
  @Value("${authz.service.name}")
  private final String serviceName;

  /**
   * Initialize LoggerFactory bean
   *
   * @return LoggerFactory
   */
  @Bean
  public LoggerFactory loggerFactory() {
    return new LoggerFactory();
  }

  /**
   * Initialize ILogger bean
   *
   * @return ILogger
   */
  @Bean
  public ILogger iLogger(LoggerFactory loggerFactory) {
    return loggerFactory.getLogger(serviceName);
  }
}
