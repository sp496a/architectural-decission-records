package com.hp.stratus.pendingassociations.dto.client;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

/** Basic wrapper for pc claim data. */
@Data
@Builder
public class ChromebookClaimRequest {

  @JsonProperty("deviceUniqueId")
  private String deviceUniqueId;

  @JsonProperty("tenantId")
  private String tenantId;
}
