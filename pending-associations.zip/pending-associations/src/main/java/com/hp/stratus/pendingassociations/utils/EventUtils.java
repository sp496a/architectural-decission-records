package com.hp.stratus.pendingassociations.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventAttribute;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventEnvelope;

import javax.json.Json;
import javax.json.JsonException;
import javax.json.JsonReader;
import javax.json.JsonStructure;
import java.io.StringReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** A simple utility class for common event operations. */
public class EventUtils {

  /** Helper constant for extracting event objects. */
  private static final String EVENT_OBJECT_KEY = "eventObject";

  /**
   * Gets the event object attribute in the event.
   *
   * @return The event attribute, or null if not found.
   */
  public static StratusEventAttribute getEventObjectAttribute(StratusEventEnvelope envelope) {
    return getEventAttribute(envelope, EVENT_OBJECT_KEY);
  }

  /**
   * Gets the event attribute with the provided key from the provided envelope.
   *
   * @param envelope The event envelope.
   * @param key The key.
   * @return The event attribute.
   */
  public static StratusEventAttribute getEventAttribute(StratusEventEnvelope envelope, String key) {
    return envelope.getEventAttributeValueMap() != null
        ? envelope.getEventAttributeValueMap().get(key)
        : null;
  }

  /**
   * Gets event details as a JSON structure.
   *
   * @param attribute The event attribute.
   * @return The json structure, or null if parsing fails.
   */
  public static JsonStructure getEventDetailStructure(StratusEventAttribute attribute) {

    // Handle missing event details gracefully
    if (attribute.getStringValue() == null) {
      return null;
    }

    // Read in the JSON
    try (JsonReader reader = Json.createReader(new StringReader(attribute.getStringValue()))) {
      return reader.read();
    } catch (JsonException e) {
      return null;
    }
  }

  /**
   * Gets event details as a map.
   *
   * @param objectMapper The object mapper to use.
   * @param attribute The attribute to parse.
   * @return The map, or null if parsing fails.
   */
  public static Map<String, Object> getEventDetailMap(
      ObjectMapper objectMapper, StratusEventAttribute attribute) {

    // Handle missing event details gracefully
    if (attribute.getStringValue() == null) {
      return null;
    }

    // Read in the JSON
    try {
      return objectMapper.readValue(attribute.getStringValue(), Map.class);
    } catch (JsonProcessingException e) {
      return null;
    }
  }

  /**
   * Converts an event object to standard map.
   *
   * @param mapper The object mapper to use for parsing JSON.
   * @param envelope The event envelope.
   * @return The event envelope map.
   */
  public static Map<String, Object> getEventAttributeMap(
      ObjectMapper mapper, StratusEventEnvelope envelope) {

    // Map the event attributes, we can't use a stream here because parseEventAttribute can return
    // null
    Map<String, Object> mappedValues = new HashMap<>();
    for (Map.Entry<String, StratusEventAttribute> entry :
        envelope.getEventAttributeValueMap().entrySet()) {
      mappedValues.put(entry.getKey(), parseEventAttribute(mapper, entry.getValue()));
    }

    return mappedValues;
  }

  /**
   * Parses an event attribute into a standard object.
   *
   * @param objectMapper The mapper to use for JSON payloads
   * @param attribute The attribute to parse.
   * @return The parsed object.
   */
  public static Object parseEventAttribute(
      ObjectMapper objectMapper, StratusEventAttribute attribute) {

    // Handle missing event details gracefully
    if (attribute.getStringValue() == null) {
      return null;
    }

    // Attempt to read it in as a map
    try {
      return objectMapper.readValue(attribute.getStringValue(), Map.class);
    } catch (JsonProcessingException e) {
      // Ignore
    }

    // Attempt to read it in as a list
    try {
      return objectMapper.readValue(attribute.getStringValue(), List.class);
    } catch (JsonProcessingException e) {
      // Ignore
    }

    // Read it as a raw string
    return attribute.getStringValue();
  }

  /**
   * Converts the supplied map into a JSON structure.
   *
   * @param mapper The object mapper to use.
   * @param map The map to convert.
   * @return The JSON structure.
   */
  public static JsonStructure convertToJsonStructure(ObjectMapper mapper, Map<String, Object> map) {

    // TODO: this is horribly inefficient and can be improved
    try (JsonReader reader = Json.createReader(new StringReader(mapper.writeValueAsString(map)))) {
      return reader.read();
    } catch (JsonException | JsonProcessingException e) {
      return null;
    }
  }
}
