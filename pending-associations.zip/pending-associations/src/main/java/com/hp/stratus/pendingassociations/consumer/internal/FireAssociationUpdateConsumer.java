package com.hp.stratus.pendingassociations.consumer.internal;

import com.hp.stratus.pendingassociations.dto.event.internal.InternalEvent;
import com.hp.stratus.pendingassociations.dto.event.internal.InternalEventType;
import com.hp.stratus.pendingassociations.exceptions.BadRequestException;
import com.hp.stratus.pendingassociations.service.AssociationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.stereotype.Component;

/** Consumer for fire association update events. */
@Component
@Slf4j
@RequiredArgsConstructor
public class FireAssociationUpdateConsumer implements InternalEventConsumer {

  /** Service to use for publishing events. */
  private final AssociationService associationService;

  /** Indicates that this consumer is only interested in criteria resolution events. */
  @Override
  public InternalEventType eventType() {
    return InternalEventType.PUBLISH_FIRE_ASSOCIATION_UPDATE;
  }

  /**
   * Handles the supplied event.
   *
   * @param event The event.
   */
  @Override
  public void handleEvent(InternalEvent event) {
    try {

      // Fire the association update
      associationService.fireAssociationUpdate(event.getAssociation());

    } catch (BadRequestException e) {

      // Dead-letter the message
      throw new AmqpRejectAndDontRequeueException(e);
    }
  }
}
