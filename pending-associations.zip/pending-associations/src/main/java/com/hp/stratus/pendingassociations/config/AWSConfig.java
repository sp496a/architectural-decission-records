package com.hp.stratus.pendingassociations.config;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.AwsSessionCredentials;
import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.kms.KmsClient;

import java.util.function.Supplier;

/** Configures AWS settings. */
@Configuration
@RequiredArgsConstructor
public class AWSConfig {

  /** AWS profile to use. */
  @Value("${aws.profile}")
  private final String awsProfile;

  /** Region to use for KMS. */
  @Value("${kms.region}")
  private final String kmsRegion;

  /**
   * Provides a profile credential provider, which can be used to retrieve AWS credentials.
   *
   * @return The provider.
   */
  @Bean
  public ProfileCredentialsProvider profileCredentialsProvider() {
    return ProfileCredentialsProvider.create(awsProfile);
  }

  /**
   * Provides a basic AWS credential supplier, which can be used to fetch AWS credentials.
   *
   * @param profile The profile credentials provider to use.
   * @return The credential supplier.
   */
  @Bean
  public Supplier<AwsSessionCredentials> awsCredentialsSupplier(
      ProfileCredentialsProvider profile) {
    return () -> (AwsSessionCredentials) profile.resolveCredentials();
  }

  /**
   * Provides a basic KMS client.
   *
   * @param profile The profile credentials provider to use.
   * @return The kms client.
   */
  @Bean
  public KmsClient kmsClient(ProfileCredentialsProvider profile) {
    return KmsClient.builder().region(Region.of(kmsRegion)).credentialsProvider(profile).build();
  }
}
