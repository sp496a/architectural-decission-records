package com.hp.stratus.pendingassociations.config;

import com.hp.stratus.pendingassociations.model.cache.PcAssociationActionInformation;
import com.hp.stratus.pendingassociations.model.cache.PrinterAssociationActionInformation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.RedisSerializer;

/** Configures connection to a Redis cache. */
@Configuration
@RequiredArgsConstructor
public class RedisConfig {

  /** Specifies the Redis host. */
  @Value("${redis.host}")
  private final String host;

  /** Specifies the Redis port. */
  @Value("${redis.port}")
  private final int port;

  /** Specifies whether Redis is in cluster mode. */
  @Value("${redis.cluster}")
  private final boolean cluster;

  /**
   * Creates a Redis connection factory.
   *
   * @return The factory.
   */
  @Bean
  public LettuceConnectionFactory connectionFactory() {

    // If we're running in standalone mode, set up a standalone configuration
    if (!cluster) {
      return new LettuceConnectionFactory(new RedisStandaloneConfiguration(host, port));
    }

    // We're running in cluster mode, configure that instead
    return new LettuceConnectionFactory(new RedisClusterConfiguration().clusterNode(host, port));
  }

  /**
   * Creates a redis template for storing booleans.
   *
   * @param connectionFactory The connection factory to use.
   * @return The template.
   */
  @Bean
  public RedisTemplate<String, Boolean> booleanTemplate(
      LettuceConnectionFactory connectionFactory) {
    return createTemplate(connectionFactory, RedisSerializer.java());
  }

  /**
   * Creates a redis template for printer association information.
   *
   * @param connectionFactory The connection factory to use.
   * @return The template.
   */
  @Bean
  public RedisTemplate<String, PrinterAssociationActionInformation> printerAssociationTemplate(
      LettuceConnectionFactory connectionFactory) {
    return createTemplate(connectionFactory, RedisSerializer.json());
  }

  /**
   * Creates a redis template for PC association information.
   *
   * @param connectionFactory The connection factory to use.
   * @return The template.
   */
  @Bean
  public RedisTemplate<String, PcAssociationActionInformation> pcAssociationTemplate(
      LettuceConnectionFactory connectionFactory) {
    return createTemplate(connectionFactory, RedisSerializer.json());
  }

  /**
   * Simple helper function for creating a redis template with a configurable value serializer.
   *
   * @param connectionFactory The connection factory to use.
   * @param valueSerializer The value serializer to use.
   * @param <V> The value type.
   * @return The template.
   */
  private <V> RedisTemplate<String, V> createTemplate(
      LettuceConnectionFactory connectionFactory, RedisSerializer<Object> valueSerializer) {
    RedisTemplate<String, V> template = new RedisTemplate<>();
    template.setConnectionFactory(connectionFactory);

    template.setKeySerializer(RedisSerializer.string());
    template.setValueSerializer(valueSerializer);

    return template;
  }
}
