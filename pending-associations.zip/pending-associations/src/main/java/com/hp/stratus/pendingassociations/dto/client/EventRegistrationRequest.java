package com.hp.stratus.pendingassociations.dto.client;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource;
import lombok.Builder;
import lombok.Data;

/** Basic wrapper for event registration data. */
@Data
@Builder
public class EventRegistrationRequest {

  @JsonProperty("protocol")
  private String protocol;

  @JsonProperty("topicResourceName")
  private String topicResourceName;

  @JsonProperty("eventResource")
  private ExternalEventResource externalEventResource;
}
