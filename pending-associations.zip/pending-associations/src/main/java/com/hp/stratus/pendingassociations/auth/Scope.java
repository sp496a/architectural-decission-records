package com.hp.stratus.pendingassociations.auth;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/*
 * Scope of Pending Association Svc:
 * - `ws-hp.com/pending-associations/association.CREATE`
 * - `ws-hp.com/pending-associations/association.READ`
 * - `ws-hp.com/pending-associations/association.UPDATE`
 * - `ws-hp.com/pending-associations/association.DELETE`
 */
@RequiredArgsConstructor
public enum Scope {
  CREATE("ws-hp.com/pending-associations/association.CREATE"),
  READ("ws-hp.com/pending-associations/association.READ"),
  UPDATE("ws-hp.com/pending-associations/association.UPDATE"),
  DELETE("ws-hp.com/pending-associations/association.DELETE");

  @Getter private final String value;

  public String toString() {
    return value;
  }
}
