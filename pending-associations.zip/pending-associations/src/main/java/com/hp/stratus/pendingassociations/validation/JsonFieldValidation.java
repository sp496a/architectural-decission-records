package com.hp.stratus.pendingassociations.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

@Documented
@Constraint(validatedBy = JsonFieldValidator.class)
@Target({ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface JsonFieldValidation {
  String message() default " invalid format for this field. It must be null or in json format.";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};
}
