package com.hp.stratus.pendingassociations.dto.client;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

/** Basic DTO for making calls to CMS. */
@Data
@Builder
public class CmsConsentAssociationRequest {
  @JsonProperty("userId")
  private String userId;

  @JsonProperty("tenantId")
  private String tenantId;

  @JsonProperty("deviceUUID")
  private String deviceUUID;

  @JsonProperty("deviceSerialNumber")
  private String deviceSerialNumber;
}
