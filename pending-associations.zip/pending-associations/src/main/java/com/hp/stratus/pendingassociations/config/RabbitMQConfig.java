package com.hp.stratus.pendingassociations.config;

import lombok.RequiredArgsConstructor;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** RabbitMQ configuration class. */
@Configuration
@RequiredArgsConstructor
public class RabbitMQConfig {

  /** Specifies the queue to use. */
  @Value("${rabbitmq.queue}")
  private final String queue;

  /** Specifies the exchange to use. */
  @Value("${rabbitmq.exchange}")
  private final String exchange;

  /** Specifies whether RabbitMQ resources should be declared on start. */
  @Value("${rabbitmq.declare}")
  private final boolean declare;

  /** Defines the queue, asserts it if it doesn't exist. */
  @Bean
  public Queue queue() {
    Queue q = new Queue(queue);
    q.setShouldDeclare(declare);
    return q;
  }

  /** Defines the exchange, asserts it if it doesn't exist. */
  @Bean
  public FanoutExchange exchange() {
    FanoutExchange f = new FanoutExchange(exchange);
    f.setShouldDeclare(declare);
    return f;
  }

  /** Adds the binding between the queue and exchange if it doesn't exist. */
  @Bean
  public Binding binding(Queue queue, FanoutExchange exchange) {
    Binding b = BindingBuilder.bind(queue).to(exchange);
    b.setShouldDeclare(declare);
    return b;
  }

  /** Defines the listener configuration. */
  @Bean
  public SimpleMessageListenerContainer listenerContainer(
      ConnectionFactory connectionFactory, MessageListener messageListener) {
    SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
    container.setConnectionFactory(connectionFactory);
    container.setQueueNames(queue);
    container.setMessageListener(messageListener);
    return container;
  }
}
