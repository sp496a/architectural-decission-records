package com.hp.stratus.pendingassociations.dto.event.internal;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Getter;

/** Defines the types of internal events. */
@AllArgsConstructor
public enum InternalEventType {
  CRITERIA_RESOLVED("CRITERIA_RESOLVED"),
  EXECUTE_NEXT_ACTION("EXECUTE_NEXT_ACTION"),
  PUBLISH_FIRE_ASSOCIATION_UPDATE("PUBLISH_FIRE_ASSOCIATION_UPDATE");

  @Getter @JsonValue private final String value;

  @JsonCreator
  public static InternalEventType fromValue(String text) {
    for (InternalEventType type : InternalEventType.values()) {
      if (String.valueOf(type.value).equals(text)) {
        return type;
      }
    }
    return null;
  }
}
