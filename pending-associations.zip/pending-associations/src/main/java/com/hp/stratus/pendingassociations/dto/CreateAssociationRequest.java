package com.hp.stratus.pendingassociations.dto;

import lombok.Getter;
import lombok.Setter;
import org.springframework.validation.annotation.Validated;

/** Represents the create association api request */
@Getter
@Setter
@Validated
public class CreateAssociationRequest extends AssociationUpdateDto {}
