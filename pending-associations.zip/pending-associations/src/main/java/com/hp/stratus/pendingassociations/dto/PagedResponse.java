package com.hp.stratus.pendingassociations.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/** Response wrapper for paged objects. */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PagedResponse<T> {
  private List<T> contents;
  private long totalSize;
}
