package com.hp.stratus.pendingassociations.model.converter;

import com.hp.stratus.pendingassociations.model.ResourceType;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;

@ReadingConverter
public class ResourceTypeReadConverter implements Converter<String, ResourceType> {

  @Override
  public ResourceType convert(String source) {
    return ResourceType.fromValue(source);
  }
}
