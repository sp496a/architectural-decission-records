package com.hp.stratus.pendingassociations.model.converter;

import com.hp.stratus.pendingassociations.model.Operation;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.WritingConverter;

@WritingConverter
public class OperationWriteConverter implements Converter<Operation, String> {

  @Override
  public String convert(Operation source) {
    return source.getValue();
  }
}
