package com.hp.stratus.pendingassociations.consumer.external;

import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventEnvelope;

/** Defines a basic event consumer interface that can indicate its event types. */
public interface ExternalEventConsumer {

  /** Indicates the resource name the consumer is interested in. */
  ExternalEventResource eventResource();

  /** Indicates the event type the consumer supports. */
  ExternalEventType eventType();

  /** Handles the event. */
  void handleEvent(StratusEventEnvelope event);
}