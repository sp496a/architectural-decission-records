package com.hp.stratus.auth.component;

import java.util.List;

public interface JwtAuthValidator {

  boolean validate(String token, List<String> permission);
}
