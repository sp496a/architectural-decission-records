package com.hp.stratus.pendingassociations.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;

/** Gets or Sets resourceType */
@AllArgsConstructor
public enum ResourceIdType {
  POINTER("pointer"),
  STRING("string"),
  PATH("path");

  @Getter @JsonValue private final String value;

  @JsonCreator
  public static ResourceIdType fromValue(String text) {
    return Arrays.stream(values())
        .filter(val -> StringUtils.equalsIgnoreCase(val.getValue(), text))
        .findAny()
        .orElse(null);
  }
}
