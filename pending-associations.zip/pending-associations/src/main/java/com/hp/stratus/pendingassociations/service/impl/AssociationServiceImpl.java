package com.hp.stratus.pendingassociations.service.impl;

import com.hp.stratus.pendingassociations.dto.*;
import com.hp.stratus.pendingassociations.exceptions.BadGatewayException;
import com.hp.stratus.pendingassociations.exceptions.BadRequestException;
import com.hp.stratus.pendingassociations.exceptions.ConflictException;
import com.hp.stratus.pendingassociations.exceptions.ResourceNotFoundException;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.Criteria;
import com.hp.stratus.pendingassociations.model.CriteriaState;
import com.hp.stratus.pendingassociations.model.State;
import com.hp.stratus.pendingassociations.repository.AssociationRepository;
import com.hp.stratus.pendingassociations.service.AssociationService;
import com.hp.stratus.pendingassociations.service.EventService;
import com.hp.stratus.pendingassociations.utils.AssociationMapper;
import com.hp.stratus.pendingassociations.utils.SearchUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;

/** Association CRUD service. */
@Slf4j
@Service
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class AssociationServiceImpl implements AssociationService {

  /** Repository to use for DB actions. */
  private final AssociationRepository associationRepository;

  /** Service for firing association update events. */
  private final EventService eventService;

  /**
   * Handles the CreateAssociationRequest object to create the association
   *
   * @param request DTO creation request.
   * @return DTO creation response.
   */
  @Override
  public CreateAssociationResponse create(CreateAssociationRequest request) {
    log.debug("Begin : {} : create ", this.getClass().getName());

    // Convert the association to a model
    Association association = AssociationMapper.toModel(request);

    // Generate an ID
    association.setId(UUID.randomUUID());

    // Apply defaults to each criteria
    LocalDateTime createdAt = LocalDateTime.now();
    for (Criteria criteria : association.getCriteria()) {
      criteria.setCreatedAt(createdAt);
      criteria.setState(CriteriaState.PENDING);
    }

    // Apply a default state if necessary
    if (association.getState() == null) {
      association.setState(State.PENDING);
    }

    // Insert the association
    association = associationRepository.insert(association);

    // And create the response
    CreateAssociationResponse createAssociationRes =
        AssociationMapper.toCreateAssociationResponse(association);

    log.debug("End : {} : create ", this.getClass().getName());
    return createAssociationRes;
  }

  /**
   * Retrieves an association by ID.
   *
   * @param id The association ID.
   * @return Association response object.
   */
  @Override
  public AssociationDto get(UUID id) {
    log.debug("Begin : {} : get(id={})", this.getClass().getName(), id);

    // Fetch the association
    Association association = associationRepository.findById(id);

    // Throw a 404 if it wasn't found
    if (association == null) {
      throw new ResourceNotFoundException("Resource not found");
    }

    // Map it to a response
    AssociationDto associationDto = AssociationMapper.toAssociationDto(association);

    log.debug("End: {} : get(id={})", this.getClass().getName(), id);
    return associationDto;
  }

  /**
   * Retrieves a paginated list of associations.
   *
   * @param offset Offset for the page start.
   * @param limit Max number of items in the page.
   * @param sort Sorting to apply.
   * @param search Key:Value string used for generic searching.
   * @return The paginated association list.
   */
  @Override
  public Page<AssociationDto> getPaginatedAssociationList(
      int offset, int limit, Sort sort, String search) {
    log.debug(
        "Begin : {} : getPaginatedAssociationList(offset={}, limit={}, sort={}, search={})",
        this.getClass().getName(),
        offset,
        limit,
        sort,
        search);

    // Construct a page request
    Pageable pageable = new OffsetSearchPageRequest(offset, limit, sort, search);

    // Extract the search key and value
    String[] searchArray = SearchUtils.splitSearchString(search);
    if (searchArray.length != 2) {
      throw new BadRequestException("Please supply a valid key:value search string");
    }
    String searchKey = searchArray[0];
    String searchValue = searchArray[1];

    // Fetch the page
    Page<com.hp.stratus.pendingassociations.model.Association> pagedModels =
        associationRepository.getGenericSearchPagedAssociationList(
            pageable, searchKey, searchValue);

    // Map it to a response
    Page<AssociationDto> pagedAssociations = pagedModels.map(AssociationMapper::toAssociationDto);

    log.debug(
        "End : {} : getPaginatedAssociationList(offset={}, limit={}, sort={}, search={})",
        this.getClass().getName(),
        offset,
        limit,
        sort,
        search);
    return pagedAssociations;
  }

  /**
   * Updates the association specified by ID.
   *
   * @param id The association ID.
   * @param request The update DTO.
   * @return Response DTO.
   */
  @Override
  public PutAssociationResponse put(UUID id, PutAssociationRequest request) {
    log.debug("Begin : {} : put(id={}, request={})", this.getClass().getName(), id, request);

    // Fetch the existing association
    Association existingAssociation = associationRepository.findById(id);
    if (existingAssociation == null) {
      throw new ResourceNotFoundException("Resource not found");
    }

    // Only open associations can be edited
    if (existingAssociation.getState() != State.OPEN) {
      throw new ConflictException("Only open associations can be edited");
    }

    // Construct the new association
    Association association = AssociationMapper.toModel(request);
    association.setId(id);

    // Apply defaults to each criteria
    LocalDateTime createdAt = LocalDateTime.now();
    for (Criteria criteria : association.getCriteria()) {
      criteria.setCreatedAt(createdAt);
      criteria.setState(CriteriaState.PENDING);
    }

    // Apply a default state if necessary
    if (association.getState() == null) {
      association.setState(State.PENDING);
    }

    // Save the new association
    association = associationRepository.save(association);

    // And convert it to a put response
    PutAssociationResponse putAssociationResponse =
        AssociationMapper.toPutAssociationResponse(association);

    log.debug("End : {} : put(id={}, request={})", this.getClass().getName(), id, request);
    return putAssociationResponse;
  }

  /**
   * Deletes an association by ID.
   *
   * @param id The association ID.
   * @return The number of records deleted.
   */
  @Override
  public long delete(UUID id) {
    log.debug("Begin : {} : delete(id={}) ", this.getClass().getName(), id);

    // Find the association by ID
    Association association = associationRepository.findById(id);
    if (association == null || association.getState() == State.CANCELLED) {
      return 0;
    }

    // Set the association state to cancelled and save it
    association.setState(State.CANCELLED);
    associationRepository.save(association);

    log.debug("End : {} : delete(id={}) ", this.getClass().getName(), id);
    return 1;
  }

  /**
   * Patches an association by ID.
   *
   * @param id The association ID.
   * @param request The patch request
   * @return The patch response.
   */
  @Override
  public PatchAssociationResponse patch(UUID id, PatchAssociationRequest request) {
    log.debug("Begin : {} : patch(id={}, request={})", this.getClass().getName(), id, request);

    // Find the existing association
    Association association = associationRepository.findById(id);
    if (association == null) {
      throw new ResourceNotFoundException("Resource not found");
    }

    // Only open associations can be edited
    if (association.getState() != State.OPEN) {
      throw new ConflictException("Only open associations can be edited");
    }

    // Replace the tenant ID if supplied
    if (request.getTenantId() != null) {
      association.setTenantId(request.getTenantId());
    }

    // Replace the state if supplied
    if (request.getState() != null) {
      association.setState(AssociationMapper.toStateModel(request.getState()));
    }

    // Replace the actions if supplied
    if (request.getActions() != null) {
      association.setActions(AssociationMapper.toActionModels(request.getActions()));
    }

    // Replace the criteria if supplied
    if (request.getCriteria() != null) {
      association.setCriteria(AssociationMapper.toCriteriaModels(request.getCriteria()));

      // Add defaults
      LocalDateTime createdAt = LocalDateTime.now();
      for (Criteria criteria : association.getCriteria()) {
        criteria.setCreatedAt(createdAt);
        criteria.setState(CriteriaState.PENDING);
      }
    }

    // Replace the metadata if supplied
    if (request.getMetadata() != null) {
      association.setMetadata(request.getMetadata());
    }

    // Save the updates
    associationRepository.save(association);

    // Convert to a response
    PatchAssociationResponse patchAssociationResponse =
        AssociationMapper.toPatchAssociationResponse(association);

    log.debug("End : {} : put(id={}, request={})", this.getClass().getName(), id, request);
    return patchAssociationResponse;
  }

  /**
   * Counts associations with pagination.
   *
   * @param offset The offset to begin the page
   * @param limit The size of the page to return
   * @return Content range
   */
  @Override
  public String head(int offset, int limit) {
    log.debug("Begin : {} : head(offset={}, limit={})", this.getClass().getName(), offset, limit);

    long count = associationRepository.count();
    int max = offset + limit;
    String response = offset + "-" + max + "/" + count;

    log.debug("End : {} : head(offset={}, limit={})", this.getClass().getName(), offset, limit);
    return response;
  }

  /**
   * Completes the supplied association.
   *
   * @param association The association to complete.
   */
  @Override
  public void completeAssociation(Association association) {

    // Mark the association as completed and update it in the DB
    association.setState(State.COMPLETED);
    associationRepository.save(association);

    // Fire the association update event
    eventService.publishFireAssociationUpdate(association.getId());
  }

  /**
   * Cancels the supplied association.
   *
   * @param association The association to cancel.
   */
  @Override
  public void cancelAssociation(Association association) {

    // Mark the association as cancelled and update it in the DB
    association.setState(State.CANCELLED);
    associationRepository.save(association);
  }

  /**
   * Fires an association update event to the rest of stratus.
   *
   * @param associationId The association ID.
   * @throws BadGatewayException When event management responds with a 5xx.
   * @throws BadRequestException When event management responds with a non-5xx error.
   */
  public void fireAssociationUpdate(UUID associationId)
      throws BadGatewayException, BadRequestException {

    // Grab the association by ID
    Association association = associationRepository.findById(associationId);
    if (association == null) {
      return;
    }

    // Fire the actual event
    eventService.publishAssociationUpdate(association);
  }
}
