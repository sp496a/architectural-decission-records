package com.hp.stratus.pendingassociations.action.associateconsent;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.action.ActionExecutor;
import com.hp.stratus.pendingassociations.exceptions.ResourceResolutionException;
import com.hp.stratus.pendingassociations.model.Action;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.Operation;
import com.hp.stratus.pendingassociations.utils.PathResolver;
import com.hp.stratus.pendingassociations.utils.ResourceUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.NotImplementedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/** Executor for association actions. */
@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
@Slf4j
public class AssociateConsentExecutor implements ActionExecutor {

  /** The object mapper to use for extracting resource details. */
  private final ObjectMapper objectMapper;

  /** The path resolver to use for json path resources. */
  private final PathResolver pathResolver;

  /** List of type resource type specific executors. */
  private final List<AssociateConsentResourceExecutor> resourceExecutors;

  /**
   * Indicates that this executor only supports the associateConsent operation.
   *
   * @return The association operation.
   */
  @Override
  public Operation getOperation() {
    return Operation.ASSOCIATE_CONSENT;
  }

  /**
   * Executes the associate action, handing the resource off to the relevant sub-executor.
   *
   * @param association The association.
   * @param action The action to execute.
   * @param actionIndex The index of the action.
   * @throws ResourceResolutionException Thrown when resource resolution fails.
   * @throws NotImplementedException Thrown if an unsupported resource is supplied.
   */
  @Override
  public void execute(Association association, Action action, int actionIndex)
      throws ResourceResolutionException, NotImplementedException {

    // Associate consent actions require user and device resources
    if (action.getResources() == null
        || action.getResources().getUser() == null
        || action.getResources().getDevice() == null) {
      throw new ResourceResolutionException(
          "Consent associations require user and device resources");
    }

    // Find the correct resource executor
    AssociateConsentResourceExecutor executor =
        resourceExecutors.stream()
            .filter(e -> e.getDeviceResourceType() == action.getResources().getDevice().getType())
            .findFirst()
            .orElseThrow(
                () ->
                    new NotImplementedException(
                        "No executor found for consent association of resource "
                            + action.getResources().getDevice().getType().toString()));

    // Resolve the user resource
    String userId =
        ResourceUtils.resolveResource(
            objectMapper, pathResolver, association, action.getResources().getUser().getId());

    // Resolve the device resource
    String deviceId =
        ResourceUtils.resolveResource(
            objectMapper, pathResolver, association, action.getResources().getDevice().getId());

    // And execute the executor
    executor.execute(userId, deviceId, association, actionIndex);
  }
}
