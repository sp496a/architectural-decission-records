package com.hp.stratus.pendingassociations.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

/** Definition of criteria while creating/updating */
@Data
@Validated
public class CriteriaUpdateDto {
  @JsonProperty("type")
  private CriteriaType type;

  @JsonProperty("details")
  private CriteriaDetailsDto details;

  @JsonProperty("condition")
  private ConditionDto condition;

  @JsonProperty("conditions")
  private ConditionsDto conditions;
}
