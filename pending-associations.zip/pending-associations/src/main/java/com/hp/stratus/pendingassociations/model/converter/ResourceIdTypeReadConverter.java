package com.hp.stratus.pendingassociations.model.converter;

import com.hp.stratus.pendingassociations.model.ResourceIdType;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;

@ReadingConverter
public class ResourceIdTypeReadConverter implements Converter<String, ResourceIdType> {

  @Override
  public ResourceIdType convert(String source) {
    return ResourceIdType.fromValue(source);
  }
}
