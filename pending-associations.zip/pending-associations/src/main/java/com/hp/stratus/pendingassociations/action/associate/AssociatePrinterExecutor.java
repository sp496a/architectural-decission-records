package com.hp.stratus.pendingassociations.action.associate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.http.client.utils.HttpClient;
import com.hp.stratus.pendingassociations.dto.client.PrinterClaimRequest;
import com.hp.stratus.pendingassociations.exceptions.ActionExecutionException;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.Resource;
import com.hp.stratus.pendingassociations.model.ResourceType;
import com.hp.stratus.pendingassociations.model.cache.PrinterAssociationActionInformation;
import com.hp.stratus.pendingassociations.repository.ActionRepository;
import com.hp.stratus.pendingassociations.service.EventService;
import com.hp.stratus.pendingassociations.utils.PathResolver;
import com.hp.stratus.pendingassociations.utils.ResourceUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

/** A simple executor for printer association actions. */
@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
@Slf4j
public class AssociatePrinterExecutor implements AssociateResourceExecutor {

  private static final String OWNERSHIP_VERSION = "1.0.0";

  /** The object mapper to use for extracting resource details. */
  private final ObjectMapper objectMapper;

  /** The path resolver to use for json path resources. */
  private final PathResolver pathResolver;

  /** The action repository for updating actions in the DB. */
  private final ActionRepository actionRepository;

  /** The service for firing events. */
  private final EventService eventService;

  /** Template for storing values in Redis. */
  private final RedisTemplate<String, PrinterAssociationActionInformation> redis;

  /** Basic HTTP client. */
  private final HttpClient client;

  /** Supplier for JWT tokens. */
  @Qualifier("jwtSupplier")
  private final Supplier<String> jwtSupplier;

  /** Base URL for stratus services. */
  @Value("${devices.base.url}")
  private final String baseUrl;

  /** Endpoint for device ownership. */
  @Value("${devices.printer.ownership.endpoint}")
  private final String ownershipEndpoint;

  /**
   * Indicates that this executor only supports a printer resource type.
   *
   * @return The printer resource type.
   */
  @Override
  public ResourceType getResourceType() {
    return ResourceType.PRINTER;
  }

  /**
   * Executes the association.
   *
   * @param deviceResource The device resource.
   * @param association The association to execute the action on.
   * @param actionIndex The index of the action to execute.
   * @throws ActionExecutionException Thrown if execution fails.
   */
  @Override
  public void execute(Resource deviceResource, Association association, int actionIndex)
      throws ActionExecutionException {
    log.debug(
        "Executing association action {} for association {}", actionIndex, association.getId());

    // Resolve the resource and throw an exception if the resolution can't be done
    String deviceId =
        ResourceUtils.resolveResource(
            objectMapper, pathResolver, association, deviceResource.getId());

    // Write the device and association IDs to redis, so we can complete the action later
    redis
        .opsForValue()
        .set(deviceId, new PrinterAssociationActionInformation(association.getId(), actionIndex));

    // Construct the registration URI
    String uri = UriComponentsBuilder.fromUriString(baseUrl).path(ownershipEndpoint).toUriString();

    // Build the request
    PrinterClaimRequest req =
        PrinterClaimRequest.builder()
            .version(OWNERSHIP_VERSION)
            .deviceId(deviceId)
            .tenantId(association.getTenantId())
            .build();

    // Make the request
    try {
      client.post(uri, jwtSupplier.get(), req, new ParameterizedTypeReference<>() {});
      log.info("Successfully initiated claim action for printer {}", deviceId);
    } catch (HttpClientErrorException e) {
      handleClientError(
          HttpStatus.valueOf(e.getStatusCode().value()),
          deviceId,
          association.getId(),
          actionIndex);
    } catch (HttpServerErrorException e) {
      handleServerError(HttpStatus.valueOf(e.getStatusCode().value()), deviceId);
    } catch (Exception e) {
      handleNetworkError(deviceId, e.getMessage());
    }
  }

  /**
   * Completes a claim for the supplied device ID and resolution object.
   *
   * @param deviceId The device ID.
   * @param resolutionObject The resolution object.
   */
  public void completeClaim(String deviceId, Map<String, Object> resolutionObject) {

    // Fetch the association ID from redis
    PrinterAssociationActionInformation actionInformation =
        redis.opsForValue().getAndDelete(deviceId);
    if (actionInformation == null) {
      log.debug("No pending claim found for device {}", deviceId);
      return;
    }

    // Resolve the action
    resolveAction(
        deviceId,
        actionInformation.getAssociationId(),
        actionInformation.getActionIndex(),
        resolutionObject);
  }

  /**
   * Resolves the supplied action and fires the next action event.
   *
   * @param deviceId The device ID.
   * @param associationId The association ID.
   * @param actionIndex The action index to resolve.
   * @param resolutionObject The resolution object to use.
   */
  private void resolveAction(
      String deviceId, UUID associationId, int actionIndex, Object resolutionObject) {

    // Update the action
    boolean resolved = actionRepository.resolveAction(associationId, actionIndex, resolutionObject);
    if (!resolved) {
      log.warn("Failed to find association matching claim for device {}", deviceId);
      return;
    }

    // Fire off the event to execute the next action
    eventService.publishExecuteNextAction(associationId);
  }

  /**
   * Handles a 4xx client error during claim.
   *
   * @param status The status code.
   * @param deviceId The device ID.
   * @param associationId The association ID.
   * @param actionIndex The index of the action.
   * @throws ActionExecutionException if the client error caused the execution to fail.
   */
  private void handleClientError(
      HttpStatus status, String deviceId, UUID associationId, int actionIndex)
      throws ActionExecutionException {

    // Clear out the redis lock in case another attempt comes through
    redis.delete(deviceId);

    // If the status is anything but a conflict, we can't complete the association or retry
    if (status != HttpStatus.CONFLICT) {
      log.warn("Failed to initiate claim for printer {}: Response code={}", deviceId, status);
      throw new ActionExecutionException(
          false, "Client error when initiating claim for printer " + deviceId);
    }

    // The status is a conflict, resolve it with a resolution object indicating that
    log.info("printer with ID {} is already claimed, resolving...", deviceId);
    Map<String, Object> resolution =
        Map.of("message", "printer with ID " + deviceId + " is already claimed");
    resolveAction(deviceId, associationId, actionIndex, resolution);
    log.info("Successfully completed claim action for printer {}", deviceId);
  }

  /**
   * Handles a 5xx server error during claim.
   *
   * @param status The status code.
   * @param deviceId The device ID.
   * @throws ActionExecutionException Indicating that the action execution failed.
   */
  private void handleServerError(HttpStatus status, String deviceId)
      throws ActionExecutionException {
    redis.delete(deviceId);
    log.warn(
        "Failed to initiate claim for printer {}: Response code={}. Retrying...", deviceId, status);
    throw new ActionExecutionException(
        true, "Server error when initiating claim for printer " + deviceId);
  }

  /**
   * Handles a network error during claim.
   *
   * @param deviceId The device ID.
   * @throws ActionExecutionException Indicating that action execution failed.
   */
  private void handleNetworkError(String deviceId, String message) throws ActionExecutionException {
    redis.delete(deviceId);
    log.warn("Failed to initiate claim for printer {}: {} Retrying...", deviceId, message);
    throw new ActionExecutionException(
        true, "Network error when initiating claim for printer " + deviceId);
  }
}
