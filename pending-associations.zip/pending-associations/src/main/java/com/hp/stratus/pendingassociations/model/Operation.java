package com.hp.stratus.pendingassociations.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;

/** The operation to perform for an action. */
@AllArgsConstructor
public enum Operation {
  @JsonProperty("associate")
  ASSOCIATE("associate"),
  @JsonProperty("associateConsent")
  ASSOCIATE_CONSENT("associateConsent"),
  @JsonProperty("updateMetadata")
  UPDATE_METADATA("updateMetadata");

  @Getter private final String value;

  public static Operation fromValue(String text) {
    for (Operation o : Operation.values()) {
      if (o.getValue().equals(text)) {
        return o;
      }
    }
    return null;
  }
}
