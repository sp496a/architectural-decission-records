package com.hp.stratus.pendingassociations.dto.client;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

/** Basic wrapper for printer claim data. */
@Data
@Builder
public class PrinterClaimRequest {

  @JsonProperty("version")
  private String version;

  @JsonProperty("deviceId")
  private String deviceId;

  @JsonProperty("accountId")
  private String tenantId;
}
