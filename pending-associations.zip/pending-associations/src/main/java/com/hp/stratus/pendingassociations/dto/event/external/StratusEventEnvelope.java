package com.hp.stratus.pendingassociations.dto.event.external;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/** Defines a basic stratus event object. */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class StratusEventEnvelope {

  @JsonProperty("event")
  private ExternalEventType event;

  @JsonProperty("fqResourceName")
  private ExternalEventResource fqResourceName;

  @JsonProperty("resourceId")
  private String resourceId;

  @JsonProperty("tenantResourceId")
  private String tenantResourceId;

  @JsonProperty("scopes")
  private List<String> scopes;

  @JsonProperty("resource")
  private String resource;

  @JsonProperty("eventAttributeValueMap")
  private Map<String, StratusEventAttribute> eventAttributeValueMap;
}
