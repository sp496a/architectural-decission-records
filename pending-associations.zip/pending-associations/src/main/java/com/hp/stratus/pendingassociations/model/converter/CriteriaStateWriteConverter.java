package com.hp.stratus.pendingassociations.model.converter;

import com.hp.stratus.pendingassociations.model.CriteriaState;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.WritingConverter;

@WritingConverter
public class CriteriaStateWriteConverter implements Converter<CriteriaState, String> {

  @Override
  public String convert(CriteriaState source) {
    return source.getValue();
  }
}
