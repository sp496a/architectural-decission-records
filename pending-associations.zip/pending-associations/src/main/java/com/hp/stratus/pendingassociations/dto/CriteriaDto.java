package com.hp.stratus.pendingassociations.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

import java.time.LocalDateTime;

@Data
@Validated
public class CriteriaDto extends CriteriaUpdateDto {

  @JsonProperty("state")
  private CriteriaState state;

  @JsonProperty("createdAt")
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
  private LocalDateTime createdAt;

  @JsonProperty("resolvedAt")
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
  private LocalDateTime resolvedAt;

  @JsonProperty("resolvedWith")
  private Object resolvedWith;
}
