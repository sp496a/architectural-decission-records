package com.hp.stratus.pendingassociations.action;

import com.hp.stratus.pendingassociations.exceptions.ActionExecutionException;
import com.hp.stratus.pendingassociations.exceptions.ResourceResolutionException;
import com.hp.stratus.pendingassociations.model.Action;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.Operation;
import org.apache.commons.lang3.NotImplementedException;

/** Basic interface for action execution. */
public interface ActionExecutor {

  /** Indicates the operation this executor supports. */
  Operation getOperation();

  /**
   * Executes the action.
   *
   * @param association The association.
   * @param action The action to execute.
   * @param actionIndex The index of the action.
   * @throws ResourceResolutionException When there is an issue with resource resolution
   * @throws NotImplementedException When a matching sub-executor can't be found.
   * @throws ActionExecutionException When action execution fails.
   */
  void execute(Association association, Action action, int actionIndex)
      throws ResourceResolutionException, NotImplementedException, ActionExecutionException;
}
