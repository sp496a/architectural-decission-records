package com.hp.stratus.pendingassociations.exceptions;

import com.hp.stratus.pendingassociations.dto.ApiError;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;


@Slf4j
@ControllerAdvice
public class CustomRequestHandler {

  private static final String HYPHE = "-";

  private static final String SPACE = " ";

  /**
   * Handles the MethodArgumentNotValidException from Spring validation and prepares an ApiError
   * response
   *
   * @param methodArgumentNotValidException exception thrown from the spring validation
   * @return the ApiError object
   */
  @ExceptionHandler(MethodArgumentNotValidException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ResponseEntity<ApiError> handleInputValidationExceptions(
      MethodArgumentNotValidException methodArgumentNotValidException) {

    var error = new StringBuilder();
    methodArgumentNotValidException
        .getBindingResult()
        .getAllErrors()
        .forEach(
            fieldError -> {
              String fieldName = ((FieldError) fieldError).getField();
              String errorMessage = fieldError.getDefaultMessage();
              error.append(fieldName).append(HYPHE).append(errorMessage).append(SPACE);
            });

    var apiError =
        new ApiError(
            Integer.toString(HttpStatus.BAD_REQUEST.value()), error.toString().stripTrailing());
    log.info(error.toString().stripTrailing(), methodArgumentNotValidException);
    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(apiError);
  }

  /**
   * Handles the ResourceNotFoundException and prepares an ApiError response
   *
   * @param resourceNotFoundException The exception that caused the handler to fire
   * @return the ApiError object
   */
  @ExceptionHandler(ResourceNotFoundException.class)
  @ResponseStatus(HttpStatus.NOT_FOUND)
  public ResponseEntity<ApiError> handleResourceNotFoundException(
      ResourceNotFoundException resourceNotFoundException) {
    log.info(resourceNotFoundException.getMessage(), resourceNotFoundException);
    var apiError =
        new ApiError(
            Integer.toString(HttpStatus.NOT_FOUND.value()), resourceNotFoundException.getMessage());

    return ResponseEntity.status(HttpStatus.NOT_FOUND).body(apiError);
  }

  /**
   * Handles the ConflictException and prepares an ApiError response
   *
   * @param conflictException The exception that caused the handler to fire
   * @return the ApiError object
   */
  @ExceptionHandler(ConflictException.class)
  @ResponseStatus(HttpStatus.CONFLICT)
  public ResponseEntity<ApiError> handleConflictException(ConflictException conflictException) {
    log.info(conflictException.getMessage(), conflictException);
    var apiError =
        new ApiError(Integer.toString(HttpStatus.CONFLICT.value()), conflictException.getMessage());

    return ResponseEntity.status(HttpStatus.CONFLICT).body(apiError);
  }

  /**
   * Handles the IllegalArgumentException and prepares an ApiError response
   *
   * @param illegalArgumentException The exception that caused the handler to fire
   * @return the ApiError object
   */
  @ExceptionHandler(IllegalArgumentException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ResponseEntity<ApiError> handleIllegalArgumentException(
      IllegalArgumentException illegalArgumentException) {
    log.info(illegalArgumentException.getMessage(), illegalArgumentException);

    var apiError =
        new ApiError(
            Integer.toString(HttpStatus.BAD_REQUEST.value()),
            illegalArgumentException.getMessage());

    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(apiError);
  }

  /**
   * Handles the ConstraintViolationException and prepares an ApiError response
   *
   * @param constraintViolationException The exception that caused the handler to fire
   * @return the ApiError object
   */
  @ExceptionHandler(ConstraintViolationException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ResponseEntity<ApiError> handleConstraintViolationException(
      ConstraintViolationException constraintViolationException) {
    log.info(constraintViolationException.getMessage(), constraintViolationException);

    var apiError =
        new ApiError(
            Integer.toString(HttpStatus.BAD_REQUEST.value()),
            constraintViolationException.getMessage());

    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(apiError);
  }

  /**
   * Handles the HttpMessageNotReadableException and prepares an ApiError response
   *
   * @param exception The exception that caused the handler to fire when failed to parse the request
   *     body
   * @return the ApiError object
   */
  @ExceptionHandler(HttpMessageNotReadableException.class)
  @ResponseStatus(HttpStatus.BAD_REQUEST)
  public ResponseEntity<ApiError> handleHttpMessageNotReadableException(
      HttpMessageNotReadableException exception) {
    log.info(exception.getMessage(), exception);

    var apiError =
        new ApiError(
            Integer.toString(HttpStatus.BAD_REQUEST.value()),
            "Failed to parse the request body. Please double check if it is well formatted.");

    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(apiError);
  }

  /**
   * Handles custom exception
   *
   * @param exception exception to handle
   * @return errorMessage with httpStatus, errorMessage
   */
  @ExceptionHandler(PendingAssociationException.class)
  public ResponseEntity<ApiError> handlePendingAssociationException(
      PendingAssociationException exception) {
    log.info(exception.getErrorMessage(), exception);

    log.warn(
        exception.getErrorMessage()); // log warn level exception msg according story STRBOX1-595
    var apiError =
        new ApiError(Integer.toString(exception.getStatus().value()), exception.getErrorMessage());

    return ResponseEntity.status(exception.getStatus()).body(apiError);
  }

  @ExceptionHandler(MethodArgumentTypeMismatchException.class)
  public Object handleMethodArgumentTypeMismatchException(
      MethodArgumentTypeMismatchException numberFormatException) {
    log.info(
        numberFormatException.getCause().getMessage().replace("\"", ""), numberFormatException);

    var apiError =
        new ApiError(
            Integer.toString(HttpStatus.BAD_REQUEST.value()),
            (numberFormatException.getCause().getMessage().replace("\"", "")));

    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(apiError);
  }
}
