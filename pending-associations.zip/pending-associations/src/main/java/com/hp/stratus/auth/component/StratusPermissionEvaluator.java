package com.hp.stratus.auth.component;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
@Primary
public class StratusPermissionEvaluator implements PermissionEvaluator {

  private final JwtAuthValidator jwtAuthValidator;

  /**
   * Implementation of spring security PermissionEvaluator
   *
   * @param auth : jwt token received from http request header
   * @param key : not really used in this case.
   * @param permission: the permission object contains scope. if multiple scope, the type should be
   *     List; otherwise, toString() of the object will be use
   * @return true if pass authentication. Otherwise, throws Exception.
   */
  @Override
  public boolean hasPermission(Authentication auth, Object key, Object permission) {
    String jwtToken = ((JwtAuthenticationToken) auth).getToken().getTokenValue();
    List<String> requiredScopes = null;
    if (permission != null) {
      if (permission instanceof List) { // //permission is a List<String>
        requiredScopes = (List<String>) permission;
      } else { // if not List, use the toString() convert permission object to String
        requiredScopes =
            List.of(permission.toString()); // permission is a String or Enum with toString() method
      }
    }

    boolean result = jwtAuthValidator.validate(jwtToken, requiredScopes);
    log.debug("Evaluate Permission {} for request with jwtToken", permission);

    return result;
  }

  /**
   * no use, just implemented the method defined in parent interface
   *
   * @param auth The authentication
   * @param serializable the serializable object
   * @param key key to look for
   * @param permission permission to look for
   * @return always false
   */
  @Override
  public boolean hasPermission(
      Authentication auth, Serializable serializable, String key, Object permission) {
    return false;
  }
}
