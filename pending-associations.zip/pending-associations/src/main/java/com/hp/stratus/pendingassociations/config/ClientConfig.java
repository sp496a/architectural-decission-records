package com.hp.stratus.pendingassociations.config;

import com.hp.stratus.fleet.jwtvalidation.util.JwtGenerator;
import com.hp.stratus.http.client.config.RestTemplateFactory;
import com.hp.stratus.http.client.utils.HttpClient;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestTemplate;

import java.util.function.Supplier;

/** Configuration for HTTP clients. */
@Configuration
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class ClientConfig {

  /** The client ID for the service. */
  @Value("${authz.client.id}")
  private String clientId;

  /** The client secret for the service. */
  @Value("${authz.client.secret}")
  private String clientSecret;

  /** The spring environment. */
  private final Environment environment;

  /**
   * Set the rest template to use for making API calls.
   *
   * @return The template.
   */
  @Bean
  @Primary
  public RestTemplate restTemplate() {
    return RestTemplateFactory.initRestTemplate(environment);
  }

  /**
   * Constructs the HTTP client for the service.
   *
   * @param restTemplate The underlying rest template to use.
   * @return The client.
   */
  @Bean
  public HttpClient httpClient(RestTemplate restTemplate) {
    return new HttpClient(restTemplate);
  }

  /**
   * Constructs a JWT supplier.
   *
   * @param generator The JWT generator.
   * @return The supplier.
   */
  @Bean
  @Qualifier("jwtSupplier")
  public Supplier<String> jwtSupplier(JwtGenerator generator) {
    return () -> generator.generateNewJwtToken(clientId, clientSecret);
  }
}
