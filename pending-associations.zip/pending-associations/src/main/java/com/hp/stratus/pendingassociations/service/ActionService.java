package com.hp.stratus.pendingassociations.service;

import java.util.UUID;

/** A simple service for executing actions when associations are completed. */
public interface ActionService {

  /**
   * Begins processing actions for the supplied association.
   *
   * @param association The association ID.
   */
  void beginExecution(UUID association);

  /**
   * Kicks off the next action execution.
   *
   * @param association The association ID.
   */
  void executeNextAction(UUID association);
}
