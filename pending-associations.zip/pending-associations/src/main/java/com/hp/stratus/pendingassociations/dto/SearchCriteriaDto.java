package com.hp.stratus.pendingassociations.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

/** Definition of Search criteria */
@Data
@Validated
public class SearchCriteriaDto {

  @JsonProperty("type")
  private CriteriaType type = null;

  @JsonProperty("condition")
  private ConditionDto condition = null;

  @JsonProperty("state")
  private CriteriaState state = null;
}
