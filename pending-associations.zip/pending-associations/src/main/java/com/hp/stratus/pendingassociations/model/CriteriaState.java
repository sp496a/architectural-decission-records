package com.hp.stratus.pendingassociations.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;

/** The current state of the criteria */
@AllArgsConstructor
public enum CriteriaState {
  @JsonProperty("pending")
  PENDING("pending"),
  @JsonProperty("resolved")
  RESOLVED("resolved");

  @Getter private final String value;

  public static CriteriaState fromValue(String text) {
    for (CriteriaState c : CriteriaState.values()) {
      if (c.getValue().equals(text)) {
        return c;
      }
    }
    return null;
  }
}
