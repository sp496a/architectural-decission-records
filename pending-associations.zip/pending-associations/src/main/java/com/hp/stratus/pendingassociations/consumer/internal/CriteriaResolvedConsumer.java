package com.hp.stratus.pendingassociations.consumer.internal;

import com.hp.stratus.pendingassociations.dto.event.internal.InternalEvent;
import com.hp.stratus.pendingassociations.dto.event.internal.InternalEventType;
import com.hp.stratus.pendingassociations.service.ActionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/** Consumer for criteria resolution events. */
@Component
@Slf4j
@RequiredArgsConstructor
public class CriteriaResolvedConsumer implements InternalEventConsumer {

  /** Service to use for kicking off actions. */
  private final ActionService actionService;

  /** Indicates that this consumer is only interested in criteria resolution events. */
  @Override
  public InternalEventType eventType() {
    return InternalEventType.CRITERIA_RESOLVED;
  }

  /**
   * Handles the supplied event.
   *
   * @param event The event.
   */
  @Override
  public void handleEvent(InternalEvent event) {
    actionService.beginExecution(event.getAssociation());
  }
}
