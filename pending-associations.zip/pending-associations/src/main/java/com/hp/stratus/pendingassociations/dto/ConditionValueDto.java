package com.hp.stratus.pendingassociations.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.validation.annotation.Validated;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Validated
public class ConditionValueDto {
  @JsonProperty("type")
  @NotNull
  private ConditionTypeDto type;

  @JsonProperty("value")
  @NotNull
  private String value;
}
