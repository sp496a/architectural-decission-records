package com.hp.stratus.pendingassociations.exceptions;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;
import org.springframework.http.HttpStatus;

/** Generic pending association exception class */
@Getter
@RequiredArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = false)
public class PendingAssociationException extends RuntimeException {
  private final String errorMessage;
  private final HttpStatus status;
}
