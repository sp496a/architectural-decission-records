package com.hp.stratus.pendingassociations.service;

import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType;

import javax.json.JsonStructure;
import java.util.Map;

/** A basic service for handling criteria. */
public interface CriteriaService {

  /**
   * Resolves event-based criteria.
   *
   * @param resource The event resource.
   * @param type The event type.
   * @param event The event body.
   * @param resolutionObject The resolution object to use.
   */
  void resolveEventBasedCriteria(
      ExternalEventResource resource,
      ExternalEventType type,
      JsonStructure event,
      Object resolutionObject);

  /**
   * Resolves criteria for chromebooks. TODO: this is a hack
   *
   * @param resource The event resource.
   * @param type The event type.
   * @param eventMap A map representation of the event.
   * @param eventStructure A structure representation of the event.
   */
  void resolveConditionCriteriaHack(
      ExternalEventResource resource,
      ExternalEventType type,
      Map<String, Object> eventMap,
      JsonStructure eventStructure);
}
