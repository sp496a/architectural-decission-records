package com.hp.stratus.pendingassociations.model;

import lombok.Data;

/** Conditions model. */
@Data
public class Conditions {
  private ConditionsOperator operator;
  private Condition[] values;
}
