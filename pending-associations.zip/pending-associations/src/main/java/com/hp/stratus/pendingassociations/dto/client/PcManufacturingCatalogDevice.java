package com.hp.stratus.pendingassociations.dto.client;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;

/** PC Manufacturing catalog device definition. */
@Data
@Getter
public class PcManufacturingCatalogDevice {

  @JsonProperty("deviceUniqueId")
  private String deviceUniqueId;

  @JsonProperty("uuid")
  private String uuid;

  @JsonProperty("serialNumber")
  private String serialNumber;

  @JsonProperty("productName")
  private String productName;

  @JsonProperty("productNumber")
  private String productNumber;

  @JsonProperty("productDescription")
  private String productDescription;
}
