package com.hp.stratus.auth.conf;

import com.hp.stratus.auth.exception.SecurityFilterExceptionHandler;
import com.hp.stratus.auth.path.PermitAllPathProvider;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.AccessDeniedHandler;

@Slf4j
@Configuration
@EnableWebSecurity
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class SecurityConfig {

  private final Environment environment;
  private final PermitAllPathProvider permitAllPathService;

  @Bean
  @Order(Ordered.HIGHEST_PRECEDENCE)
  public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    List<String> permitAllPathList = permitAllPathService.getPathForPermitAll();
    log.debug("Starting security config");
    http.httpBasic()
        .disable()
        .sessionManagement()
        .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
        .and()
        .csrf()
        .disable() // solely service <-> service and won't be publicly exposed for browsers at all
        .authorizeHttpRequests()
        .requestMatchers(
            // common permitAll
            "/error")
        .permitAll()
        .requestMatchers(
            // permit all configured routes
            permitAllPathList.toArray(new String[permitAllPathList.size()]))
        .permitAll()
        .requestMatchers("/*", "/**")
        .authenticated()
        .and()
        .exceptionHandling()
        .accessDeniedHandler(customAccessDeniedHandler())
        .and()
        .oauth2ResourceServer()
        .authenticationEntryPoint(customAuthenticationEntry())
        .jwt();
    log.debug("Security config done.");
    return http.build();
  }

  @Bean
  public AuthenticationEntryPoint customAuthenticationEntry() {
    return new SecurityFilterExceptionHandler();
  }

  @Bean
  public AccessDeniedHandler customAccessDeniedHandler() {
    return new SecurityFilterExceptionHandler();
  }
}
