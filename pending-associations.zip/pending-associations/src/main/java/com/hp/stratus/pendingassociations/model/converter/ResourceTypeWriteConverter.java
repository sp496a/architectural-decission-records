package com.hp.stratus.pendingassociations.model.converter;

import com.hp.stratus.pendingassociations.model.ResourceType;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.WritingConverter;

@WritingConverter
public class ResourceTypeWriteConverter implements Converter<ResourceType, String> {

  @Override
  public String convert(ResourceType source) {
    return source.getValue();
  }
}
