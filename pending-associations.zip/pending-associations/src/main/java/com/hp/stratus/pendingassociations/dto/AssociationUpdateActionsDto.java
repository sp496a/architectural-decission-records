package com.hp.stratus.pendingassociations.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

import java.time.LocalDateTime;

@Data
@Validated
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssociationUpdateActionsDto {
  @JsonProperty("operation")
  private Operation operation;

  @JsonProperty("resource")
  private ResourceDto resource;

  @JsonProperty("resources")
  private ResourcesDto resources;

  @JsonProperty("completedAt")
  @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
  private LocalDateTime completedAt;

  @JsonProperty("completedWith")
  private Object completedWith;
}
