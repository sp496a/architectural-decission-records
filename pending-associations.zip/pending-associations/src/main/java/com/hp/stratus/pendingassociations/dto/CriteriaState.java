package com.hp.stratus.pendingassociations.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.util.Arrays;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

/** The current state of the criteria */
@AllArgsConstructor
public enum CriteriaState {
  PENDING("pending"),
  RESOLVED("resolved");

  @Getter @JsonValue private final String value;

  @JsonCreator
  public static CriteriaState fromValue(String text) {
    return Arrays.stream(values())
        .filter(val -> StringUtils.equalsIgnoreCase(val.getValue(), text))
        .findAny()
        .orElse(null);
  }
}
