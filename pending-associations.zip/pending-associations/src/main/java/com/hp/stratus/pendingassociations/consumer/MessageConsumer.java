package com.hp.stratus.pendingassociations.consumer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.consumer.external.ExternalEventConsumer;
import com.hp.stratus.pendingassociations.consumer.internal.InternalEventConsumer;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventEnvelope;
import com.hp.stratus.pendingassociations.dto.event.internal.InternalEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageListener;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.core.SdkBytes;
import software.amazon.awssdk.services.kms.KmsClient;
import software.amazon.awssdk.services.kms.model.DecryptRequest;
import software.amazon.awssdk.services.kms.model.DecryptResponse;

import java.io.IOException;
import java.util.List;

/** Top level message consumer. */
@Component
@Primary
@Slf4j
@RequiredArgsConstructor
public class MessageConsumer implements MessageListener {

  /** Jackson mapper. */
  private final ObjectMapper mapper;

  /** List of external event consumers. */
  private final List<ExternalEventConsumer> externalEventConsumers;

  /** List of internal event consumers. */
  private final List<InternalEventConsumer> internalEventConsumers;

  /** KMS client to use. */
  private final KmsClient kmsClient;

  /** Specifies the decryption key to use. */
  @Value("${event.decryption.key}")
  private String decryptionKey;

  /**
   * Handles an incoming message.
   *
   * @param message The message to handle.
   */
  @Override
  public void onMessage(Message message) {

    // Handle internal events
    if (InternalEvent.INTERNAL_EVENT_APP_ID.equals(message.getMessageProperties().getAppId())) {
      handleInternal(message);
      return;
    }

    // Handle external events
    handleExternal(message);
  }

  /**
   * Hanldes the supplied internal message.
   *
   * @param message The message.
   */
  private void handleInternal(Message message) {

    // Parse into an internal event, If parsing fails, dead letter the message
    InternalEvent event;
    try {
      event = mapper.readValue(message.getBody(), InternalEvent.class);
    } catch (IOException e) {
      log.warn("Dropped internal event with invalid JSON encoding", e);
      throw new AmqpRejectAndDontRequeueException(e);
    }

    // Hand the message off to the relevant consumer
    for (InternalEventConsumer consumer : internalEventConsumers) {
      if (consumer.eventType() == event.getType()) {
        consumer.handleEvent(event);
        return;
      }
    }

    log.debug(
        "Failed to find matching consumer for internal event {}, ignoring...", event.getType());
  }

  /**
   * Handles the supplied external message.
   *
   * @param message The message.
   */
  private void handleExternal(Message message) {

    // Decrypt the message
    byte[] decrypted;
    try {
      decrypted = decrypt(message);
    } catch (Exception e) {
      log.warn("Dropped external event with invalid encryption", e);
      throw new AmqpRejectAndDontRequeueException(e);
    }

    // Parse as JSON. If there are any failures, dead letter the message
    StratusEventEnvelope envelope;
    try {
      envelope = mapper.readValue(decrypted, StratusEventEnvelope.class);
    } catch (IOException e) {
      log.warn("Dropped external event with invalid JSON encoding", e);
      throw new AmqpRejectAndDontRequeueException(e);
    }

    // Hand the message off to the relevant consumer
    for (ExternalEventConsumer consumer : externalEventConsumers) {
      if (consumer.eventType() == envelope.getEvent()
          && consumer.eventResource() == envelope.getFqResourceName()) {
        consumer.handleEvent(envelope);
        return;
      }
    }

    log.debug(
        "Failed to find matching consumer for external event {}, ignoring...",
        envelope.getFqResourceName().getValue());
  }

  /**
   * Decrypts the provided message.
   *
   * @return The decrypted bytes.
   */
  private byte[] decrypt(Message message) {

    // Construct the decryption request
    DecryptRequest decryptRequest =
        DecryptRequest.builder()
            .keyId(decryptionKey)
            .ciphertextBlob(SdkBytes.fromByteArray(message.getBody()))
            .build();

    // And decrypt the bytes
    DecryptResponse decryptResponse = kmsClient.decrypt(decryptRequest);
    return decryptResponse.plaintext().asByteArray();
  }
}
