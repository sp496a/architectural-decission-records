package com.hp.stratus.pendingassociations.dto;

import lombok.Data;

/** Represents the health response */
@Data
public class HealthResponse {
  private String name;
  private String status;
}
