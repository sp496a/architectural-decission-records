package com.hp.stratus.pendingassociations.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.util.Arrays;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

/** The type of criteria */
@AllArgsConstructor
public enum CriteriaType {
  EVENT_RECEIVED("eventReceived");

  @Getter @JsonValue private final String value;

  @JsonCreator
  public static CriteriaType fromValue(String text) {
    return Arrays.stream(values())
        .filter(val -> StringUtils.equalsIgnoreCase(val.getValue(), text))
        .findAny()
        .orElse(null);
  }
}
