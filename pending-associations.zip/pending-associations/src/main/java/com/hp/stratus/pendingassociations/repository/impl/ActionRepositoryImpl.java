package com.hp.stratus.pendingassociations.repository.impl;

import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.repository.ActionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.UUID;

/** Repository implementation for actions related to association actions. */
@Repository
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class ActionRepositoryImpl implements ActionRepository {

  /** The mongo template to use for queries. */
  private final MongoTemplate mongoTemplate;

  /**
   * Resolves an action by index.
   *
   * @param associationId The association ID.
   * @param actionIndex The index of the action.
   * @param resolutionObject The resolution object to set.
   * @return The number of updated records.
   */
  @Override
  public boolean resolveAction(UUID associationId, int actionIndex, Object resolutionObject) {

    // Construct the query
    Query query = new Query();
    query.addCriteria(Criteria.where("id").is(associationId));

    // Construct the update definition
    Update update = new Update();
    update.set("actions." + actionIndex + ".completedAt", LocalDateTime.now());
    update.set("actions." + actionIndex + ".completedWith", resolutionObject);

    return mongoTemplate.updateMulti(query, update, Association.class).getModifiedCount() > 0;
  }
}
