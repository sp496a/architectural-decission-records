package com.hp.stratus.pendingassociations.model;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class Criteria {
  private CriteriaType type;
  private Condition condition;
  private Conditions conditions;
  private CriteriaState state;
  private LocalDateTime createdAt;
  private LocalDateTime resolvedAt;
  private Object resolvedWith;
  private CriteriaDetails details;
}
