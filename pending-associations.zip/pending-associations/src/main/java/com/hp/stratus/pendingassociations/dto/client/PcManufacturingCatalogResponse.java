package com.hp.stratus.pendingassociations.dto.client;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;

import java.util.List;

/** PC manufacturing catalog response DTO. */
@Data
@Getter
public class PcManufacturingCatalogResponse {

  @JsonProperty("version")
  private String version;

  @JsonProperty("devices")
  private List<PcManufacturingCatalogDevice> devices;
}
