package com.hp.stratus.pendingassociations.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.http.client.utils.HttpClient;
import com.hp.stratus.pendingassociations.auth.Scope;
import com.hp.stratus.pendingassociations.dto.client.EventRegistrationRequest;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventAttribute;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventEnvelope;
import com.hp.stratus.pendingassociations.dto.event.internal.InternalEvent;
import com.hp.stratus.pendingassociations.dto.event.internal.InternalEventType;
import com.hp.stratus.pendingassociations.exceptions.BadGatewayException;
import com.hp.stratus.pendingassociations.exceptions.BadRequestException;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.service.EventService;
import com.hp.stratus.pendingassociations.utils.AssociationMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.core.MessagePropertiesBuilder;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

/** Handles API calls to the event management service. */
@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
@Slf4j
public class EventServiceImpl implements EventService {

  private static final String EVENT_PROTOCOL = "AWSSNS";
  private static final String EVENT_OBJECT_KEY = "eventObject";
  private static final String ATTRIBUTE_TYPE = "String";

  /** Jackson object mapper */
  private final ObjectMapper objectMapper;

  /** Basic HTTP client. */
  private final HttpClient client;

  /** The rabbitMQ template for internal events. */
  private final RabbitTemplate rabbitTemplate;

  /** Supplier for JWT tokens. */
  @Qualifier("jwtSupplier")
  private final Supplier<String> jwtSupplier;

  /** Service name to use as the user-agent. */
  @Value("${authz.service.name}")
  private final String serviceName;

  /** Base URL for stratus services. */
  @Value("${stratus.base.url}")
  private final String baseUrl;

  /** Endpoint for subscribing to events. */
  @Value("${stratus.event.subscribe.endpoint}")
  private final String subscribeEndpoint;

  /** Endpoint for publishing events. */
  @Value("${stratus.event.publish.endpoint}")
  private final String publishEndpoint;

  /** Topic for event subscriptions. */
  @Value("${event.topic}")
  private final String eventTopic;

  /** RabbitMQ exchange to publish to for internal events. */
  @Value("${rabbitmq.exchange}")
  private final String internalExchange;

  /**
   * Subscribes to the supplied resource.
   *
   * @param resource The resource to subscribe to.
   */
  public void subscribeToResource(ExternalEventResource resource) {

    // Construct the registration URI
    String uri = UriComponentsBuilder.fromUriString(baseUrl).path(subscribeEndpoint).toUriString();

    // Build the request
    EventRegistrationRequest req =
        EventRegistrationRequest.builder()
            .protocol(EVENT_PROTOCOL)
            .topicResourceName(eventTopic)
            .externalEventResource(resource)
            .build();

    // Make the request
    ResponseEntity<Void> response;
    try {
      response =
          client.post(
              uri,
              jwtSupplier.get(),
              Map.of(HttpHeaders.USER_AGENT, serviceName),
              req,
              new ParameterizedTypeReference<>() {});
    } catch (Exception e) {
      log.warn("Failed to subscribe to resource {}: {}", resource, e);
      return;
    }

    // Check the status code
    if (response.getStatusCode() == HttpStatus.OK) {
      log.info("Successfully registered event consumer for resource {}", resource);
    } else {
      log.warn("Failed to register event consumer: Response code={}", response.getStatusCode());
    }
  }

  /**
   * Publishes an association update event.
   *
   * @param association The association.
   * @throws BadGatewayException When event management responds with a 5xx.
   * @throws BadRequestException When event management responds with a non-5xx error.
   */
  public void publishAssociationUpdate(Association association)
      throws BadGatewayException, BadRequestException {

    // Construct the envelope
    StratusEventEnvelope envelope =
        StratusEventEnvelope.builder()
            .event(ExternalEventType.UPDATED)
            .fqResourceName(ExternalEventResource.PENDING_ASSOCIATION)
            .resourceId(association.getId().toString())
            .tenantResourceId(association.getTenantId())
            .scopes(List.of(Scope.READ.toString()))
            .resource(ExternalEventResource.PENDING_ASSOCIATION.toString())
            .build();

    // Construct the attribute
    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setDataType(ATTRIBUTE_TYPE);
    try {
      attribute.setStringValue(
          objectMapper.writeValueAsString(AssociationMapper.toAssociationDto(association)));
    } catch (JsonProcessingException e) {
      log.error("Failed to stringify association: {}", e.getMessage());
    }

    // And the attribute map
    envelope.setEventAttributeValueMap(Map.of(EVENT_OBJECT_KEY, attribute));

    // Publish the envelope
    publish(envelope);
  }

  /**
   * Publishes a criteria resolved event.
   *
   * @param associationId The association ID.
   */
  public void publishCriteriaResolved(UUID associationId) {
    publish(
        InternalEvent.builder()
            .type(InternalEventType.CRITERIA_RESOLVED)
            .association(associationId)
            .build());
  }

  /**
   * Publishes a criteria resolved event.
   *
   * @param associationId The association ID.
   */
  public void publishExecuteNextAction(UUID associationId) {
    publish(
        InternalEvent.builder()
            .type(InternalEventType.EXECUTE_NEXT_ACTION)
            .association(associationId)
            .build());
  }

  /**
   * Publishes an association update event.
   *
   * @param associationId The association ID to publish.
   */
  public void publishFireAssociationUpdate(UUID associationId) {
    publish(
        InternalEvent.builder()
            .type(InternalEventType.PUBLISH_FIRE_ASSOCIATION_UPDATE)
            .association(associationId)
            .build());
  }

  /**
   * Publishes the supplied event to event management.
   *
   * @param envelope The envelope to publish.
   * @throws BadGatewayException When event management responds with a 5xx.
   * @throws BadRequestException When event management responds with a non-5xx error.
   */
  private void publish(StratusEventEnvelope envelope)
      throws BadGatewayException, BadRequestException {

    // Construct the URI
    String uri = UriComponentsBuilder.fromUriString(baseUrl).path(publishEndpoint).toUriString();

    // And send the request
    try {
      client.post(uri, jwtSupplier.get(), envelope, new ParameterizedTypeReference<>() {});
      log.info("Successfully published event {}", envelope.getFqResourceName());
    } catch (HttpClientErrorException e) {
      log.warn(
          "Received a client error when publishing event {}:", envelope.getFqResourceName(), e);
      throw new BadRequestException("Failed to POST to event management", e);
    } catch (HttpServerErrorException e) {
      log.warn("Failed to publish event: Response code={}. Retrying...", e.getStatusCode(), e);
      throw new BadGatewayException("Failed to publish to event management");
    } catch (Exception e) {
      log.warn("Encountered a network error when publishing event. Retrying...", e);
      throw new BadGatewayException("Failed to publish to event management");
    }
  }

  /**
   * Publishes an internal event.
   *
   * @param event The event to publish.
   */
  private void publish(InternalEvent event) {

    // JSON encode the message
    byte[] messageBytes;
    try {
      messageBytes = objectMapper.writeValueAsBytes(event);
    } catch (JsonProcessingException e) {
      log.error("Failed to json encode internal event: {}", e.getMessage());
      return;
    }

    // Build the message properties
    MessageProperties properties =
        MessagePropertiesBuilder.newInstance()
            .setAppId(InternalEvent.INTERNAL_EVENT_APP_ID)
            .build();

    // Build the message object
    Message message = MessageBuilder.withBody(messageBytes).andProperties(properties).build();

    // And send it
    rabbitTemplate.send(internalExchange, "", message);
  }
}
