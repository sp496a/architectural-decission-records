package com.hp.stratus.pendingassociations.dto;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

import java.util.HashMap;
import java.util.Map;

/** The resource to apply the action to */
@Data
@Validated
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResourcesDto {

  Map<String, ResourceIdDto> untypedResources = new HashMap<>();

  @JsonProperty("user")
  private ResourceDto user;

  @JsonProperty("device")
  private ResourceDto device;

  @JsonAnySetter
  void setUntypedResources(String key, ResourceIdDto value) {
    untypedResources.put(key, value);
  }

  @JsonAnyGetter
  public Map<String, ResourceIdDto> getUntypedResources() {
    return untypedResources;
  }
}
