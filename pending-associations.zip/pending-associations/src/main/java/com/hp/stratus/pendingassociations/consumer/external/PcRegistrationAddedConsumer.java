package com.hp.stratus.pendingassociations.consumer.external;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventAttribute;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventEnvelope;
import com.hp.stratus.pendingassociations.service.CriteriaService;
import com.hp.stratus.pendingassociations.service.EventService;
import com.hp.stratus.pendingassociations.utils.EventUtils;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.stereotype.Component;

import javax.json.JsonStructure;
import java.util.Map;

/** A basic abstract consumer for events, indicating the type of events it handles. */
@Component
@Slf4j
@RequiredArgsConstructor
public class PcRegistrationAddedConsumer implements ExternalEventConsumer {

  /** Service for evaluating criteria. */
  private final CriteriaService criteriaService;

  /** Service for subscribing to events. */
  private final EventService eventService;

  /** JSON Mapper. */
  private final ObjectMapper objectMapper;

  /** Indicates the resource name this consumer handles. */
  @Override
  public ExternalEventResource eventResource() {
    return ExternalEventResource.PC_REGISTRATION;
  }

  /** Indicates the event types this consumer handles. */
  @Override
  public ExternalEventType eventType() {
    return ExternalEventType.ADDED;
  }

  /** Subscribe automatically to the required resource. */
  @PostConstruct
  public void subscribeToResource() {
    eventService.subscribeToResource(eventResource());
  }

  /**
   * Handles the events.
   *
   * @param event The event to handle.
   */
  @Override
  public void handleEvent(StratusEventEnvelope event) {

    // Extract the event attribute. If it's missing, dead letter the message
    StratusEventAttribute attribute = EventUtils.getEventObjectAttribute(event);
    if (attribute == null) {
      log.warn("No event object found in pc registration event, ignoring...");
      throw new AmqpRejectAndDontRequeueException("No event object found in pc registration event");
    }

    // Parse the attribute into a structure
    JsonStructure eventDetail = EventUtils.getEventDetailStructure(attribute);
    if (eventDetail == null) {
      log.warn("Failed to read pc registration event details into a JSON structure, ignoring...");
      throw new AmqpRejectAndDontRequeueException(
          "Failed to read pc registration event details into a JSON structure");
    }

    // And into a map, so we can use it as the resolution object
    Map<String, Object> resolutionObject = EventUtils.getEventDetailMap(objectMapper, attribute);
    if (resolutionObject == null) {
      log.warn("Failed to read pc registration event details into a map, ignoring...");
      throw new AmqpRejectAndDontRequeueException(
          "Failed to read pc registration event details into a map");
    }

    // And resolve event based associations
    criteriaService.resolveEventBasedCriteria(
        ExternalEventResource.PC_REGISTRATION,
        ExternalEventType.ADDED,
        eventDetail,
        resolutionObject);
  }
}