package com.hp.stratus.pendingassociations.repository;

import com.hp.stratus.pendingassociations.model.Association;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.UUID;

public interface AssociationRepository {

  /**
   * Creates a new association.
   *
   * @param association The association to create.
   * @return The created association
   */
  Association insert(Association association);

  /**
   * Finds an association by ID.
   *
   * @param id The association ID.
   * @return The matching association.
   */
  Association findById(UUID id);

  /**
   * Writes the supplied association to the DB.
   *
   * @param association The association to save.
   * @return The saved association.
   */
  Association save(Association association);

  /**
   * Retrieves associations with pagination.
   *
   * @param pageable Pagination settings.
   * @return Paged association list.
   */
  Page<Association> getPagedAssociationList(Pageable pageable);

  /**
   * Searches associations with the supplied criteria.
   *
   * @param pageable Pagination settings.
   * @param criteria The search criteria.
   * @param value The value to compare against.
   * @return Paged association list.
   */
  Page<Association> getGenericSearchPagedAssociationList(
      Pageable pageable, String criteria, String value);

  /**
   * Gets the total count of associations.
   *
   * @return total number of associations.
   */
  long count();
}
