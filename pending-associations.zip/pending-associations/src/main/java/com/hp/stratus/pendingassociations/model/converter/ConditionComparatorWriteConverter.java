package com.hp.stratus.pendingassociations.model.converter;

import com.hp.stratus.pendingassociations.model.ConditionComparator;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.WritingConverter;

@WritingConverter
public class ConditionComparatorWriteConverter implements Converter<ConditionComparator, String> {

  @Override
  public String convert(ConditionComparator source) {
    return source.getValue();
  }
}
