package com.hp.stratus.pendingassociations.model.aggregation;

/** A simple enum used to differentiate between value 1 and value 2 in conditions. */
public enum ConditionValueField {
  value1,
  value2
}
