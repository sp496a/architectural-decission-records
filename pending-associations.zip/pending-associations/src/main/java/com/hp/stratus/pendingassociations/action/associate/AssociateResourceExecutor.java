package com.hp.stratus.pendingassociations.action.associate;

import com.hp.stratus.pendingassociations.exceptions.ActionExecutionException;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.Resource;
import com.hp.stratus.pendingassociations.model.ResourceType;

/** Executor for associating resources. */
public interface AssociateResourceExecutor {

  /**
   * Gets the resource type handled by this executor.
   *
   * @return The resource type handled by this executor.
   */
  ResourceType getResourceType();

  /**
   * Executes the executor.
   *
   * @param deviceResource The device resource to associate.
   * @param association The association.
   * @param actionIndex The action index of the association.
   * @throws ActionExecutionException When action execution fails.
   */
  void execute(Resource deviceResource, Association association, int actionIndex)
      throws ActionExecutionException;
}
