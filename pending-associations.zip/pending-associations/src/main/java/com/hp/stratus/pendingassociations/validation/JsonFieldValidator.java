package com.hp.stratus.pendingassociations.validation;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * JSON field validator to validate a field defined as Object type but should be null/json
 * object/json array
 */
@Slf4j
public class JsonFieldValidator implements ConstraintValidator<JsonFieldValidation, Object> {

  private ObjectMapper objectMapper = new ObjectMapper();

  @Override
  public void initialize(JsonFieldValidation jsonValidation) {}

  /**
   * validate method will be invoked when JsonFieldValidation annotation applied to a field
   *
   * @param value the object to do validation
   * @param context
   * @return true when object a null/HashMap(when json object)/ArrayList(when json array); false for
   *     other cases
   */
  @Override
  public boolean isValid(Object value, ConstraintValidatorContext context) {
    // when null value, return true
    if (value == null) {
      return true;
    }
    // json object format object converted to HashMap: return true
    if (value instanceof HashMap) {
      return true;
    }
    // json array format, only pass when json object array: return true
    if (value instanceof ArrayList
        && ((ArrayList) value).stream().allMatch(obj -> obj instanceof HashMap)) {
      return true;
    }

    log.debug("json field validation : {} input is not correct json format for this field", value);
    // default
    return false;
  }
}
