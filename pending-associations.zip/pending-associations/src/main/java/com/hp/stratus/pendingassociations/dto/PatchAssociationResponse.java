package com.hp.stratus.pendingassociations.dto;

import lombok.Getter;
import lombok.Setter;

/** Represents the patch association api response */
@Getter
@Setter
public class PatchAssociationResponse extends AssociationDto {}
