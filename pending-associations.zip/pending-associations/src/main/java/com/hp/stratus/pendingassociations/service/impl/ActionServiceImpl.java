package com.hp.stratus.pendingassociations.service.impl;

import com.hp.stratus.pendingassociations.action.ActionExecutor;
import com.hp.stratus.pendingassociations.exceptions.ActionExecutionException;
import com.hp.stratus.pendingassociations.model.Action;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.State;
import com.hp.stratus.pendingassociations.repository.AssociationRepository;
import com.hp.stratus.pendingassociations.service.ActionService;
import com.hp.stratus.pendingassociations.service.AssociationService;
import com.hp.stratus.pendingassociations.service.EventService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

/** Service for executing association actions. */
@Slf4j
@Service
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class ActionServiceImpl implements ActionService {

  /** Suffix for keys in redis for when we're executing actions for a given association */
  private static final String EXECUTING_SUFFIX = ".executing";

  /** Template for storing values in Redis. */
  private final RedisTemplate<String, Boolean> redis;

  /** The service for firing events. */
  private final EventService eventService;

  /** The association service. */
  private final AssociationService associationService;

  /** The association repository for fetching associations from the DB. */
  private final AssociationRepository associationRepository;

  /** List of action executors. */
  private final List<ActionExecutor> actionExecutors;

  /**
   * Begins execution of actions for the association with the specified ID.
   *
   * @param id The association ID.
   */
  @Override
  public void beginExecution(UUID id) {

    // Set the execution flag in redis if required
    Boolean newExecution = redis.opsForValue().setIfAbsent(executionLock(id), true);
    if (Boolean.FALSE.equals(newExecution)) {
      log.debug(
          "Association with ID {} is already being executed. Ignoring execution event...", id);
      return;
    }

    // Fetch the association. If it's not found, remove the execution lock and drop the message
    Association association = associationRepository.findById(id);
    if (association == null) {
      log.debug("Association with ID {} does not exist. Ignoring execution event...", id);
      redis.delete(executionLock(id));
      return;
    }

    // If the association is not in a pending state, remove the execution lock and drop the message
    if (association.getState() != State.PENDING) {
      log.debug(
          "Association with ID {} is not in a pending state. Ignoring execution event...", id);
      redis.delete(executionLock(id));
      return;
    }

    // Fire an event to begin execution of the first action
    eventService.publishExecuteNextAction(association.getId());
  }

  /**
   * Executes the next action in the given association.
   *
   * @param id The association ID.
   */
  public void executeNextAction(UUID id) {

    // Fetch the association. If it's not found, remove the execution lock and drop the message
    Association association = associationRepository.findById(id);
    if (association == null) {
      log.debug("Association with ID {} does not exist. Ignoring next action event...", id);
      redis.delete(executionLock(id));
      return;
    }

    // If the association is not pending, drop the message and clear the execution lock
    if (association.getState() != State.PENDING) {
      log.debug(
          "Association with ID {} is not in a pending state. Ignoring next action event...", id);
      redis.delete(executionLock(id));
      return;
    }

    // Fetch the index of the first unresolved action. If there are none, complete the association
    int actionIndex = getFirstUnresolvedActionIndex(association);
    if (actionIndex == -1) {
      log.debug("Association {} has no more actions. Completing...", association.getId());
      completeAssociation(association);
      log.debug("Successfully completed association {}", association.getId());
      return;
    }

    // Find the relevant action executor
    Action action = association.getActions().get(actionIndex);
    ActionExecutor executor =
        actionExecutors.stream()
            .filter(a -> a.getOperation() == action.getOperation())
            .findFirst()
            .orElse(null);

    // No matching executors found. This association should not have been inserted, and can never
    // complete. Cancel it and clear the execution lock.
    if (executor == null) {
      log.warn(
          "Failed to find executor for operation {} for association {}. Cancelling...",
          action.getOperation(),
          association.getId());
      cancelAssociation(association);
      return;
    }

    // Execute the action
    try {
      executor.execute(association, action, actionIndex);
    } catch (ActionExecutionException e) {

      // If the action is not retryable, cancel the association
      if (!e.isRetryable()) {
        log.warn("Failed to complete action in association {}:", association.getId(), e);
        cancelAssociation(association);
        return;
      }

      // The error is retryable, throw an exception so we requeue the request
      log.info("Retrying action {} for association {}", actionIndex, association.getId());
      throw e;

    } catch (Exception e) {
      log.warn("Failed to complete action in association {}:", association.getId(), e);
      cancelAssociation(association);
    }
  }

  /**
   * Completes the supplied association and clears the execution lock.
   *
   * @param association The association to complete.
   */
  private void completeAssociation(Association association) {
    associationService.completeAssociation(association);
    redis.delete(executionLock(association.getId()));
  }

  /**
   * Cancels the supplied association and clears the execution lock.
   *
   * @param association The association to cancel.
   */
  private void cancelAssociation(Association association) {
    associationService.cancelAssociation(association);
    redis.delete(executionLock(association.getId()));
  }

  /**
   * Gets the first unresolved action from the supplied association, or null if there aren't any.
   *
   * @param association The association.
   * @return The first unresolved action, or null if there aren't any
   */
  private int getFirstUnresolvedActionIndex(Association association) {
    for (int i = 0; i < association.getActions().size(); i++) {
      if (association.getActions().get(i).getCompletedAt() == null) {
        return i;
      }
    }
    return -1;
  }

  /**
   * Gets the key for the execution lock.
   *
   * @param associationId The association ID.
   * @return The key string for the execution lock.
   */
  private String executionLock(UUID associationId) {
    return associationId + EXECUTING_SUFFIX;
  }
}
