package com.hp.stratus.pendingassociations.action.updateMetadata;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.exceptions.ActionExecutionException;
import com.hp.stratus.pendingassociations.exceptions.ResourceResolutionException;
import com.hp.stratus.pendingassociations.model.*;
import com.hp.stratus.pendingassociations.repository.ActionRepository;
import com.hp.stratus.pendingassociations.repository.AssociationRepository;
import com.hp.stratus.pendingassociations.service.EventService;
import com.hp.stratus.pendingassociations.utils.PathResolver;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
class UpdateMetadataExecutorTest {

  @Mock AssociationRepository repository;
  @Mock ActionRepository actionRepository;
  @Mock EventService eventService;

  private UpdateMetadataExecutor executor;

  @BeforeEach
  void setup() {
    ObjectMapper objectMapper = new ObjectMapper();
    PathResolver pathResolver = new PathResolver(objectMapper);
    executor =
        new UpdateMetadataExecutor(
            repository, actionRepository, objectMapper, pathResolver, eventService);
  }

  @Test
  void getOperation_returnsTheCorrectActionName() {
    Operation operationResult = executor.getOperation();

    assertEquals(Operation.UPDATE_METADATA, operationResult);
  }

  @Test
  void execute_throwsWithNullResources() {
    Action action = new Action();
    Association association = new Association();

    assertThrows(ResourceResolutionException.class, () -> executor.execute(association, action, 0));
  }

  @Test
  void execute_throwsWithoutResources() {
    Action action = new Action();
    Association association = new Association();
    Resources resources = new Resources();
    action.setResources(resources);
    association.setActions(List.of(action));

    assertThrows(ResourceResolutionException.class, () -> executor.execute(association, action, 0));
  }

  @Test
  void execute_initializesTheMetadataMap() {
    Action action = new Action();
    Association association = new Association();
    Resources resources = new Resources();
    Map<String, ResourceId> untypedResources = new HashMap<>();
    ResourceId resourcesId = new ResourceId();
    resourcesId.setType(ResourceIdType.STRING);
    resourcesId.setValue("testValue");
    untypedResources.put("testKey", resourcesId);
    resources.setUntypedResources(untypedResources);
    action.setResources(resources);
    association.setActions(List.of(action));
    when(repository.save(any())).thenReturn(association);

    executor.execute(association, action, 0);

    assertEquals(1, association.getMetadata().size());
    verify(repository, times(1)).save(association);
  }

  @Test
  void execute_updatesTheMetadataMap() {
    Action action = new Action();
    Association association = new Association();
    Resources resources = new Resources();
    Map<String, ResourceId> untypedResources = new HashMap<>();
    ResourceId resourcesId = new ResourceId();
    resourcesId.setType(ResourceIdType.STRING);
    resourcesId.setValue("testValue");
    untypedResources.put("testKey", resourcesId);
    resources.setUntypedResources(untypedResources);
    action.setResources(resources);
    association.setActions(List.of(action));
    Map<String, Object> existingMetadata = new HashMap<>();
    existingMetadata.put("existingKey", "existingValue");
    association.setMetadata(existingMetadata);
    when(repository.save(any())).thenReturn(association);

    executor.execute(association, action, 0);

    assertEquals(2, association.getMetadata().size());
    verify(repository, times(1)).save(association);
  }

  @Test
  void execute_doesntFireTheNextActionEventIfNoActionsWereResolved() {
    Action action = new Action();
    Association association = new Association();
    Resources resources = new Resources();
    Map<String, ResourceId> untypedResources = new HashMap<>();
    ResourceId resourcesId = new ResourceId();
    resourcesId.setType(ResourceIdType.STRING);
    resourcesId.setValue("testValue");
    untypedResources.put("testKey", resourcesId);
    resources.setUntypedResources(untypedResources);
    action.setResources(resources);
    association.setActions(List.of(action));
    when(repository.save(any())).thenReturn(association);
    when(actionRepository.resolveAction(any(), anyInt(), any())).thenReturn(false);

    executor.execute(association, action, 0);

    verify(eventService, times(0)).publishExecuteNextAction(any());
  }

  @Test
  void execute_firesTheNextActionEventIfActionWasResolved() {
    Action action = new Action();
    Association association = new Association();
    Resources resources = new Resources();
    Map<String, ResourceId> untypedResources = new HashMap<>();
    ResourceId resourcesId = new ResourceId();
    resourcesId.setType(ResourceIdType.STRING);
    resourcesId.setValue("testValue");
    untypedResources.put("testKey", resourcesId);
    resources.setUntypedResources(untypedResources);
    action.setResources(resources);
    association.setActions(List.of(action));
    when(repository.save(any())).thenReturn(association);
    when(actionRepository.resolveAction(any(), anyInt(), any())).thenReturn(true);

    executor.execute(association, action, 0);

    verify(eventService, times(1)).publishExecuteNextAction(any());
  }

  @Test
  void execute_throwsUnretryableActionExecutionException() {
    Action action = new Action();
    Association association = new Association();
    Resources resources = new Resources();
    Map<String, ResourceId> untypedResources = new HashMap<>();
    ResourceId resourcesId = new ResourceId();
    resourcesId.setType(ResourceIdType.STRING);
    resourcesId.setValue("testValue");
    untypedResources.put("testKey", resourcesId);
    resources.setUntypedResources(untypedResources);
    action.setResources(resources);
    association.setActions(List.of(action));
    when(repository.save(any())).thenThrow(new RuntimeException("whoops"));

    ActionExecutionException exception =
        assertThrows(
            ActionExecutionException.class, () -> executor.execute(association, action, 1));

    assertFalse(exception.isRetryable());
  }
}
