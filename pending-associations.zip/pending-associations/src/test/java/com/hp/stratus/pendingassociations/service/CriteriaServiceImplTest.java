package com.hp.stratus.pendingassociations.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventEnvelope;
import com.hp.stratus.pendingassociations.model.*;
import com.hp.stratus.pendingassociations.model.aggregation.AggregatePointerResult;
import com.hp.stratus.pendingassociations.model.aggregation.ConditionValueField;
import com.hp.stratus.pendingassociations.repository.CriteriaRepository;
import com.hp.stratus.pendingassociations.service.impl.CriteriaServiceImpl;
import com.hp.stratus.pendingassociations.utils.EventUtils;
import com.hp.stratus.pendingassociations.utils.PathResolver;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.json.Json;
import javax.json.JsonStructure;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource.FULFILLMENT_TRADE_ORDER;
import static com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType.UPDATED;
import static com.hp.stratus.pendingassociations.model.ConditionValueType.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
public class CriteriaServiceImplTest {
  private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
  private final PathResolver pathResolver = new PathResolver(OBJECT_MAPPER);
  @Mock private CriteriaRepository criteriaRepository;
  @Mock private EventService eventService;
  private CriteriaServiceImpl criteriaService;
  private JsonStructure event;
  private JsonStructure fulfillmentEventStructure;

  @BeforeEach
  void setup() throws IOException {
    criteriaService = new CriteriaServiceImpl(criteriaRepository, eventService, pathResolver);
    pathResolver.setup();
    event =
        Json.createReader(
                new FileReader("src/test/resources/data/dto/PrinterRegistrationEventObject.json"))
            .read();
    StratusEventEnvelope eventEnvelope =
        OBJECT_MAPPER.readValue(
            new FileReader("src/test/resources/data/dto/FulfillmentTradeOrderEvent.json"),
            StratusEventEnvelope.class);
    Map<String, Object> eventMap = EventUtils.getEventAttributeMap(OBJECT_MAPPER, eventEnvelope);
    fulfillmentEventStructure = EventUtils.convertToJsonStructure(OBJECT_MAPPER, eventMap);
  }

  @Test
  void resolveEventBasedCriteria_resolvesNothingIfPointerIsNotResolved() {
    AggregatePointerResult result = new AggregatePointerResult();
    result.setPointer("invalidPointer");
    result.setComparator(ConditionComparator.EQUALS);
    result.setCompareTo(ConditionValueField.value1);
    when(criteriaRepository.findUniquePendingEventPointers(
            eq(ExternalEventResource.PRINTER_REGISTRATION), eq(ExternalEventType.ADDED)))
        .thenReturn(List.of(result));

    criteriaService.resolveEventBasedCriteria(
        ExternalEventResource.PRINTER_REGISTRATION, ExternalEventType.ADDED, event, null);

    verify(criteriaRepository, times(0)).resolvePendingCriteria(any(), any(), any(), any());
  }

  @Test
  void resolveEventBasedCriteria_continuesIfNothingIsResolved() {
    AggregatePointerResult result = new AggregatePointerResult();
    result.setPointer("/version");
    result.setComparator(ConditionComparator.EQUALS);
    result.setCompareTo(ConditionValueField.value1);
    when(criteriaRepository.findUniquePendingEventPointers(
            eq(ExternalEventResource.PRINTER_REGISTRATION), eq(ExternalEventType.ADDED)))
        .thenReturn(List.of(result));
    when(criteriaRepository.resolvePendingCriteria(any(), any(), any(), any())).thenReturn(0L);

    criteriaService.resolveEventBasedCriteria(
        ExternalEventResource.PRINTER_REGISTRATION, ExternalEventType.ADDED, event, null);

    verify(criteriaRepository, times(1)).resolvePendingCriteria(any(), any(), any(), any());
    verify(criteriaRepository, times(0)).getPendingAssociationsWithCompletedCriteria();
  }

  @Test
  void resolveEventBasedCriteria_continuesIfNoAssociationsAreComplete() {
    AggregatePointerResult result = new AggregatePointerResult();
    result.setPointer("/version");
    result.setComparator(ConditionComparator.EQUALS);
    result.setCompareTo(ConditionValueField.value1);
    when(criteriaRepository.findUniquePendingEventPointers(
            eq(ExternalEventResource.PRINTER_REGISTRATION), eq(ExternalEventType.ADDED)))
        .thenReturn(List.of(result));
    when(criteriaRepository.resolvePendingCriteria(any(), any(), any(), any())).thenReturn(1L);
    when(criteriaRepository.getPendingAssociationsWithCompletedCriteria()).thenReturn(List.of());

    criteriaService.resolveEventBasedCriteria(
        ExternalEventResource.PRINTER_REGISTRATION, ExternalEventType.ADDED, event, null);

    verify(criteriaRepository, times(1)).getPendingAssociationsWithCompletedCriteria();
    verify(eventService, times(0)).publishCriteriaResolved(any());
  }

  @Test
  void resolveEventBasedCriteria_firesCriteriaResolvedForResolvedAssociations() {
    AggregatePointerResult result = new AggregatePointerResult();
    result.setPointer("/version");
    result.setComparator(ConditionComparator.EQUALS);
    result.setCompareTo(ConditionValueField.value1);
    when(criteriaRepository.findUniquePendingEventPointers(
            eq(ExternalEventResource.PRINTER_REGISTRATION), eq(ExternalEventType.ADDED)))
        .thenReturn(List.of(result));
    when(criteriaRepository.resolvePendingCriteria(any(), any(), any(), any())).thenReturn(1L);
    when(criteriaRepository.getPendingAssociationsWithCompletedCriteria())
        .thenReturn(List.of(new Association()));

    criteriaService.resolveEventBasedCriteria(
        ExternalEventResource.PRINTER_REGISTRATION, ExternalEventType.ADDED, event, null);

    verify(eventService, times(1)).publishCriteriaResolved(any());
  }

  @Test
  void resolveConditionCriteriaHack() {
    ConditionValue valuePointer1 = buildConditionValue(POINTER, "/fulfillmentOrderId");
    ConditionValue valueString1 =
        buildConditionValue(STRING, "ea587d6b-6c7b-4742-892c-dc35d1bfca07");
    ConditionValue valuePath2 = buildConditionValue(PATH, "$.parts[*].modelSku");
    ConditionValue valueString2 = buildConditionValue(STRING, "889T1AA#ABA");

    Condition condition1 = buildCondition(valuePointer1, valueString1);
    Condition condition2 = buildCondition(valuePath2, valueString2);

    Conditions conditions = buildConditions(condition1, condition2);

    Criteria criteria = new Criteria();
    criteria.setConditions(conditions);
    criteria.setType(CriteriaType.EVENT_RECEIVED);
    criteria.setState(CriteriaState.PENDING);

    UUID id = UUID.randomUUID();
    Association association = new Association();
    association.setId(id);
    association.setState(State.PENDING);
    association.setCriteria(List.of(criteria));

    when(criteriaRepository.findAssociationsWithConditions(FULFILLMENT_TRADE_ORDER, UPDATED))
        .thenReturn(List.of(association));

    criteriaService.resolveConditionCriteriaHack(
            FULFILLMENT_TRADE_ORDER, UPDATED, Map.of(), fulfillmentEventStructure);

    verify(criteriaRepository).findAssociationsWithConditions(FULFILLMENT_TRADE_ORDER, UPDATED);
    verify(criteriaRepository).save(association);
    verify(eventService).publishCriteriaResolved(id);
  }

  @Test
  void resolveConditionCriteriaHack_noMatchingConditionForPath() {
    ConditionValue valuePointer1 = buildConditionValue(POINTER, "/fulfillmentOrderId");
    ConditionValue valueString1 =
        buildConditionValue(STRING, "ea587d6b-6c7b-4742-892c-dc35d1bfca07");
    ConditionValue valuePath2 = buildConditionValue(PATH, "$.parts[*].modelSku");
    ConditionValue valueString2 = buildConditionValue(STRING, "FakeSku");

    Condition condition1 = buildCondition(valuePointer1, valueString1);
    Condition condition2 = buildCondition(valuePath2, valueString2);

    Conditions conditions = buildConditions(condition1, condition2);

    Criteria criteria = new Criteria();
    criteria.setConditions(conditions);
    criteria.setType(CriteriaType.EVENT_RECEIVED);
    criteria.setState(CriteriaState.PENDING);

    UUID id = UUID.randomUUID();
    Association association = new Association();
    association.setId(id);
    association.setState(State.PENDING);
    association.setCriteria(List.of(criteria));

    when(criteriaRepository.findAssociationsWithConditions(FULFILLMENT_TRADE_ORDER, UPDATED))
        .thenReturn(List.of(association));

    criteriaService.resolveConditionCriteriaHack(
            FULFILLMENT_TRADE_ORDER, UPDATED, Map.of(), fulfillmentEventStructure);

    verify(criteriaRepository).findAssociationsWithConditions(FULFILLMENT_TRADE_ORDER, UPDATED);
    verify(criteriaRepository, times(0)).save(association);
    verifyNoInteractions(eventService);
  }

  @Test
  void resolveConditionCriteriaHack_noMatchingConditionForPointer() {
    ConditionValue valuePointer1 = buildConditionValue(POINTER, "/fulfillmentOrderId");
    ConditionValue valueString1 = buildConditionValue(STRING, "InvalidOrderId");

    Conditions conditions = buildConditions(buildCondition(valuePointer1, valueString1));

    Criteria criteria = new Criteria();
    criteria.setConditions(conditions);
    criteria.setType(CriteriaType.EVENT_RECEIVED);
    criteria.setState(CriteriaState.PENDING);

    UUID id = UUID.randomUUID();
    Association association = new Association();
    association.setId(id);
    association.setState(State.PENDING);
    association.setCriteria(List.of(criteria));

    when(criteriaRepository.findAssociationsWithConditions(FULFILLMENT_TRADE_ORDER, UPDATED))
        .thenReturn(List.of(association));

    criteriaService.resolveConditionCriteriaHack(
            FULFILLMENT_TRADE_ORDER, UPDATED, Map.of(), fulfillmentEventStructure);

    verify(criteriaRepository).findAssociationsWithConditions(FULFILLMENT_TRADE_ORDER, UPDATED);
    verify(criteriaRepository, times(0)).save(association);
    verifyNoInteractions(eventService);
  }

  @Test
  void resolveConditionCriteriaHack_noPendingState() {
    ConditionValue valuePointer1 = buildConditionValue(POINTER, "/fulfillmentOrderId");
    ConditionValue valueString1 = buildConditionValue(STRING, "InvalidOrderId");

    Conditions conditions = buildConditions(buildCondition(valuePointer1, valueString1));

    Criteria criteria = new Criteria();
    criteria.setConditions(conditions);
    criteria.setType(CriteriaType.EVENT_RECEIVED);
    criteria.setState(CriteriaState.RESOLVED);

    UUID id = UUID.randomUUID();
    Association association = new Association();
    association.setId(id);
    association.setState(State.PENDING);
    association.setCriteria(List.of(criteria));

    when(criteriaRepository.findAssociationsWithConditions(FULFILLMENT_TRADE_ORDER, UPDATED))
        .thenReturn(List.of(association));

    criteriaService.resolveConditionCriteriaHack(
            FULFILLMENT_TRADE_ORDER, UPDATED, Map.of(), fulfillmentEventStructure);

    verify(criteriaRepository).findAssociationsWithConditions(FULFILLMENT_TRADE_ORDER, UPDATED);
    verify(criteriaRepository, times(0)).save(association);
    verifyNoInteractions(eventService);
  }

  @Test
  void resolveConditionCriteriaHack_conditionIsNull() {
    Criteria criteria = new Criteria();
    criteria.setConditions(null);
    criteria.setType(CriteriaType.EVENT_RECEIVED);
    criteria.setState(CriteriaState.RESOLVED);

    UUID id = UUID.randomUUID();
    Association association = new Association();
    association.setId(id);
    association.setState(State.PENDING);
    association.setCriteria(List.of(criteria));

    when(criteriaRepository.findAssociationsWithConditions(FULFILLMENT_TRADE_ORDER, UPDATED))
        .thenReturn(List.of(association));

    criteriaService.resolveConditionCriteriaHack(
            FULFILLMENT_TRADE_ORDER, UPDATED, Map.of(), fulfillmentEventStructure);

    verify(criteriaRepository).findAssociationsWithConditions(FULFILLMENT_TRADE_ORDER, UPDATED);
    verify(criteriaRepository, times(0)).save(association);
    verifyNoInteractions(eventService);
  }

  @Test
  void resolveConditionCriteriaHack_noAssociation() {
    when(criteriaRepository.findAssociationsWithConditions(FULFILLMENT_TRADE_ORDER, UPDATED))
        .thenReturn(List.of());

    criteriaService.resolveConditionCriteriaHack(
            FULFILLMENT_TRADE_ORDER, UPDATED, Map.of(), fulfillmentEventStructure);

    verify(criteriaRepository).findAssociationsWithConditions(FULFILLMENT_TRADE_ORDER, UPDATED);
    verify(criteriaRepository, times(0)).save(any());
    verifyNoInteractions(eventService);
  }

  private ConditionValue buildConditionValue(ConditionValueType type, String value) {
    ConditionValue cv = new ConditionValue();
    cv.setType(type);
    cv.setValue(value);
    return cv;
  }

  private Condition buildCondition(ConditionValue value1, ConditionValue value2) {
    Condition conditions = new Condition();
    conditions.setValue1(value1);
    conditions.setValue2(value2);
    conditions.setComparator(ConditionComparator.EQUALS);
    return conditions;
  }

  private Conditions buildConditions(Condition... condition) {
    Conditions conditions = new Conditions();
    conditions.setOperator(ConditionsOperator.AND);
    conditions.setValues(condition);
    return conditions;
  }
}
