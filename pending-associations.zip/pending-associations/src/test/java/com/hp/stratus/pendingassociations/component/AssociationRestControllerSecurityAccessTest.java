package com.hp.stratus.pendingassociations.component;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.head;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.hp.stratus.auth.path.PermitAllPathProvider;
import com.hp.stratus.pendingassociations.controller.AssociationRestController;
import com.hp.stratus.pendingassociations.dto.AssociationDto;
import com.hp.stratus.pendingassociations.dto.CreateAssociationRequest;
import com.hp.stratus.pendingassociations.service.AssociationService;
import java.io.File;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

@Tag("UnitTest")
@Tag("ComponentTest")
class AssociationRestControllerSecurityAccessTest extends SecurityAccessTest {

  static final String endpointUrl = "/pending-associations/v1/associations";
  @MockBean
  AssociationService associationService;
  @InjectMocks
  AssociationRestController associationRestController;
  @MockBean
  PermitAllPathProvider permitAllPathService;
  String payload;
  private List<AssociationDto> associationDtoList;


  @BeforeEach
  void setup() throws Exception {
    super.setup();
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    var requestObj =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdate.json"),
            CreateAssociationRequest.class);
    payload = objectMapper.writeValueAsString(requestObj);
  }

  @Test
  void create_401() throws Exception {
    var result =
        mockMvc
            .perform(
                post(endpointUrl)
                    .header(HttpHeaders.AUTHORIZATION, TEST_TOKEN_401)
                    .content(payload)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON))
            .andDo(print())
            .andExpect(status().isUnauthorized())
            .andReturn();

    assertNotNull(result);
  }

  @Test
  void create_401_no_token() throws Exception {
    var result =
        mockMvc
            .perform(
                post(endpointUrl)
                    .content(payload)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON))
            .andDo(print())
            .andExpect(status().isUnauthorized())
            .andReturn();

    assertNotNull(result);
  }

  @Test
  void create_401_string_as_token() throws Exception {
    var result =
        mockMvc
            .perform(
                post(endpointUrl)
                    .header(HttpHeaders.AUTHORIZATION, "  vvvvvvvvvvvvvvvvvvv   11111111111")
                    .content(payload)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON))
            .andDo(print())
            .andExpect(status().isUnauthorized())
            .andReturn();

    assertNotNull(result);
  }

  @Test
  void create_401_Bearer_token_malformed() throws Exception {
    var result =
        mockMvc
            .perform(
                post(endpointUrl)
                    .header(HttpHeaders.AUTHORIZATION, "Bearer  vvvvvvvvvvvvvvvvvvv   11111111111")
                    .content(payload)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON))
            .andDo(print())
            .andExpect(status().isUnauthorized())
            .andReturn();

    assertNotNull(result);
  }

  //@Test
  void create_403() throws Exception {
    var result =
        mockMvc
            .perform(
                post(endpointUrl)
                    .header(HttpHeaders.AUTHORIZATION, test_token_403)
                    .content(payload)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON))
            .andDo(print())
            .andExpect(status().isForbidden())
            .andReturn();

    assertNotNull(result);
  }

  @Test
  void patch_401() throws Exception {
    var result =
        mockMvc
            .perform(
                patch(endpointUrl + "/" + UUID.randomUUID())
                    .header(HttpHeaders.AUTHORIZATION, TEST_TOKEN_401)
                    .content(payload)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON))
            .andDo(print())
            .andExpect(status().isUnauthorized())
            .andReturn();

    assertNotNull(result);
  }

  //@Test
  void patch_403() throws Exception {
    var result =
        mockMvc
            .perform(
                patch(endpointUrl + "/" + UUID.randomUUID())
                    .header(HttpHeaders.AUTHORIZATION, test_token_403)
                    .content(payload)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON))
            .andDo(print())
            .andExpect(status().isForbidden())
            .andReturn();

    assertNotNull(result);
  }

  @Test
  void get_401() throws Exception {
    var result =
        mockMvc
            .perform(
                get(endpointUrl + "/" + UUID.randomUUID())
                    .header(HttpHeaders.AUTHORIZATION, TEST_TOKEN_401)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON))
            .andDo(print())
            .andExpect(status().isUnauthorized())
            .andReturn();

    assertNotNull(result);
  }

  //@Test
  void get_403() throws Exception {
    var result =
        mockMvc
            .perform(
                get(endpointUrl + "/" + UUID.randomUUID())
                    .header(HttpHeaders.AUTHORIZATION, test_token_403)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON))
            .andDo(print())
            .andExpect(status().isForbidden())
            .andReturn();

    assertNotNull(result);
  }

  @Test
  void head_401() throws Exception {
    var result =
        mockMvc
            .perform(
                head(endpointUrl)
                    .header(HttpHeaders.AUTHORIZATION, TEST_TOKEN_401)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON))
            .andDo(print())
            .andExpect(status().isUnauthorized())
            .andReturn();

    assertNotNull(result);
  }

  //@Test
  void head_403() throws Exception {
    var result =
        mockMvc
            .perform(
                head(endpointUrl)
                    .header(HttpHeaders.AUTHORIZATION, test_token_403)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON))
            .andDo(print())
            .andExpect(status().isForbidden())
            .andReturn();

    assertNotNull(result);
  }

  @Test
  void getPagedAccessoryListByTenantId_401() throws Exception {
    var result =
        mockMvc
            .perform(
                get(endpointUrl + "?tenantId=" + UUID.randomUUID())
                    .header(HttpHeaders.AUTHORIZATION, TEST_TOKEN_401)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON))
            .andDo(print())
            .andExpect(status().isUnauthorized())
            .andReturn();

    assertNotNull(result);
  }

  //@Test
  void getPagedAccessoryListByTenantId_403() throws Exception {
    var result =
        mockMvc
            .perform(
                get(endpointUrl + "?tenantId=" + UUID.randomUUID())
                    .header(HttpHeaders.AUTHORIZATION, test_token_403)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON))
            .andDo(print())
            .andExpect(status().isForbidden())
            .andReturn();

    assertNotNull(result);
  }

  @Test
  void delete_401() throws Exception {
    var result =
        mockMvc
            .perform(
                delete(endpointUrl + "/" + UUID.randomUUID())
                    .header(HttpHeaders.AUTHORIZATION, TEST_TOKEN_401)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON))
            .andDo(print())
            .andExpect(status().isUnauthorized())
            .andReturn();

    assertNotNull(result);
  }

  //@Test
  void delete_403() throws Exception {
    var result =
        mockMvc
            .perform(
                delete(endpointUrl + "/" + UUID.randomUUID())
                    .header(HttpHeaders.AUTHORIZATION, test_token_403)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON))
            .andDo(print())
            .andExpect(status().isForbidden())
            .andReturn();

    assertNotNull(result);
  }
}
