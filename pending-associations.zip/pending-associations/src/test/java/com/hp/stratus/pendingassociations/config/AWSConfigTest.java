package com.hp.stratus.pendingassociations.config;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import software.amazon.awssdk.auth.credentials.AwsSessionCredentials;
import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider;
import software.amazon.awssdk.services.kms.KmsClient;

import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
public class AWSConfigTest {

  private AWSConfig awsConfig;

  @BeforeEach
  void setup() {
    awsConfig = new AWSConfig("profile", "region");
  }

  @Test
  void profileCredentialsProvider_returnsProvider() {
    ProfileCredentialsProvider provider = awsConfig.profileCredentialsProvider();

    assertNotNull(provider);
  }

  @Test
  void awsCredentialsSupplier_returnsSupplier() {
    Supplier<AwsSessionCredentials> supplier =
        awsConfig.awsCredentialsSupplier(awsConfig.profileCredentialsProvider());

    assertNotNull(supplier);
  }

  @Test
  void kmsClient_returnsClient() {
    KmsClient client = awsConfig.kmsClient(awsConfig.profileCredentialsProvider());

    assertNotNull(client);
  }
}
