package com.hp.stratus.pendingassociations.dto;

import static com.hp.stratus.pendingassociations.dto.ResourceType.fromValue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@Tag("UnitTest")
class ResourceTypeTest {

  @Test
  void fromValueTest() {
    Assertions.assertEquals(ResourceType.PRINTER, fromValue("printer"));
    Assertions.assertEquals(ResourceType.PC, fromValue("pc"));
    Assertions.assertNull(fromValue("invalidResourceType"));
  }

}
