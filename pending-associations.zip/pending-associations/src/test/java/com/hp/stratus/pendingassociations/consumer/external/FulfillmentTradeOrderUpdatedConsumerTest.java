package com.hp.stratus.pendingassociations.consumer.external;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.config.JacksonConfig;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventEnvelope;
import com.hp.stratus.pendingassociations.service.CriteriaService;
import com.hp.stratus.pendingassociations.service.EventService;
import com.hp.stratus.pendingassociations.utils.EventUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;

import javax.json.JsonStructure;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
class FulfillmentTradeOrderUpdatedConsumerTest {

  @Mock CriteriaService criteriaService;
  @Mock EventService eventService;

  private final ObjectMapper mapper = new JacksonConfig().objectMapper();

  private FulfillmentTradeOrderUpdatedConsumer consumer;

  @BeforeEach
  void setup() {
    consumer = new FulfillmentTradeOrderUpdatedConsumer(mapper, criteriaService, eventService);
  }

  @Test
  void eventResource_returnsTradeOrderResource() {
    assertEquals(ExternalEventResource.FULFILLMENT_TRADE_ORDER, consumer.eventResource());
  }

  @Test
  void eventType_returnsAddedType() {
    assertEquals(ExternalEventType.UPDATED, consumer.eventType());
  }

  @Test
  void subscribeToResource_callsEventService() {
    consumer.subscribeToResource();

    verify(eventService, times(1))
        .subscribeToResource(ExternalEventResource.FULFILLMENT_TRADE_ORDER);
  }

  @Test
  void handleEvent_callsCriteriaService() throws IOException {
    File event = new File("src/test/resources/data/dto/FulfillmentTradeOrderEvent.json");
    StratusEventEnvelope envelope =
        mapper.readValue(Files.readAllBytes(event.toPath()), StratusEventEnvelope.class);
    Map<String, Object> mappedEvent = EventUtils.getEventAttributeMap(mapper, envelope);
    JsonStructure eventStructure = EventUtils.convertToJsonStructure(mapper, mappedEvent);

    consumer.handleEvent(envelope);

    verify(criteriaService, times(1))
        .resolveConditionCriteriaHack(
            ExternalEventResource.FULFILLMENT_TRADE_ORDER,
            ExternalEventType.UPDATED,
            mappedEvent,
            eventStructure);
  }

  @Test
  void handleEvent_throwsAmqpExceptionIfNoValueMapIsPresent() {
    StratusEventEnvelope envelope = new StratusEventEnvelope();
    envelope.setEventAttributeValueMap(Map.of());

    assertThrows(AmqpRejectAndDontRequeueException.class, () -> consumer.handleEvent(envelope));
  }

  @Test
  void handleEvent_throwsAmqpExceptionIfJsonStructureParsingFails() throws IOException {
    File event = new File("src/test/resources/data/dto/FulfillmentTradeOrderEvent.json");
    StratusEventEnvelope envelope =
        mapper.readValue(Files.readAllBytes(event.toPath()), StratusEventEnvelope.class);
    try (MockedStatic<EventUtils> mocked = mockStatic(EventUtils.class)) {
      mocked.when(() -> EventUtils.convertToJsonStructure(any(), any())).thenReturn(null);

      assertThrows(AmqpRejectAndDontRequeueException.class, () -> consumer.handleEvent(envelope));
    }
  }
}
