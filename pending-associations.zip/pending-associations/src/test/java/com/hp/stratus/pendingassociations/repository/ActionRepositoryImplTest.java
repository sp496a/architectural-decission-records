package com.hp.stratus.pendingassociations.repository;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.hp.stratus.pendingassociations.repository.impl.ActionRepositoryImpl;
import com.mongodb.client.result.UpdateResult;
import java.util.UUID;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.UpdateDefinition;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")

class ActionRepositoryImplTest {

  @Mock
  MongoTemplate mongoTemplate;

  @InjectMocks
  ActionRepositoryImpl actionRepository;

  @Test
  void resolveActionTest_True() {
    UUID id = UUID.randomUUID();
    UpdateResult result = mock(UpdateResult.class);
    doReturn(1L).when(result).getModifiedCount();
    when(mongoTemplate.updateMulti(any(), any(UpdateDefinition.class), (Class<?>) any()))
        .thenReturn(result);
    boolean updated = actionRepository.resolveAction(id, 1, null);
    Assertions.assertTrue(updated);
    verify(mongoTemplate, times(1))
        .updateMulti(any(), any(UpdateDefinition.class), (Class<?>) any());
  }

  @Test
  void resolveActionTest_False() {
    UUID id = UUID.randomUUID();
    UpdateResult result = mock(UpdateResult.class);
    doReturn(0L).when(result).getModifiedCount();
    when(mongoTemplate.updateMulti(any(), any(UpdateDefinition.class), (Class<?>) any()))
        .thenReturn(result);
    boolean updated = actionRepository.resolveAction(id, 1, null);
    Assertions.assertFalse(updated);
    verify(mongoTemplate, times(1))
        .updateMulti(any(), any(UpdateDefinition.class), (Class<?>) any());
  }

}
