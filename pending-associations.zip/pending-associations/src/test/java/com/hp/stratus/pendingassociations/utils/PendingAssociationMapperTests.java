package com.hp.stratus.pendingassociations.utils;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.dto.AssociationUpdateActionsDto;
import com.hp.stratus.pendingassociations.dto.CreateAssociationRequest;
import com.hp.stratus.pendingassociations.dto.CreateAssociationResponse;
import com.hp.stratus.pendingassociations.dto.CriteriaUpdateDto;
import com.hp.stratus.pendingassociations.dto.PutAssociationResponse;
import com.hp.stratus.pendingassociations.model.Action;
import com.hp.stratus.pendingassociations.model.Association;

import com.hp.stratus.pendingassociations.model.Criteria;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.io.File;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@Tag("UnitTest")
public class PendingAssociationMapperTests {

  private static final ObjectMapper objectMapper = new ObjectMapper();
  
  @BeforeEach
  void setup() {
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  }
  
  @Test
  void testConvertCreateReqToModel() throws Exception {
    // Setup the test
    CreateAssociationRequest createAssociationRequest =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdate.json"),
            CreateAssociationRequest.class);

    // Run the test
    Association association = AssociationMapper.toModel(createAssociationRequest);

    // Verify the test
    assertNotNull(association);
  }

  @Test
  void testConvertAssocationToCreateRes() throws Exception {
    // Setup the test
    Association association =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/Association.json"), Association.class);

    // Run the test
    CreateAssociationResponse createAssociationResponse =
        AssociationMapper.toCreateAssociationResponse(association);

    // Verify the test
    assertNotNull(createAssociationResponse);
  }

  @Test
  void testConvertNullToDataEntity() {

    // Run the test
    Association association = AssociationMapper.toModel(null);

    // Verify the test
    assertNull(association);
  }

  @Test
  void testConvertAssociationToPutResponse() throws Exception {
    // Setup the test
    Association association =
        objectMapper.readValue(
            new File("src/test/resources/data/mongo/Association.json"), Association.class);

    // Run the test
    PutAssociationResponse putAssociationResponse =
        AssociationMapper.toPutAssociationResponse(association);

    // Verify the test
    assertNotNull(putAssociationResponse);
  }

  @Test
  void testConvertNullEntityToPutResponse() {

    // Run the test
    PutAssociationResponse putAssociationResponse =
        AssociationMapper.toPutAssociationResponse(null);

    // Verify the test
    assertNull(putAssociationResponse);
  }

  @Test
  void testConvertCreateReqToModel1() throws Exception {
    // Setup the test
    CreateAssociationRequest createAssociationRequest =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdate.json"),
            CreateAssociationRequest.class);
    createAssociationRequest.setActions(null);
    createAssociationRequest.setCriteria(null);
    // Run the test
    Association association = AssociationMapper.toModel(createAssociationRequest);

    // Verify the test
    assertNotNull(association);
  }

  @Test
  void TesttoCriteriaModels() throws Exception {
    // Setup the test
    List<CriteriaUpdateDto> criteriaUpdateDtoList = new ArrayList<>();
    // Run the test
    List<Criteria> criteriaList = AssociationMapper.toCriteriaModels(criteriaUpdateDtoList);

    // Verify the test
    assertTrue(criteriaList.isEmpty());
  }

  @Test
  void TesttoActionModels() throws Exception {
    // Setup the test
    List<AssociationUpdateActionsDto> actionsDtos = new ArrayList<>();
    // Run the test
    List<Action> actionList = AssociationMapper.toActionModels(actionsDtos);

    // Verify the test
    assertTrue(actionList.isEmpty());
  }
}
