package com.hp.stratus.auth;

import com.hp.stratus.auth.exception.AuthErrorMessage;
import com.hp.stratus.auth.exception.AuthErrorResponse;
import com.hp.stratus.auth.exception.ErrorCodeAndMessage;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

@Tag("UnitTest")
@Tag("ComponentTest")
public class AuthErrorTest {

  @Test
  void errorCodeAndMessageTest() {
    // Run the test
    ErrorCodeAndMessage errorCodeAndMessage = ErrorCodeAndMessage.NOT_ALLOWED_ACCESS;

    // Verify the test
    Assertions.assertEquals(
        "E",
        errorCodeAndMessage.getMessageType(),
        "ErrorCodeAndMessage.NotAllowedAccess messageType incorrect");
    Assertions.assertEquals(
        403,
        errorCodeAndMessage.getHttpStatusCode(),
        "ErrorCodeAndMessage.NotAllowedAccess messageType incorrect");
    Assertions.assertEquals(
        "U",
        errorCodeAndMessage.getSeverity(),
        "ErrorCodeAndMessage.NotAllowedAccess severity incorrect");
    Assertions.assertEquals(
        "0002",
        errorCodeAndMessage.getMessageNumber(),
        "ErrorCodeAndMessage.NotAllowedAccess messageNumber incorrect");
    Assertions.assertNotNull(
        errorCodeAndMessage.getMessage(), "ErrorCodeAndMessage.NotAllowedAccess message incorrect");
    Assertions.assertNotNull(
        errorCodeAndMessage.toString(),
        "ErrorCodeAndMessage.NotAllowedAccess toString() incorrect");
  }

  @Test
  void authErrorResponseTest() {
    // Run the test
    AuthErrorResponse authErrorResponse =
        new AuthErrorResponse(
            AuthErrorResponse.VERSION,
            ErrorCodeAndMessage.UNAUTHORIZED.getHttpStatusCode(),
            new ArrayList<>());

    AuthErrorResponse authErrorResponseNoArg = new AuthErrorResponse();

    AuthErrorResponse authErrorResponseBuild =
        AuthErrorResponse.builder()
            .httpStatusCode(ErrorCodeAndMessage.UNAUTHORIZED.getHttpStatusCode())
            .stratusVersion(AuthErrorResponse.VERSION)
            .errors(new ArrayList<>())
            .build();

    // Verify the test
    Assertions.assertEquals(
        "1.0.0",
        authErrorResponse.getStratusVersion(),
        "authErrorResponse stratusVersion incorrect");
    Assertions.assertEquals(
        401, authErrorResponse.getHttpStatusCode(), "authErrorResponse httpStatusCode incorrect");
    Assertions.assertNotNull(
        authErrorResponse.toString(), "authErrorResponse toString() incorrect");
    Assertions.assertEquals(authErrorResponse, authErrorResponseBuild);
    Assertions.assertNotNull(authErrorResponseNoArg);
  }

  @Test
  void authErrorMessageTest() {
    // Run the test
    AuthErrorMessage authErrorMessage =
        new AuthErrorMessage(ErrorCodeAndMessage.UNAUTHORIZED.getMessageCode(), "error");
    AuthErrorMessage authErrorMessageNoArg = new AuthErrorMessage();
    AuthErrorMessage authErrorMessageBuild =
        AuthErrorMessage.builder()
            .code(ErrorCodeAndMessage.UNAUTHORIZED.getMessageCode())
            .message("error")
            .build();

    // Verify the test
    Assertions.assertNotNull(authErrorMessage.toString(), "authErrorMessage toString() incorrect");
    Assertions.assertEquals(authErrorMessage, authErrorMessageBuild);
    Assertions.assertNotNull(authErrorMessageNoArg);
  }
}
