package com.hp.stratus.pendingassociations.config;

import com.hp.stratus.pendingassociations.model.cache.PrinterAssociationActionInformation;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
public class RedisConfigTest {

  private RedisConfig redisConfig;

  @Test
  void connectionFactory_returnsAStandaloneFactory() {
    redisConfig = new RedisConfig("localhost", 6379, false);

    LettuceConnectionFactory connectionFactory = redisConfig.connectionFactory();

    assertNotNull(connectionFactory.getStandaloneConfiguration());
    assertEquals("localhost", connectionFactory.getStandaloneConfiguration().getHostName());
    assertEquals(6379, connectionFactory.getStandaloneConfiguration().getPort());
  }

  @Test
  void connectionFactory_returnsAClusterFactory() {
    redisConfig = new RedisConfig("localhost", 6379, true);

    LettuceConnectionFactory connectionFactory = redisConfig.connectionFactory();

    assertNotNull(connectionFactory.getClusterConfiguration());
    assertEquals("localhost", connectionFactory.getStandaloneConfiguration().getHostName());
    assertEquals(6379, connectionFactory.getStandaloneConfiguration().getPort());
  }

  @Test
  void booleanTemplate_returnsATemplate() {
    redisConfig = new RedisConfig("localhost", 6379, false);

    RedisTemplate<String, Boolean> template =
        redisConfig.booleanTemplate(redisConfig.connectionFactory());

    assertNotNull(template);
  }

  @Test
  void printerAssociationTemplate_returnsATemplate() {
    redisConfig = new RedisConfig("localhost", 6379, false);

    RedisTemplate<String, PrinterAssociationActionInformation> template =
        redisConfig.printerAssociationTemplate(redisConfig.connectionFactory());

    assertNotNull(template);
  }
}
