package com.hp.stratus.auth;

import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.web.bind.annotation.RequestMethod.GET;

/** A dummy controller to demo how the auth annotation works */
@Slf4j
@RestController
public class AuthDemoController {
  public AuthDemoController() {}

  /** Defines a GET API with a scope of list type in PreAuthorize annotation for demo */
  @PreAuthorize("hasPermission('scope', T(com.hp.stratus.auth.AuthDemoConstants.ScopeDemo).ALL)")
  @RequestMapping(method = GET, value = "/auth/authdemo_list_scope")
  public String testAuthListScope() {
    log.info("testAuthListScope api invoked");
    return "aauthdemo_list_scope";
  }

  /** Defines a GET API with a scope of enum type in PreAuthorize annotation for demo */
  @PreAuthorize(
      "hasPermission('scope', T(com.hp.stratus.auth.AuthDemoConstants.ScopeDemo).CREATE )")
  @RequestMapping(method = GET, value = "/auth/authdemo_enum_scope")
  public String testAuthEnum() {
    log.info("authdemo_enum_scope api invoked");
    return "authdemo_enum_scope";
  }

  /** Defines a GET API with a scope of String type in PreAuthorize annotation for demo */
  @PreAuthorize("hasPermission('scope', 'jees.hp.com/jobs')")
  @RequestMapping(method = GET, value = "/auth/authdemo_string_scope")
  public String testAuthStringScope() {
    log.info("authdemo_string_scope api invoked");
    return "authdemo_string_scope";
  }
}
