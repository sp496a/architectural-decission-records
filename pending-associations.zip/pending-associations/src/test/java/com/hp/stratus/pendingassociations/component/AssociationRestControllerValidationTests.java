package com.hp.stratus.pendingassociations.component;

import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.auth.conf.SecurityConfig;
import com.hp.stratus.pendingassociations.controller.AssociationRestController;
import com.hp.stratus.pendingassociations.dto.CreateAssociationRequest;
import com.hp.stratus.pendingassociations.exceptions.ResourceNotFoundException;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.service.AssociationService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.io.File;
import java.util.UUID;

import static org.mockito.Mockito.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@Tag("ComponentTest")
@WebMvcTest(controllers = AssociationRestController.class)
@Import(value = {PermitAllPathTestProvider.class})
@ImportAutoConfiguration(classes = SecurityConfig.class)
class AssociationRestControllerValidationTests {
  @JsonValue private static final ObjectMapper objectMapper = new ObjectMapper();
  @MockBean AssociationService associationService;
  @Autowired private MockMvc mockMvc;

  @Test
  void createInvalidRequestTest() throws Exception {

    // Setup the test
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    CreateAssociationRequest createAssociationRequest =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdateInvalid.json"),
            CreateAssociationRequest.class);

    // Run the test
    MvcResult mvcResult =
        mockMvc
            .perform(
                post("/pending-associations/v1/associations")
                    .with(csrf())
                    .content(objectMapper.writeValueAsString(createAssociationRequest))
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isBadRequest())
            .andReturn();

    // Verify the result
    String responsebody = mvcResult.getResponse().getContentAsString();
    Assertions.assertTrue(responsebody.contains("400"));
    Assertions.assertTrue(responsebody.contains("tenantId"));
    verifyNoMoreInteractions(associationService);
  }

  @Test
  void createInvalidRequestTest2() throws Exception {

    // Setup the test
    CreateAssociationRequest createAssociationRequest =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdateInvalid2.json"),
            CreateAssociationRequest.class);

    // Run the test
    MvcResult mvcResult =
        mockMvc
            .perform(
                post("/pending-associations/v1/associations")
                    .with(csrf())
                    .content(objectMapper.writeValueAsString(createAssociationRequest))
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isBadRequest())
            .andReturn();

    // Verify the result
    String responsebody = mvcResult.getResponse().getContentAsString();
    Assertions.assertTrue(responsebody.contains("400"));
    Assertions.assertTrue(responsebody.contains("tenantId"));
    verifyNoMoreInteractions(associationService);
  }

  @Test
  void getAssociationByIdNotFoundTest() throws Exception {
    // Setup the test
    Association newAssociation = new Association();
    UUID id = UUID.randomUUID();
    newAssociation.setId(id);
    when(associationService.get(id)).thenThrow(new ResourceNotFoundException());

    // Run the test
    mockMvc
        .perform(get("/pending-associations/v1/associations/{associationId}", id))
        .andDo(print())
        .andExpect(status().isNotFound())
        .andReturn();

    // Verify the test
    verify(associationService, times(1)).get(id);
    verifyNoMoreInteractions(associationService);
  }

  @Test
  void getAssociationByInvalidIdTest() throws Exception {

    // Run the test
    mockMvc
        .perform(get("/pending-associations/v1/associations/{associationId}", "someid"))
        .andDo(print())
        .andExpect(status().isBadRequest())
        .andReturn();

    // Verify the test
    verifyNoMoreInteractions(associationService);
  }

  @Test
  void deleteAssociationByInvalidIdTest() throws Exception {

    // Run the test
    mockMvc
        .perform(
            delete("/pending-associations/v1/associations/{associationId}", "someid").with(csrf()))
        .andDo(print())
        .andExpect(status().isBadRequest())
        .andReturn();

    // Verify the test
    verifyNoMoreInteractions(associationService);
  }

  @Test
  void getPagedAssociationListInvalidParamTest() throws Exception {

    // Run the test

    // Run and verify the test
    mockMvc
        .perform(get("/pending-associations/v1/associations?offset=-1&limit=-2"))
        .andDo(print())
        .andExpect(status().isBadRequest())
        .andReturn();

    // Verify the test
    verifyNoMoreInteractions(associationService);
  }

  @Test
  void getPagedAssociationListInvalidSortByTest() throws Exception {

    // Run the test

    // Run and verify the test
    mockMvc
        .perform(get("/pending-associations/v1/associations?offset=-1&limit=-2&sortBy=id:Asca"))
        .andDo(print())
        .andExpect(status().isBadRequest())
        .andReturn();

    // Verify the test
    verifyNoMoreInteractions(associationService);
  }

  @Test
  void headInvalidParamTest() throws Exception {

    // Run the test
    mockMvc
        .perform(head("/pending-associations/v1/associations?offset=-1&limit=-2"))
        .andDo(print())
        .andExpect(status().isBadRequest())
        .andReturn();

    // Verify the test
    verifyNoMoreInteractions(associationService);
  }
}
