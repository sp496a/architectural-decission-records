package com.hp.stratus.pendingassociations.repository;

import static com.hp.stratus.pendingassociations.data.Constants.ID;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.dto.OffsetSearchPageRequest;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.repository.impl.AssociationRepositoryImpl;
import java.io.File;
import java.io.IOException;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
class AssociationRepositoryImplTest {

  @JsonValue
  private static final ObjectMapper objectMapper = new ObjectMapper();
  @Mock
  MongoTemplate mongoTemplate;
  @InjectMocks
  AssociationRepositoryImpl associationRepository;
  Association association;
  private List<Association> associationList;

  @BeforeEach
  void setUp() throws IOException {
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    association =
        objectMapper.readValue(
            new File("src/test/resources/data/mongo/Association.json"), new TypeReference<>() {
            });
    associationList =
        objectMapper.readValue(
            new File("src/test/resources/data/mongo/Associations.json"), new TypeReference<>() {
            });
  }

  @Test
  void insertTest() {
    when(mongoTemplate.insert(association)).thenReturn(association);
    Assertions.assertEquals(association, associationRepository.insert(association));
  }

  @Test
  void findByIdTest() {
    Criteria criteria = Criteria.where(ID).is(association.getId());
    Query query = Query.query(criteria);
    when(mongoTemplate.findOne(query, Association.class)).thenReturn(association);
    Assertions.assertEquals(association, associationRepository.findById(association.getId()));
  }

  @Test
  void saveTest() {
    when(mongoTemplate.save(association)).thenReturn(association);
    Assertions.assertEquals(association, associationRepository.save(association));
  }

  @Test
  void countTest() {
    when(mongoTemplate.count(new Query(), Association.class)).thenReturn(1L);
    Assertions.assertEquals(1, associationRepository.count());
  }

  @Test
  void getGenericSearchPagedAssociationListTest() {
    Pageable pageable = new OffsetSearchPageRequest(0, 20, null, "tenantId");
    Query query = new Query().with(pageable);
    String criteria = "tenantId";
    String value = "90dc86e8-952c-11ec-b909-0242ac120002";
    if (criteria != null && value != null) {
      query.addCriteria(Criteria.where(criteria).is(value));
    }
    when(mongoTemplate.find(query, Association.class)).thenReturn(associationList);
    Assertions.assertNotNull(
        associationRepository.getGenericSearchPagedAssociationList(pageable, "tenantId",
            "90dc86e8-952c-11ec-b909-0242ac120002"));
  }

  @Test
  void getPagedAssociationListTest() {
    Pageable pageable = new OffsetSearchPageRequest(0, 20, null, "tenantId");
    Query query = new Query().with(pageable);
    when(mongoTemplate.find(query, Association.class)).thenReturn(associationList);
    Assertions.assertNotNull(
        associationRepository.getPagedAssociationList(pageable));
  }

}
