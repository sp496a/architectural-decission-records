package com.hp.stratus.pendingassociations.dto.event.internal;

import static com.hp.stratus.pendingassociations.dto.event.internal.InternalEventType.fromValue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@Tag("UnitTest")
class InternalEventTypeTest {

  @Test
  void fromValueTest() {
    Assertions.assertEquals(InternalEventType.CRITERIA_RESOLVED, fromValue("CRITERIA_RESOLVED"));
    Assertions.assertEquals(InternalEventType.EXECUTE_NEXT_ACTION,
        fromValue("EXECUTE_NEXT_ACTION"));
    Assertions
        .assertEquals(InternalEventType.PUBLISH_FIRE_ASSOCIATION_UPDATE,
            fromValue("PUBLISH_FIRE_ASSOCIATION_UPDATE"));
    Assertions.assertNull(fromValue("invalidInternalEventType"));
  }

}
