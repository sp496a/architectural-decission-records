package com.hp.stratus.pendingassociations.service;

import com.hp.stratus.pendingassociations.service.impl.SpecServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
public class SpecServiceImplTest {

  private SpecService specService;

  @BeforeEach
  void setUp() {
    specService = new SpecServiceImpl();
  }

  @Test
  void getSpecTest() throws Exception {
    String spec = specService.getSpec();
    Assertions.assertNotNull(spec);
  }
}
