package com.hp.stratus.pendingassociations.consumer.internal;

import com.hp.stratus.pendingassociations.dto.event.internal.InternalEvent;
import com.hp.stratus.pendingassociations.dto.event.internal.InternalEventType;
import com.hp.stratus.pendingassociations.service.ActionService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
public class ExecuteNextActionConsumerTest {

  @Mock ActionService actionService;

  private ExecuteNextActionConsumer consumer;

  @BeforeEach
  void setup() {
    consumer = new ExecuteNextActionConsumer(actionService);
  }

  @Test
  void eventType_returnsExecuteNextActionType() {
    Assertions.assertEquals(consumer.eventType(), InternalEventType.EXECUTE_NEXT_ACTION);
  }

  @Test
  void handleEvent_callsTheActionService() {
    InternalEvent event =
        new InternalEvent(InternalEventType.EXECUTE_NEXT_ACTION, UUID.randomUUID());

    consumer.handleEvent(event);

    verify(actionService, times(1)).executeNextAction(eq(event.getAssociation()));
  }
}
