package com.hp.stratus.pendingassociations.consumer.external;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.action.associate.AssociatePrinterExecutor;
import com.hp.stratus.pendingassociations.config.JacksonConfig;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventAttribute;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventEnvelope;
import com.hp.stratus.pendingassociations.service.EventService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
public class PrinterClaimAddedConsumerTest {

  @Mock AssociatePrinterExecutor actionExecutor;
  @Mock EventService eventService;

  private final ObjectMapper mapper = new JacksonConfig().objectMapper();

  private PrinterClaimAddedConsumer consumer;

  @BeforeEach
  void setup() {
    consumer = new PrinterClaimAddedConsumer(actionExecutor, eventService, mapper);
  }

  @Test
  void eventResource_returnsPrinterClaimResource() {
    Assertions.assertEquals(consumer.eventResource(), ExternalEventResource.PRINTER_CLAIM);
  }

  @Test
  void eventType_returnsAddedType() {
    Assertions.assertEquals(consumer.eventType(), ExternalEventType.ADDED);
  }

  @Test
  void subscribeToResource_callsEventService() {
    consumer.subscribeToResource();

    verify(eventService, times(1)).subscribeToResource(eq(ExternalEventResource.PRINTER_CLAIM));
  }

  @Test
  void handleEvent_deadLettersWhenNoEventObjectIsSupplied() {
    assertThrows(
        AmqpRejectAndDontRequeueException.class,
        () ->
            consumer.handleEvent(
                StratusEventEnvelope.builder().eventAttributeValueMap(new HashMap<>()).build()));
  }

  @Test
  void handleEvent_deadLettersWhenEventDetailsCantBeParsed() {
    Map<String, StratusEventAttribute> attributeMap = new HashMap<>();
    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setStringValue("invalid JSON");
    attributeMap.put("eventObject", attribute);

    assertThrows(
        AmqpRejectAndDontRequeueException.class,
        () ->
            consumer.handleEvent(
                StratusEventEnvelope.builder().eventAttributeValueMap(attributeMap).build()));
  }

  @Test
  void handleEvent_deadLettersWhenDeviceIdIsMissing() {
    Map<String, StratusEventAttribute> attributeMap = new HashMap<>();
    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setStringValue("{}");
    attributeMap.put("eventObject", attribute);

    assertThrows(
        AmqpRejectAndDontRequeueException.class,
        () ->
            consumer.handleEvent(
                StratusEventEnvelope.builder().eventAttributeValueMap(attributeMap).build()));
  }

  @Test
  void handleEvent_deadLettersWhenDeviceIdIsNull() {
    Map<String, StratusEventAttribute> attributeMap = new HashMap<>();
    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setStringValue("{}");
    attributeMap.put("eventObject", attribute);
    attributeMap.put("deviceId", new StratusEventAttribute());

    assertThrows(
        AmqpRejectAndDontRequeueException.class,
        () ->
            consumer.handleEvent(
                StratusEventEnvelope.builder().eventAttributeValueMap(attributeMap).build()));
  }

  @Test
  void handleEvent_callsTheAssociatePrinterExecutor() {
    Map<String, StratusEventAttribute> attributeMap = new HashMap<>();
    StratusEventAttribute detailsAttribute = new StratusEventAttribute();
    detailsAttribute.setStringValue("{}");
    attributeMap.put("eventObject", detailsAttribute);
    StratusEventAttribute deviceIdAttribute = new StratusEventAttribute();
    deviceIdAttribute.setStringValue("deviceId");
    attributeMap.put("deviceId", deviceIdAttribute);

      consumer.handleEvent(
          StratusEventEnvelope.builder().eventAttributeValueMap(attributeMap).build());

    verify(actionExecutor, times(1)).completeClaim(eq("deviceId"), anyMap());
  }
}
