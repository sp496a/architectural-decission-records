package com.hp.stratus.pendingassociations.utils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@Tag("UnitTest")
public class SearchUtilsTest {

  @Test
  void splitSearchStringTest() {
    Assertions.assertNotNull(SearchUtils.splitSearchString(null));
    String[] splittedString = SearchUtils.splitSearchString("first:second");
    Assertions.assertEquals("first", splittedString[0]);
    Assertions.assertEquals("second", splittedString[1]);
  }
}
