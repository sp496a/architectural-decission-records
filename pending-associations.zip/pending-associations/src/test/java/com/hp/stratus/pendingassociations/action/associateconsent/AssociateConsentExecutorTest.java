package com.hp.stratus.pendingassociations.action.associateconsent;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.exceptions.ResourceResolutionException;
import com.hp.stratus.pendingassociations.model.*;
import com.hp.stratus.pendingassociations.utils.PathResolver;
import com.hp.stratus.pendingassociations.utils.ResourceUtils;
import org.apache.commons.lang3.NotImplementedException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
class AssociateConsentExecutorTest {

  @Mock AssociateConsentResourceExecutor consentResourceExecutor;
  private AssociateConsentExecutor executor;
  private ObjectMapper objectMapper;
  private PathResolver pathResolver;

  @BeforeEach
  void setup() {
    objectMapper = new ObjectMapper();
    pathResolver = new PathResolver(objectMapper);
    executor =
        new AssociateConsentExecutor(objectMapper, pathResolver, List.of(consentResourceExecutor));
  }

  @Test
  void testGetOperation() {

    // run test
    Operation operationResult = executor.getOperation();

    // verify result
    assertEquals(Operation.ASSOCIATE_CONSENT, operationResult);
  }

  @Test
  void execute_actionResouceIsNull() {

    // Setup testdata
    List<AssociateConsentResourceExecutor> consentExecutors = new ArrayList<>();
    executor = new AssociateConsentExecutor(objectMapper, pathResolver, consentExecutors);
    Action action = new Action();

    // Run test and verify result
    assertThrows(
        ResourceResolutionException.class, () -> executor.execute(new Association(), action, 0));
  }

  @Test
  void execute_resourceTypeExecuteCalled() {
    Association association = new Association();
    Action action = new Action();
    Resource device = new Resource();
    device.setType(ResourceType.PC);
    device.setId(new ResourceId());
    device.getId().setValue("device");
    Resource user = new Resource();
    user.setType(ResourceType.USER);
    user.setId(new ResourceId());
    user.getId().setValue("user");
    Resources resources = new Resources();
    resources.setDevice(device);
    resources.setUser(user);
    action.setResources(resources);
    when(consentResourceExecutor.getDeviceResourceType()).thenReturn(ResourceType.PC);

    try (MockedStatic<ResourceUtils> mocked = mockStatic(ResourceUtils.class)) {
      mocked
          .when(() -> ResourceUtils.resolveResource(any(), any(), any(), any()))
          .thenReturn("resolvedValue");

      // run test
      executor.execute(association, action, 1);

      // verify test
      mocked.verify(
          () ->
              ResourceUtils.resolveResource(
                  any(), any(), eq(association), eq(action.getResources().getUser().getId())),
          times(1));
      mocked.verify(
          () ->
              ResourceUtils.resolveResource(
                  any(), any(), eq(association), eq(action.getResources().getDevice().getId())),
          times(1));
      verify(consentResourceExecutor, times(1))
          .execute(eq("resolvedValue"), eq("resolvedValue"), eq(association), eq(1));
    }
  }

  @Test
  void execute_actionResourceNotImplemented() {
    Association association = new Association();
    Action action = new Action();
    Resource device = new Resource();
    device.setType(ResourceType.PRINTER);
    Resource user = new Resource();
    user.setType(ResourceType.USER);
    Resources resources = new Resources();
    resources.setDevice(device);
    resources.setUser(user);
    action.setResources(resources);
    when(consentResourceExecutor.getDeviceResourceType()).thenReturn(ResourceType.PC);

    assertThrows(NotImplementedException.class, () -> executor.execute(association, action, 1));
  }

  @Test
  void execute_actionResouceUserIsNull() {

    // Setup testdata
    List<AssociateConsentResourceExecutor> consentExecutors = new ArrayList<>();
    executor = new AssociateConsentExecutor(objectMapper, pathResolver, consentExecutors);
    Action action = new Action();
    Resources resources = new Resources();
    resources.setUser(null);
    action.setResources(resources);

    // Run test and verify result
    assertThrows(
        ResourceResolutionException.class, () -> executor.execute(new Association(), action, 0));
  }

  @Test
  void execute_actionResouceDeviceIsNull() {

    // Setup testdata
    List<AssociateConsentResourceExecutor> consentExecutors = new ArrayList<>();
    executor = new AssociateConsentExecutor(objectMapper, pathResolver, consentExecutors);
    Action action = new Action();
    Resources resources = new Resources();
    ResourceId resourceId = new ResourceId();
    resourceId.setType(ResourceIdType.POINTER);
    resourceId.setValue("value");
    Resource resource = new Resource();
    resource.setType(ResourceType.USER);
    resource.setId(resourceId);
    resources.setUser(resource);
    resources.setDevice(null);

    // Run test and verify result
    assertThrows(
        ResourceResolutionException.class, () -> executor.execute(new Association(), action, 0));
  }
}
