package com.hp.stratus.pendingassociations.action.associate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.http.client.utils.HttpClient;
import com.hp.stratus.pendingassociations.dto.client.PrinterClaimRequest;
import com.hp.stratus.pendingassociations.exceptions.ActionExecutionException;
import com.hp.stratus.pendingassociations.model.*;
import com.hp.stratus.pendingassociations.model.cache.PrinterAssociationActionInformation;
import com.hp.stratus.pendingassociations.repository.ActionRepository;
import com.hp.stratus.pendingassociations.service.EventService;
import com.hp.stratus.pendingassociations.utils.PathResolver;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;

import java.util.UUID;
import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
class AssociationPrinterExecutorTest {

  private final ObjectMapper objectMapper = new ObjectMapper();
  private final PathResolver pathResolver = new PathResolver(objectMapper);

  @Mock ActionRepository actionRepository;
  @Mock EventService eventService;
  @Mock RedisTemplate<String, PrinterAssociationActionInformation> redisTemplate;
  @Mock ValueOperations<String, PrinterAssociationActionInformation> valueOperations;
  @Mock HttpClient httpClient;
  @Mock Supplier<String> jwtSupplier;

  private AssociatePrinterExecutor executor;

  @BeforeEach
  void setup() {
    executor =
        new AssociatePrinterExecutor(
            objectMapper,
            pathResolver,
            actionRepository,
            eventService,
            redisTemplate,
            httpClient,
            jwtSupplier,
            "base",
            "/endpoint");
  }

  @Test
  void execute_setsRedisInformationAndCallsDeviceApi() {
    when(redisTemplate.opsForValue()).thenReturn(valueOperations);
    when(jwtSupplier.get()).thenReturn("token");
    when(httpClient.post(any(), any(), any(), any()))
        .thenReturn(new ResponseEntity<>(HttpStatus.OK));

    executor.execute(
        Resource.builder()
            .id(ResourceId.builder().type(ResourceIdType.STRING).value("device").build())
            .build(),
        new Association(),
        0);

    verify(valueOperations, times(1))
        .set("device", new PrinterAssociationActionInformation(null, 0));
    verify(httpClient, times(1))
        .post(eq("base/endpoint"), eq("token"), isA(PrinterClaimRequest.class), any());
  }

  @Test
  void execute_maintainsRedisKeyOnSuccess() {
    when(redisTemplate.opsForValue()).thenReturn(valueOperations);
    when(jwtSupplier.get()).thenReturn("token");
    when(httpClient.post(any(), any(), any(), any()))
        .thenReturn(new ResponseEntity<>(HttpStatus.OK));

    executor.execute(
        Resource.builder()
            .id(ResourceId.builder().type(ResourceIdType.STRING).value("device").build())
            .build(),
        new Association(),
        0);

    verify(redisTemplate, times(0)).delete("device");
  }

  @Test
  void execute_resolvesActionOn409() {
    when(redisTemplate.opsForValue()).thenReturn(valueOperations);
    when(jwtSupplier.get()).thenReturn("token");
    when(httpClient.post(any(), any(), any(), any()))
        .thenThrow(new HttpClientErrorException(HttpStatus.CONFLICT));

    executor.execute(
        Resource.builder()
            .id(ResourceId.builder().type(ResourceIdType.STRING).value("device").build())
            .build(),
        new Association(),
        0);

    verify(redisTemplate, times(1)).delete("device");
    verify(actionRepository, times(1)).resolveAction(any(), anyInt(), any());
  }

  @Test
  void execute_throwsAnUnretryableExceptionOnClientErrors() {
    when(redisTemplate.opsForValue()).thenReturn(valueOperations);
    when(jwtSupplier.get()).thenReturn("token");
    when(httpClient.post(any(), any(), any(), any()))
        .thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST));
    Association association = new Association();
    Resource resource =
        Resource.builder()
            .id(ResourceId.builder().type(ResourceIdType.STRING).value("device").build())
            .build();

    ActionExecutionException exception =
        assertThrows(
            ActionExecutionException.class, () -> executor.execute(resource, association, 0));

    verify(redisTemplate, times(1)).delete("device");
    verify(actionRepository, times(0)).resolveAction(any(), anyInt(), any());
    assertFalse(exception.isRetryable());
  }

  @Test
  void execute_throwsARetryableExceptionOnServerErrors() {
    when(redisTemplate.opsForValue()).thenReturn(valueOperations);
    when(jwtSupplier.get()).thenReturn("token");
    when(httpClient.post(any(), any(), any(), any()))
        .thenThrow(new HttpServerErrorException(HttpStatus.BAD_GATEWAY));
    Association association = new Association();
    Resource resource =
        Resource.builder()
            .id(ResourceId.builder().type(ResourceIdType.STRING).value("device").build())
            .build();

    ActionExecutionException exception =
        assertThrows(
            ActionExecutionException.class, () -> executor.execute(resource, association, 0));

    verify(redisTemplate, times(1)).delete("device");
    verify(actionRepository, times(0)).resolveAction(any(), anyInt(), any());
    assertTrue(exception.isRetryable());
  }

  @Test
  void execute_throwsARetryableExceptionOnNetworkErrors() {
    when(redisTemplate.opsForValue()).thenReturn(valueOperations);
    when(jwtSupplier.get()).thenReturn("token");
    when(httpClient.post(any(), any(), any(), any())).thenThrow(new RuntimeException());
    Association association = new Association();
    Resource resource =
        Resource.builder()
            .id(ResourceId.builder().type(ResourceIdType.STRING).value("device").build())
            .build();

    ActionExecutionException exception =
        assertThrows(
            ActionExecutionException.class, () -> executor.execute(resource, association, 0));

    verify(redisTemplate, times(1)).delete("device");
    verify(actionRepository, times(0)).resolveAction(any(), anyInt(), any());
    assertTrue(exception.isRetryable());
  }

  @Test
  void completeClaim_doesNothingIfKeyIsNotFoundInRedis() {
    when(redisTemplate.opsForValue()).thenReturn(valueOperations);
    when(valueOperations.getAndDelete(any())).thenReturn(null);

    executor.completeClaim("device", null);

    verify(actionRepository, times(0)).resolveAction(any(), anyInt(), any());
    verify(eventService, times(0)).publishExecuteNextAction(any());
  }

  @Test
  void completeClaim_doesNotFireAnEventWhenNoActionsAreResolved() {
    when(redisTemplate.opsForValue()).thenReturn(valueOperations);
    PrinterAssociationActionInformation info =
        new PrinterAssociationActionInformation(UUID.randomUUID(), 0);
    when(valueOperations.getAndDelete(any())).thenReturn(info);
    when(actionRepository.resolveAction(any(), anyInt(), any())).thenReturn(false);

    executor.completeClaim("device", null);

    verify(actionRepository, times(1))
        .resolveAction(info.getAssociationId(), info.getActionIndex(), null);
    verify(eventService, times(0)).publishExecuteNextAction(any());
  }

  @Test
  void completeClaim_resolvesAction() {
    when(redisTemplate.opsForValue()).thenReturn(valueOperations);
    PrinterAssociationActionInformation info =
        new PrinterAssociationActionInformation(UUID.randomUUID(), 0);
    when(valueOperations.getAndDelete(any())).thenReturn(info);
    when(actionRepository.resolveAction(any(), anyInt(), any())).thenReturn(true);

    executor.completeClaim("device", null);

    verify(actionRepository, times(1))
        .resolveAction(info.getAssociationId(), info.getActionIndex(), null);
    verify(eventService, times(1)).publishExecuteNextAction(info.getAssociationId());
  }

  @Test
  void execute_throwsException() {
    when(redisTemplate.opsForValue()).thenReturn(valueOperations);
    when(jwtSupplier.get()).thenReturn("token");
    when(httpClient.post(any(), any(), any(), any()))
        .thenThrow(new RestClientException("Exception"));
    Association association = new Association();
    Resource resource =
        Resource.builder()
            .id(ResourceId.builder().type(ResourceIdType.STRING).value("device").build())
            .build();

    ActionExecutionException exception =
        assertThrows(
            ActionExecutionException.class, () -> executor.execute(resource, association, 0));

    verify(redisTemplate, times(1)).delete("device");
    assertTrue(exception.isRetryable());
  }

  @Test
  void getResourceTypeTest() {
    Assertions.assertEquals(ResourceType.PRINTER, executor.getResourceType());
  }
}
