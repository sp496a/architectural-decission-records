package com.hp.stratus.pendingassociations.dto;

import static com.hp.stratus.pendingassociations.dto.State.fromValue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@Tag("UnitTest")
class StateTest {

  @Test
  void fromValueTest() {
    Assertions.assertEquals(State.PENDING, fromValue("pending"));
    Assertions.assertEquals(State.CANCELLED, fromValue("cancelled"));
    Assertions.assertEquals(State.OPEN, fromValue("open"));
    Assertions.assertEquals(State.COMPLETED, fromValue("completed"));
    Assertions.assertNull(fromValue("invalidState"));
  }

}
