/*
 * Copyright (c) 2022, HP Development Company, L.P. All rights reserved. This software contains
 * confidential and proprietary information of HP. The user of this software agrees not to disclose,
 * disseminate or copy such Confidential Information and shall use the software only in accordance
 * with the terms of the license agreement the user entered into with HP.
 *
 */

package com.hp.stratus.pendingassociations.client;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import com.hp.stratus.http.client.utils.HttpClient;
import com.hp.stratus.pendingassociations.dto.HealthResponse;
import com.hp.stratus.pendingassociations.rest.PendingAssociationRestClient;
import java.lang.reflect.Field;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

// TODO: Temporary test class for example purpose only and shall be removed when actual api is
// available for use.

@Tag("UnitTest")
@Tag("ComponentTest")
@ExtendWith(MockitoExtension.class)
class PendingAssociationsClientTest {
  private final String STRATUS_BASE_URL = "https://dev-us1.api.ws-hp.com";
  private final String TOKEN = "token";

  private static HealthResponse RESPONSE;

  private PendingAssociationRestClient pendingAssociationClient;

  @Mock private Environment environment;

  @Mock private HttpClient httpClient;

  @BeforeEach
  void setup() throws Exception {
    Field field = PendingAssociationRestClient.class.getDeclaredField("httpClient");
    field.setAccessible(true);
    pendingAssociationClient = new PendingAssociationRestClient(STRATUS_BASE_URL, environment);
    field.set(pendingAssociationClient, httpClient);

    RESPONSE = prepareHealthResponse();
  }

  @Test
  void testPing() {
    UriComponents uriComponents =
        UriComponentsBuilder.fromUriString(STRATUS_BASE_URL).path("/ping").build().normalize();
    String url = uriComponents.toString();

    ResponseEntity<HealthResponse> responseEntity = ResponseEntity.ok(RESPONSE);

    doReturn(responseEntity).when(httpClient).get(eq(url), eq(TOKEN), any());

    HealthResponse result = pendingAssociationClient.ping(TOKEN);

    assertEquals(RESPONSE, result);
    assertNotNull(result);
    verify(httpClient, times(1)).get(eq(url), eq(TOKEN), any());
  }

  @Test
  void testPing_NotFound() {
    UriComponents uriComponents =
        UriComponentsBuilder.fromUriString(STRATUS_BASE_URL).path("/ping").build().normalize();
    String url = uriComponents.toString();

    ResponseEntity<HealthResponse> responseEntity = new ResponseEntity<>(HttpStatus.BAD_REQUEST);

    doReturn(responseEntity).when(httpClient).get(eq(url), eq(TOKEN), any());

    HealthResponse result = pendingAssociationClient.ping(TOKEN);

    assertNull(result);
    verify(httpClient, times(1)).get(eq(url), eq(TOKEN), any());
  }

  @Test
  void testPing_Exception() {

    UriComponents uriComponents =
        UriComponentsBuilder.fromUriString(STRATUS_BASE_URL).path("/ping").build().normalize();
    String url = uriComponents.toString();

    doThrow(new RuntimeException("not found")).when(httpClient).get(eq(url), eq(TOKEN), any());

    // Run and verify the test
    HealthResponse result = pendingAssociationClient.ping(TOKEN);
    assertNull(result);
  }

  private HealthResponse prepareHealthResponse() {
    HealthResponse response = new HealthResponse();
    response.setName("pending-association-svc");
    response.setStatus("healthy");
    return response;
  }

  @Test
  void pendingAssociationRestClient_ExceptionTest() {
    assertThrows(NullPointerException.class,
        () -> new PendingAssociationRestClient(null, environment));
  }
}
