package com.hp.stratus.pendingassociations.component;

import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.auth.path.PermitAllPathProvider;
import com.hp.stratus.pendingassociations.controller.AssociationRestController;
import com.hp.stratus.pendingassociations.dto.*;
import com.hp.stratus.pendingassociations.exceptions.BadRequestException;
import com.hp.stratus.pendingassociations.exceptions.ConflictException;
import com.hp.stratus.pendingassociations.exceptions.CustomRequestHandler;
import com.hp.stratus.pendingassociations.exceptions.ResourceNotFoundException;
import com.hp.stratus.pendingassociations.service.AssociationService;
import com.hp.stratus.pendingassociations.utils.DataConverterUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Sort;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.springframework.data.domain.Sort;

@Tag("ComponentTest")
@WebMvcTest(value = AssociationRestController.class)
public class AssociationRestControllerTests {
  @JsonValue private static final ObjectMapper objectMapper = new ObjectMapper();
  @MockBean AssociationService associationService;
  @InjectMocks AssociationRestController associationRestController;
  private List<AssociationDto> associationDtoList;
  private MockMvc mockMvc;
  @MockBean PermitAllPathProvider permitAllPathService;

  @BeforeEach
  void setup() throws IOException {
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    associationRestController = new AssociationRestController(associationService);
    mockMvc =
        MockMvcBuilders.standaloneSetup(associationRestController)
            .setControllerAdvice(new CustomRequestHandler())
            .build();
    associationDtoList =
        objectMapper.readValue(
            new File("src/test/resources/data/mongo/Associations.json"), new TypeReference<>() {});
  }

  @Test
  void getAssociationByID_successTest() throws Exception {

    // Setup the test
    AssociationDto associationDto = new AssociationDto();
    UUID id = UUID.randomUUID();
    associationDto.setId(id);
    when(associationService.get(id)).thenReturn(associationDto);

    // Run the test
    mockMvc
        .perform(get("/pending-associations/v1/associations/{associationId}", id))
        .andDo(print())
        .andExpect(content().contentType("application/json"))
        .andExpect(status().isOk())
        .andReturn();

    // Verify the test
    verify(associationService, times(1)).get(id);
    verifyNoMoreInteractions(associationService);
  }

  @Test
  void getSearchPagedAssociationList_successTest() throws Exception {

    // Setup the test
    Page<AssociationDto> testAssociationList = new PageImpl<>(associationDtoList);
    when(associationService.getPaginatedAssociationList(0, 1, null, null))
        .thenReturn(testAssociationList);

    // Run and Verify the Tests
    mockMvc
        .perform(get("/pending-associations/v1/associations?offset=0&limit=1"))
        .andDo(print())
        .andExpect(status().isOk())
        .andReturn();
  }

  @Test
  void getSearchPagedAssociationList_successTest1() throws Exception {

    // Setup the test
    Page<AssociationDto> testAssociationList = new PageImpl<>(associationDtoList);
    String[] sortStrings = {"tenantId:asc"};
    Sort sort = sortStrings == null ? null : DataConverterUtils.convertToSort(List.of(sortStrings));
    when(associationService.getPaginatedAssociationList(0, 1, sort,"tenantId"))
        .thenReturn(testAssociationList);

    // Run and Verify the Tests
    mockMvc
        .perform(get("/pending-associations/v1/associations?offset=0&limit=1&search=tenantId&sortBy=tenantId:asc"))
        .andDo(print())
        .andExpect(status().isOk())
        .andReturn();
  }

  @Test
  void create_successTest() throws Exception {

    // Setup the test
    CreateAssociationRequest createAssociationRequest =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdate.json"),
            CreateAssociationRequest.class);
    CreateAssociationResponse createAssociationRes =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/Association.json"),
            CreateAssociationResponse.class);
    when(associationService.create(Mockito.any(CreateAssociationRequest.class)))
        .thenReturn(createAssociationRes);

    // Run the test
    mockMvc
        .perform(
            post("/pending-associations/v1/associations/")
                .content(objectMapper.writeValueAsString(createAssociationRequest))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
        .andDo(print())
        .andExpect(status().isCreated())
        .andReturn();

    // Verify the test
    verify(associationService, times(1)).create(any());
    verifyNoMoreInteractions(associationService);
  }

  @Test
  void create_successTest2() throws Exception {

    // Setup the test
    CreateAssociationRequest createAssociationRequest =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdate2.json"),
            CreateAssociationRequest.class);
    CreateAssociationResponse createAssociationRes =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/Association.json"),
            CreateAssociationResponse.class);
    when(associationService.create(Mockito.any(CreateAssociationRequest.class)))
        .thenReturn(createAssociationRes);

    // Run the test
    mockMvc
        .perform(
            post("/pending-associations/v1/associations/")
                .content(objectMapper.writeValueAsString(createAssociationRequest))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
        .andDo(print())
        .andExpect(status().isCreated())
        .andReturn();

    // Verify the test
    verify(associationService, times(1)).create(any());
    verifyNoMoreInteractions(associationService);
  }

  @Test
  void putAssociationByID_ResourceNotFound() throws Exception {

    // Setup the test
    PutAssociationRequest putAssociationRequest =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdateForPatch.json"),
            PutAssociationRequest.class);
    when(associationService.put(any(UUID.class), any(PutAssociationRequest.class)))
        .thenThrow(new ResourceNotFoundException());

    // Run the test
    mockMvc
        .perform(
            put("/pending-associations/v1/associations/{associationId}", UUID.randomUUID())
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("UTF-8")
                .content(objectMapper.writeValueAsString(putAssociationRequest))
                .accept(MediaType.APPLICATION_JSON))
        .andDo(print())
        .andExpect(status().isNotFound())
        .andReturn();

    // Verify the test
    verify(associationService, times(1)).put(any(UUID.class), any(PutAssociationRequest.class));
    verifyNoMoreInteractions(associationService);
  }

  @Test
  void putAssociationByID_HttpMessageNotReadableException() throws Exception {

    // Setup the test
    PutAssociationRequest putAssociationRequest =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdateForPatch.json"),
            PutAssociationRequest.class);
    when(associationService.put(any(UUID.class), any(PutAssociationRequest.class)))
        .thenThrow(new HttpMessageNotReadableException("error input in testing"));

    // Run the test
    mockMvc
        .perform(
            put("/pending-associations/v1/associations/{associationId}", UUID.randomUUID())
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("UTF-8")
                .content(objectMapper.writeValueAsString(putAssociationRequest))
                .accept(MediaType.APPLICATION_JSON))
        .andDo(print())
        .andExpect(status().isBadRequest())
        .andReturn();

    // Verify the test
    verify(associationService, times(1)).put(any(UUID.class), any(PutAssociationRequest.class));
    verifyNoMoreInteractions(associationService);
  }

  @Test
  void putAssociationByID_successTest() throws Exception {

    // Setup the test
    PutAssociationRequest putAssociationRequest =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdateForPatch.json"),
            PutAssociationRequest.class);
    PutAssociationResponse putAssociationResponse =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/Association.json"), PutAssociationResponse.class);
    when(associationService.put(any(UUID.class), any(PutAssociationRequest.class)))
        .thenReturn(putAssociationResponse);

    // Run the test
    mockMvc
        .perform(
            put("/pending-associations/v1/associations/{associationId}", UUID.randomUUID())
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("UTF-8")
                .content(objectMapper.writeValueAsString(putAssociationRequest))
                .accept(MediaType.APPLICATION_JSON))
        .andDo(print())
        .andExpect(status().isOk())
        .andReturn();

    // Verify the test
    verify(associationService, times(1)).put(any(UUID.class), any(PutAssociationRequest.class));
    verifyNoMoreInteractions(associationService);
  }

  @Test
  void deleteAssociationTest() throws Exception {

    // Setup the test
    when(associationService.delete(any())).thenReturn(1L);
    UUID id = UUID.randomUUID();

    // Run the test
    mockMvc
        .perform(delete("/pending-associations/v1/associations/{associationId}", id))
        .andDo(print())
        .andExpect(status().isOk())
        .andReturn();

    // Verify the test
    verify(associationService, times(1)).delete(any());
    verifyNoMoreInteractions(associationService);
  }

  @Test
  void patch_successTest() throws Exception {
    // Setup Test
    PatchAssociationRequest patchAssociationRequest =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdateForPatch.json"),
            PatchAssociationRequest.class);
    PatchAssociationResponse patchAssociationResponse =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/Association.json"),
            PatchAssociationResponse.class);
    when(associationService.patch(any(), any(PatchAssociationRequest.class)))
        .thenReturn(patchAssociationResponse);

    // Run Test
    mockMvc
        .perform(
            patch("/pending-associations/v1/associations/{assocationId}", UUID.randomUUID())
                .content(objectMapper.writeValueAsString(patchAssociationRequest))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
        .andDo(print())
        .andExpect(status().isOk())
        .andReturn();

    // Verify Test
    verify(associationService, times(1)).patch(any(), any());
    verifyNoMoreInteractions(associationService);
  }

  @Test
  void head_successTest() throws Exception {

    // Setup the test
    String contentRange = "1" + "-" + "3" + "/" + "5";
    when(associationService.head(1, 2)).thenReturn(contentRange);

    // Run the test
    MvcResult mvcResult =
        mockMvc
            .perform(head("/pending-associations/v1/associations?offset=1&limit=2"))
            .andDo(print())
            .andExpect(status().isOk())
            .andReturn();

    // Verify the test
    assertEquals(contentRange, mvcResult.getResponse().getHeader("contentRange"));
    verify(associationService, times(1)).head(1, 2);
    verifyNoMoreInteractions(associationService);
  }

  @Test
  void putAssociationByID_ConflictException() throws Exception {

    // Setup the test
    PutAssociationRequest putAssociationRequest =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdateForPatch.json"),
            PutAssociationRequest.class);
    when(associationService.put(any(UUID.class), any(PutAssociationRequest.class)))
        .thenThrow(new ConflictException());

    // Run the test
    mockMvc
        .perform(
            put("/pending-associations/v1/associations/{associationId}", UUID.randomUUID())
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("UTF-8")
                .content(objectMapper.writeValueAsString(putAssociationRequest))
                .accept(MediaType.APPLICATION_JSON))
        .andDo(print())
        .andExpect(status().isConflict())
        .andReturn();

    // Verify the test
    verify(associationService, times(1)).put(any(UUID.class), any(PutAssociationRequest.class));
    verifyNoMoreInteractions(associationService);
  }
}
