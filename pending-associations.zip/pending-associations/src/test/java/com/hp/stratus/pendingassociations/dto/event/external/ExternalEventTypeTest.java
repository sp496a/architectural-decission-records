package com.hp.stratus.pendingassociations.dto.event.external;

import static com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType.fromValue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@Tag("UnitTest")
class ExternalEventTypeTest {

  @Test
  void fromValueTest() {
    Assertions.assertEquals(ExternalEventType.ADDED, fromValue("ADDED"));
    Assertions.assertEquals(ExternalEventType.DELETED, fromValue("DELETED"));
    Assertions.assertEquals(ExternalEventType.UPDATED, fromValue("UPDATED"));
    Assertions.assertNull(fromValue("invalidExternalEventType"));
  }
}
