package com.hp.stratus.pendingassociations.action.associate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.http.client.utils.HttpClient;
import com.hp.stratus.pendingassociations.dto.client.ChromebookClaimRequest;
import com.hp.stratus.pendingassociations.dto.client.PcManufacturingCatalogDevice;
import com.hp.stratus.pendingassociations.dto.client.PcManufacturingCatalogResponse;
import com.hp.stratus.pendingassociations.exceptions.ActionExecutionException;
import com.hp.stratus.pendingassociations.model.*;
import com.hp.stratus.pendingassociations.repository.ActionRepository;
import com.hp.stratus.pendingassociations.service.EventService;
import com.hp.stratus.pendingassociations.utils.PathResolver;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
class AssociateChromebookExecutorTest {

  private final ObjectMapper objectMapper = new ObjectMapper();
  private final PathResolver pathResolver = new PathResolver(objectMapper);

  @Mock ActionRepository actionRepository;
  @Mock EventService eventService;
  @Mock HttpClient httpClient;
  @Mock Supplier<String> jwtSupplier;

  private AssociateChromebookExecutor executor;

  @BeforeEach
  void setup() {
    executor =
        new AssociateChromebookExecutor(
            objectMapper,
            pathResolver,
            actionRepository,
            eventService,
            httpClient,
            jwtSupplier,
            "chromebookBase",
            "/chromebookEndpoint",
            "pcMfgBase",
            "/pcMfgEndpoint");
  }

  @Test
  void getResourceType_returnsTheCorrectResourceType() {
    assertEquals(ResourceType.CHROMEBOOK, executor.getResourceType());
  }

  @Test
  void execute_claimsTheChromebook() {
    Association association = createStandardAssociation();
    Resource resource = createStandardResource();
    PcManufacturingCatalogResponse pcResponse = createStandardPcMfgResponse();
    when(httpClient.get((URI) any(), any(), any()))
        .thenReturn(new ResponseEntity<>(pcResponse, HttpStatus.OK));
    ResponseEntity<Map<String, Object>> response = ResponseEntity.ok(Map.of("key", "value"));
    doReturn(response).when(httpClient).post(any(), any(), any(), any());
    when(jwtSupplier.get()).thenReturn("token");
    when(actionRepository.resolveAction(any(), anyInt(), any())).thenReturn(true);

    executor.execute(resource, association, 0);

    verify(httpClient, times(1))
        .get(
            eq(URI.create("pcMfgBase/pcMfgEndpoint?serialNumber=serial&productNumber=model")),
            eq("token"),
            any());
    verify(httpClient, times(1))
        .post(
            eq("chromebookBase/chromebookEndpoint"),
            eq("token"),
            eq(
                ChromebookClaimRequest.builder()
                    .deviceUniqueId("deviceUniqueId")
                    .tenantId("tenantId")
                    .build()),
            any());
    verify(actionRepository, times(1))
        .resolveAction(association.getId(), 0, Map.of("key", "value"));
    verify(eventService, times(1)).publishExecuteNextAction(association.getId());
  }

  @Test
  void execute_throwsUnretryableActionExecutionExceptionWhenPcMfgReturns4xx() {
    Association association = createStandardAssociation();
    Resource resource = createStandardResource();
    when(httpClient.get((URI) any(), any(), any()))
        .thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST));

    ActionExecutionException exception =
        assertThrows(
            ActionExecutionException.class, () -> executor.execute(resource, association, 0));

    assertFalse(exception.isRetryable());
  }

  @Test
  void execute_throwsRetryableActionExecutionExceptionWhenPcMfgReturns5xx() {
    Association association = createStandardAssociation();
    Resource resource = createStandardResource();
    when(httpClient.get((URI) any(), any(), any()))
        .thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

    ActionExecutionException exception =
        assertThrows(
            ActionExecutionException.class, () -> executor.execute(resource, association, 0));

    assertTrue(exception.isRetryable());
  }

  @Test
  void execute_throwsRetryableActionExecutionExceptionWhenPcMfgThrowsANetworkError() {
    Association association = createStandardAssociation();
    Resource resource = createStandardResource();
    when(httpClient.get((URI) any(), any(), any())).thenThrow(new RuntimeException());

    ActionExecutionException exception =
        assertThrows(
            ActionExecutionException.class, () -> executor.execute(resource, association, 0));

    assertTrue(exception.isRetryable());
  }

  @Test
  void execute_throwsUnretryableActionExecutionExceptionWhenPcMfgThrowsReturnsNothing() {
    Association association = createStandardAssociation();
    Resource resource = createStandardResource();
    when(httpClient.get((URI) any(), any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));

    ActionExecutionException exception =
        assertThrows(
            ActionExecutionException.class, () -> executor.execute(resource, association, 0));

    assertFalse(exception.isRetryable());
  }

  @Test
  void execute_throwsUnretryableActionExecutionExceptionWhenPcMfgReturnsAnEmptyList() {
    Association association = createStandardAssociation();
    Resource resource = createStandardResource();
    PcManufacturingCatalogResponse pcResponse = new PcManufacturingCatalogResponse();
    pcResponse.setDevices(new ArrayList<>());
    when(httpClient.get((URI) any(), any(), any()))
        .thenReturn(new ResponseEntity<>(pcResponse, HttpStatus.OK));

    ActionExecutionException exception =
        assertThrows(
            ActionExecutionException.class, () -> executor.execute(resource, association, 0));

    assertFalse(exception.isRetryable());
  }

  @Test
  void execute_throwsUnretryableActionExecutionExceptionWhenChromebookRegistryReturns4xx() {
    Association association = createStandardAssociation();
    Resource resource = createStandardResource();
    PcManufacturingCatalogResponse pcResponse = createStandardPcMfgResponse();
    when(httpClient.get((URI) any(), any(), any()))
        .thenReturn(new ResponseEntity<>(pcResponse, HttpStatus.OK));
    when(httpClient.post(any(), any(), any(), any()))
        .thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST));

    ActionExecutionException exception =
        assertThrows(
            ActionExecutionException.class, () -> executor.execute(resource, association, 0));

    assertFalse(exception.isRetryable());
  }

  @Test
  void execute_completesActionWhenChromebookRegistryReturnsAConflict() {
    Association association = createStandardAssociation();
    Resource resource = createStandardResource();
    PcManufacturingCatalogResponse pcResponse = createStandardPcMfgResponse();
    when(httpClient.get((URI) any(), any(), any()))
        .thenReturn(new ResponseEntity<>(pcResponse, HttpStatus.OK));
    when(httpClient.post(any(), any(), any(), any()))
        .thenThrow(new HttpClientErrorException(HttpStatus.CONFLICT));
    when(actionRepository.resolveAction(any(), anyInt(), any())).thenReturn(true);

    executor.execute(resource, association, 0);

    verify(actionRepository, times(1))
        .resolveAction(
            association.getId(),
            0,
            Map.of("message", "chromebook with ID deviceUniqueId is already claimed"));
    verify(eventService, times(1)).publishExecuteNextAction(association.getId());
  }

  @Test
  void execute_throwsRetryableActionExecutionExceptionWhenChromebookRegistryReturns5xx() {
    Association association = createStandardAssociation();
    Resource resource = createStandardResource();
    PcManufacturingCatalogResponse pcResponse = createStandardPcMfgResponse();
    when(httpClient.get((URI) any(), any(), any()))
        .thenReturn(new ResponseEntity<>(pcResponse, HttpStatus.OK));
    when(httpClient.post(any(), any(), any(), any()))
        .thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

    ActionExecutionException exception =
        assertThrows(
            ActionExecutionException.class, () -> executor.execute(resource, association, 0));

    assertTrue(exception.isRetryable());
  }

  @Test
  void execute_throwsRetryableActionExecutionExceptionWhenChromebookRegistryReturnsANetworkError() {
    Association association = createStandardAssociation();
    Resource resource = createStandardResource();
    PcManufacturingCatalogResponse pcResponse = createStandardPcMfgResponse();
    when(httpClient.get((URI) any(), any(), any()))
        .thenReturn(new ResponseEntity<>(pcResponse, HttpStatus.OK));
    when(httpClient.post(any(), any(), any(), any())).thenThrow(new RuntimeException("failed"));

    ActionExecutionException exception =
        assertThrows(
            ActionExecutionException.class, () -> executor.execute(resource, association, 0));

    assertTrue(exception.isRetryable());
  }

  @Test
  void execute_doesntFireNextActionEventIfNoActionsWereCompleted() {
    Association association = createStandardAssociation();
    Resource resource = createStandardResource();
    PcManufacturingCatalogResponse pcResponse = createStandardPcMfgResponse();
    when(httpClient.get((URI) any(), any(), any()))
        .thenReturn(new ResponseEntity<>(pcResponse, HttpStatus.OK));
    when(httpClient.post(any(), any(), any(), any()))
        .thenReturn(new ResponseEntity<>(HttpStatus.OK));
    when(actionRepository.resolveAction(any(), anyInt(), any())).thenReturn(false);

    executor.execute(resource, association, 0);

    verify(eventService, times(0)).publishExecuteNextAction(association.getId());
  }

  private Association createStandardAssociation() {
    Association association = new Association();
    association.setId(UUID.randomUUID());
    association.setTenantId("tenantId");
    return association;
  }

  private Resource createStandardResource() {
    return Resource.builder()
        .serial(ResourceId.builder().type(ResourceIdType.STRING).value("serial").build())
        .model(ResourceId.builder().type(ResourceIdType.STRING).value("model").build())
        .build();
  }

  private PcManufacturingCatalogResponse createStandardPcMfgResponse() {

    PcManufacturingCatalogDevice device = new PcManufacturingCatalogDevice();
    device.setDeviceUniqueId("deviceUniqueId");
    List<PcManufacturingCatalogDevice> devices = List.of(device);

    PcManufacturingCatalogResponse pcResponse = new PcManufacturingCatalogResponse();
    pcResponse.setDevices(devices);
    return pcResponse;
  }
}
