package com.hp.stratus.pendingassociations.dto.event.external;


import static com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource.fromValue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@Tag("UnitTest")
class ExternalEventResourceTest {

  @Test
  void fromValueTest() {
    Assertions.assertEquals(ExternalEventResource.PC_CLAIM, fromValue("com.hp.onecloud.iot.claim"));
    Assertions.assertEquals(ExternalEventResource.PC_REGISTRATION,
        fromValue("com.hp.onecloud.iot.registration"));
    Assertions
        .assertEquals(ExternalEventResource.PRINTER_CLAIM, fromValue("com.hp.stratus.iot.claim"));
    Assertions.assertEquals(ExternalEventResource.PRINTER_REGISTRATION,
        fromValue("com.hp.stratus.iot.device.registration"));
    Assertions.assertEquals(ExternalEventResource.PENDING_ASSOCIATION,
        fromValue("com.hp.stratus.pendingassociation"));
    Assertions.assertNull(fromValue("invalidExternalEventResource"));
  }
}
