package com.hp.stratus.pendingassociations.dto;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@Tag("UnitTest")
class ConditionsOperatorDtoTest {

  @Test
  void fromValue_returnsMatchingValue() {
    Assertions.assertEquals(ConditionsOperatorDto.AND, ConditionsOperatorDto.fromValue("and"));
  }

  @Test
  void fromValue_returnsNullIfNotFound() {
    Assertions.assertNull(ConditionsOperatorDto.fromValue("invalidValue"));
  }
}
