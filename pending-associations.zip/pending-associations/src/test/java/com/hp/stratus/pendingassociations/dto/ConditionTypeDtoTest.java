package com.hp.stratus.pendingassociations.dto;

import static com.hp.stratus.pendingassociations.dto.ConditionTypeDto.fromValue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@Tag("UnitTest")
class ConditionTypeDtoTest {

  @Test
  void fromValueTest() {
    Assertions.assertEquals(ConditionTypeDto.POINTER, fromValue("pointer"));
    Assertions.assertEquals(ConditionTypeDto.STRING, fromValue("string"));
    Assertions.assertNull(fromValue("invalidConditionTypeDto"));
  }

}
