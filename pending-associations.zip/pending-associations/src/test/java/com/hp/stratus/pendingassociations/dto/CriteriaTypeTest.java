package com.hp.stratus.pendingassociations.dto;

import static com.hp.stratus.pendingassociations.dto.CriteriaType.fromValue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@Tag("UnitTest")
class CriteriaTypeTest {

  @Test
  void fromValueTest() {
    Assertions.assertEquals(CriteriaType.EVENT_RECEIVED, fromValue("eventReceived"));
    Assertions.assertNull(fromValue("invalidCriteriaType"));
  }

}
