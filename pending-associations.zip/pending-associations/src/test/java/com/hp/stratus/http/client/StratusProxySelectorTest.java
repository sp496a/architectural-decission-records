package com.hp.stratus.http.client;

import com.hp.stratus.http.client.config.StratusProxySelector;
import java.net.ProxySelector;
import java.util.HashSet;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.env.Environment;

import java.net.Proxy;
import java.net.URI;
import java.util.List;

import static com.hp.stratus.http.client.utils.HttpConstants.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@Tag("UnitTest")
@ExtendWith(MockitoExtension.class)
class StratusProxySelectorTest {

  @Mock private Environment environment;
  private final String NON_PROXY_URL_HTTP = "http://localhost";
  private final String NON_PROXY_URL_HTTPS = "https://localhost";
  private final String NON_PROXY_URL = "localhost";

  @BeforeEach
  void setup() {

    // Setup the test
    when(environment.getProperty(HTTP_PROXY_HOST_KEY)).thenReturn(NON_PROXY_URL_HTTP);
    when(environment.getProperty(HTTP_PROXY_PORT_KEY, String.valueOf(HTTP_PROXY_PORT_DEFAULT)))
        .thenReturn(String.valueOf(HTTP_PROXY_PORT_DEFAULT));
    when(environment.getProperty(HTTPS_PROXY_HOST_KEY)).thenReturn(NON_PROXY_URL_HTTPS);
    when(environment.getProperty(HTTPS_PROXY_PORT_KEY, String.valueOf(HTTPS_PROXY_PORT_DEFAULT)))
        .thenReturn(String.valueOf(HTTPS_PROXY_PORT_DEFAULT));
    when(environment.getProperty(HTTP_NON_PROXY_KEY)).thenReturn(NON_PROXY_URL);
  }

  @Test
  void select_httpProxy_Test() throws Exception {

    StratusProxySelector selector = new StratusProxySelector(environment);
    URI uri = new URI(NON_PROXY_URL_HTTP);

    // Run and verify the test
    List<Proxy> proxyList = selector.select(uri);

    // Verify the test
    assertEquals(1, proxyList.size());
  }

  @Test
  void select_httpsProxy_Test() throws Exception {

    StratusProxySelector selector = new StratusProxySelector(environment);

    URI uri = new URI(NON_PROXY_URL_HTTPS);

    // Run and verify the test
    List<Proxy> proxyList = selector.select(uri);

    // Verify the test
    assertEquals(1, proxyList.size());
  }

  @Test
  void select_noProxyList_Test() throws Exception {

    StratusProxySelector selector = new StratusProxySelector(environment);

    URI uri = new URI("https://localhost");

    // Run and verify the test
    List<Proxy> proxyList = selector.select(uri);

    // Verify the test
    assertEquals(1, proxyList.size());
  }

  @Test
  void select_supportedProtocols_Test() throws Exception {

    StratusProxySelector selector = new StratusProxySelector(environment);
    URI uri = new URI("http://pending");

    // Run and verify the test
    List<Proxy> proxyList = selector.select(uri);

    // Verify the test
    assertEquals(2, proxyList.size());
  }
}
