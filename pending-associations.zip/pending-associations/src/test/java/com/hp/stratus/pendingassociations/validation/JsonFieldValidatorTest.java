package com.hp.stratus.pendingassociations.validation;

import jakarta.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

@Tag("UnitTest")
public class JsonFieldValidatorTest {

  private JsonFieldValidation jsonFieldValidation = mock(JsonFieldValidation.class);

  private ConstraintValidatorContext constraintValidatorContext =
      mock(ConstraintValidatorContext.class);

  private JsonFieldValidator jsonFieldValidator = new JsonFieldValidator();

  @BeforeEach
  void setUp() {
    jsonFieldValidator.initialize(jsonFieldValidation);
  }

  @Test
  public void nullMeta_successTest() {
    // Setup the test
    Object meta = null;

    // Run the test
    boolean result = jsonFieldValidator.isValid(meta, constraintValidatorContext);

    // Validate the test
    assertTrue(result);
  }

  @Test
  public void jsonMeta_successTest() {
    // Setup the test
    HashMap<String, String> map1 = new HashMap<>();
    map1.put("name0", "ABC");
    Object meta = map1;

    // Run the test
    boolean result = jsonFieldValidator.isValid(meta, constraintValidatorContext);

    // Validate the test
    assertTrue(result);
  }

  @Test
  public void jsonArrayMeta_successTest() {
    // Setup the test
    Object meta = new ArrayList<HashMap>();
    HashMap<String, String> map1 = new HashMap<>();
    map1.put("name0", "ABC");

    // Run the test
    boolean result = jsonFieldValidator.isValid(meta, constraintValidatorContext);

    // Validate the test
    assertTrue(result);
  }

  @Test
  public void stringMeta_failureTest() {
    // Setup the test
    Object meta = "AAAAA";

    // Run the test
    boolean result = jsonFieldValidator.isValid(meta, constraintValidatorContext);

    // Validate the test
    assertFalse(result);
  }
}
