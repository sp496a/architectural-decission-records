package com.hp.stratus.http.client.utils;

import org.junit.Test;
import org.junit.jupiter.api.Tag;

import static org.junit.jupiter.api.Assertions.assertEquals;

@Tag("ComponentTest")
@Tag("UnitTest")
public class HttpConstantsTest {

  @Test
  public void testConstants() {
    assertEquals("http", HttpConstants.URL_SCHEME_HTTP);
    assertEquals("https", HttpConstants.URL_SCHEME_HTTPS);

    // Proxy
    assertEquals("http.proxyHost", HttpConstants.HTTP_PROXY_HOST_KEY);
    assertEquals("http.proxyPort", HttpConstants.HTTP_PROXY_PORT_KEY);
    assertEquals("https.proxyHost", HttpConstants.HTTPS_PROXY_HOST_KEY);
    assertEquals("https.proxyPort", HttpConstants.HTTPS_PROXY_PORT_KEY);
    assertEquals("http.nonProxyHosts", HttpConstants.HTTP_NON_PROXY_KEY);
    assertEquals(80, HttpConstants.HTTP_PROXY_PORT_DEFAULT);
    assertEquals(443, HttpConstants.HTTPS_PROXY_PORT_DEFAULT);
  }
}
