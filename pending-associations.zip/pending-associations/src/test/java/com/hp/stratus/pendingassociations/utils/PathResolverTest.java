package com.hp.stratus.pendingassociations.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import javax.json.Json;
import javax.json.JsonStructure;
import java.util.List;

@Tag("UnitTest")
class PathResolverTest {

  private static final ObjectMapper objectMapper = new ObjectMapper();

  private PathResolver pathResolver;

  @BeforeEach
  void setup() {
    pathResolver = new PathResolver(objectMapper);
    pathResolver.setup();
  }

  @Test
  void resolvePath_resolvesASinglePath() {
    JsonStructure structure = Json.createObjectBuilder().add("test", "abc").build();

    List<String> values = pathResolver.resolvePath("$.test", structure);

    Assertions.assertEquals(1, values.size());
    Assertions.assertEquals("abc", values.get(0));
  }

  @Test
  void resolvePath_resolvesMultiplePaths() {
    JsonStructure structure =
        Json.createArrayBuilder()
            .add(Json.createObjectBuilder().add("test", "abc").build())
            .add(Json.createObjectBuilder().add("test", "def").build())
            .build();

    List<String> values = pathResolver.resolvePath("$[*].test", structure);

    Assertions.assertEquals(2, values.size());
    Assertions.assertEquals("abc", values.get(0));
    Assertions.assertEquals("def", values.get(1));
  }

  @Test
  void resolvePath_resolvesWithoutMatches() {
    JsonStructure structure = Json.createObjectBuilder().add("test", "abc").build();

    List<String> values = pathResolver.resolvePath("$.test2", structure);

    Assertions.assertEquals(0, values.size());
  }
}
