package com.hp.stratus.pendingassociations.config;

import com.hp.stratus.library.log.ILogger;
import com.hp.stratus.library.log.LoggerFactory;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
public class LoggingConfigTest {

  private LoggingConfig config = new LoggingConfig("test");

  @Test
  void loggerFactory_returnsFactory() {
    LoggerFactory factory = config.loggerFactory();

    assertNotNull(factory);
  }

  @Test
  void iLogger_returnsLogger() {
    ILogger logger = config.iLogger(config.loggerFactory());

    assertNotNull(logger);
  }
}
