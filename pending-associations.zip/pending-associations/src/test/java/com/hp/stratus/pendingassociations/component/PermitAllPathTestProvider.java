package com.hp.stratus.pendingassociations.component;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class PermitAllPathTestProvider
    extends com.hp.stratus.pendingassociations.auth.PermitAllPathProviderImpl {

  /**
   * Returns the list of paths that are always permitted.
   *
   * @return The list of paths.
   */
  public List<String> getPathForPermitAll() {
    return Arrays.asList(
        "/pending-associations/**", // ignore auth when controller test
        "/ping",
        "/pending-associations/health",
        "/pending-associations/spec");
  }
}
