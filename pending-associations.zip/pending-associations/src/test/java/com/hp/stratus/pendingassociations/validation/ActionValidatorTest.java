package com.hp.stratus.pendingassociations.validation;

import com.hp.stratus.pendingassociations.dto.*;
import com.hp.stratus.pendingassociations.exceptions.BadRequestException;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

@Tag("UnitTest")
@Tag("ComponentTest")
class ActionValidatorTest {

  @Test
  void validate_validatesAListOfResources() {
    AssociationUpdateActionsDto action = new AssociationUpdateActionsDto();
    action.setOperation(Operation.ASSOCIATE);
    action.setResource(new ResourceDto());
    action.getResource().setType(ResourceType.PRINTER);

    assertDoesNotThrow(() -> ActionValidator.validate(List.of(action)));
  }

  @Test
  void validate_throwsWhenNoResourcesArePassedToAssociate() {
    AssociationUpdateActionsDto action = new AssociationUpdateActionsDto();
    action.setOperation(Operation.ASSOCIATE);

    assertThrows(BadRequestException.class, () -> ActionValidator.validate(action));
  }

  @Test
  void validate_throwsWhenMultipleResourcesArePassedToAssociate() {
    AssociationUpdateActionsDto action = new AssociationUpdateActionsDto();
    action.setOperation(Operation.ASSOCIATE);
    action.setResources(new ResourcesDto());

    assertThrows(BadRequestException.class, () -> ActionValidator.validate(action));
  }

  @Test
  void validate_throwsWhenUserResourceIsPassedToAssociate() {
    AssociationUpdateActionsDto action = new AssociationUpdateActionsDto();
    action.setOperation(Operation.ASSOCIATE);
    action.setResource(new ResourceDto());
    action.getResource().setType(ResourceType.USER);

    assertThrows(BadRequestException.class, () -> ActionValidator.validate(action));
  }

  @Test
  void validate_doesNotThrowWhenValidAssociateResourceIsSupplied() {
    AssociationUpdateActionsDto action = new AssociationUpdateActionsDto();
    action.setOperation(Operation.ASSOCIATE);
    action.setResource(new ResourceDto());
    action.getResource().setType(ResourceType.PRINTER);

    assertDoesNotThrow(() -> ActionValidator.validate(action));
  }

  @Test
  void validate_throwsWhenNoResourceIsPassedToAssociateConsent() {
    AssociationUpdateActionsDto action = new AssociationUpdateActionsDto();
    action.setOperation(Operation.ASSOCIATE_CONSENT);

    assertThrows(BadRequestException.class, () -> ActionValidator.validate(action));
  }

  @Test
  void validate_throwsWhenSingleResourceIsPassedToAssociateConsent() {
    AssociationUpdateActionsDto action = new AssociationUpdateActionsDto();
    action.setOperation(Operation.ASSOCIATE_CONSENT);
    action.setResource(new ResourceDto());

    assertThrows(BadRequestException.class, () -> ActionValidator.validate(action));
  }

  @Test
  void validate_throwsWhenInvalidUserResourceIsPassedToAssociateConsent() {
    AssociationUpdateActionsDto action = new AssociationUpdateActionsDto();
    action.setOperation(Operation.ASSOCIATE_CONSENT);
    action.setResources(new ResourcesDto());
    action.getResources().setUser(new ResourceDto());
    action.getResources().getUser().setType(ResourceType.PRINTER);

    assertThrows(BadRequestException.class, () -> ActionValidator.validate(action));
  }

  @Test
  void validate_throwsWhenInvalidDeviceResourceIsPassedToAssociateConsent() {
    AssociationUpdateActionsDto action = new AssociationUpdateActionsDto();
    action.setOperation(Operation.ASSOCIATE_CONSENT);
    action.setResources(new ResourcesDto());
    action.getResources().setUser(new ResourceDto());
    action.getResources().getUser().setType(ResourceType.USER);
    action.getResources().setDevice(new ResourceDto());
    action.getResources().getDevice().setType(ResourceType.USER);

    assertThrows(BadRequestException.class, () -> ActionValidator.validate(action));
  }

  @Test
  void validate_doesNotThrowWhenValidAssociateConsentResourcesAreSupplied() {
    AssociationUpdateActionsDto action = new AssociationUpdateActionsDto();
    action.setOperation(Operation.ASSOCIATE_CONSENT);
    action.setResources(new ResourcesDto());
    action.getResources().setUser(new ResourceDto());
    action.getResources().getUser().setType(ResourceType.USER);
    action.getResources().setDevice(new ResourceDto());
    action.getResources().getDevice().setType(ResourceType.PRINTER);

    assertDoesNotThrow(() -> ActionValidator.validate(action));
  }

  @Test
  void validate_withResourceAndNoResources() {
    AssociationUpdateActionsDto action = new AssociationUpdateActionsDto();
    action.setOperation(Operation.ASSOCIATE);
    action.setResource(new ResourceDto());
    action.getResource().setType(ResourceType.PRINTER);
    action.setResources(new ResourcesDto());

    assertThrows(BadRequestException.class, () -> ActionValidator.validate(action));
  }

  @Test
  void validate_withResourceAndNoResources1() {
    AssociationUpdateActionsDto action = new AssociationUpdateActionsDto();
    action.setOperation(Operation.ASSOCIATE_CONSENT);
    action.setResource(new ResourceDto());
    action.getResource().setType(ResourceType.PRINTER);
    action.setResources(new ResourcesDto());

    assertThrows(BadRequestException.class, () -> ActionValidator.validate(action));
  }

  @Test
  void validate_withValidUpdateMetadataAction() {
    AssociationUpdateActionsDto action = new AssociationUpdateActionsDto();
    action.setOperation(Operation.UPDATE_METADATA);
    action.setResources(new ResourcesDto());
    action.getResources().getUntypedResources().put("test", new ResourceIdDto());

    assertDoesNotThrow(() -> ActionValidator.validate(action));
  }

  @Test
  void validate_withInvalidUpdateMetadataAction() {
    AssociationUpdateActionsDto action = new AssociationUpdateActionsDto();
    action.setOperation(Operation.UPDATE_METADATA);
    action.setResources(new ResourcesDto());

    assertThrows(BadRequestException.class, () -> ActionValidator.validate(action));
  }
}
