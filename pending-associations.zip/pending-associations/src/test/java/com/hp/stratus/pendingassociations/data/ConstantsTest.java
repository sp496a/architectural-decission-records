package com.hp.stratus.pendingassociations.data;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@Tag("UnitTest")
public class ConstantsTest {

  @Test
  void constantsTest() {
    assertEquals("id", Constants.ID);
    assertEquals("Pending Associations Service API",
        Constants.PENDING_ASSOCIATIONS_SERVICE_API_TITLE);
    assertEquals("v1.0.0", Constants.PENDING_ASSOCIATIONS_SERVICE_API_VERSION);
  }

}
