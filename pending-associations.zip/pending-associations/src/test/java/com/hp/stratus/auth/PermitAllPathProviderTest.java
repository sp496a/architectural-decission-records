package com.hp.stratus.auth;

import com.hp.stratus.pendingassociations.auth.PermitAllPathProviderImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import java.util.List;

@Tag("UnitTest")
@Tag("ComponentTest")
public class PermitAllPathProviderTest {

  @Test
  void defaultPermitAllPathProviderTest() throws Exception {
    // Setup the test
    PermitAllPathProviderImpl defaultPermitAllPathProvider = new PermitAllPathProviderImpl();

    // Run the test
    List<String> defaulPermitAllPaths = defaultPermitAllPathProvider.getPathForPermitAll();

    // Verify the test
    Assertions.assertNotNull(
        defaulPermitAllPaths, "DefaultPermitAllPathProvider provided incorrect null list");
    Assertions.assertEquals(
        3,
        defaulPermitAllPaths.size(),
        "DefaultPermitAllPathProvider changed, please check unit test");
  }
}
