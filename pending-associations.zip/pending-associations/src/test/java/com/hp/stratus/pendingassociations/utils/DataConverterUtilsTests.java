package com.hp.stratus.pendingassociations.utils;

import com.hp.stratus.pendingassociations.exceptions.PendingAssociationException;
import org.junit.jupiter.api.Assertions;
import org.junit.Assert;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

import java.util.List;
import org.springframework.http.HttpStatus;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@Tag("UnitTest")
public class DataConverterUtilsTests {
  @Test
  public void testConvertToSort() {
    String property1 = "id";
    String property2 = "name";
    String direction1 = "asc";
    String direction2 = "desc";
    String sortString1 = property1 + ":" + direction1;
    String sortString2 = property2 + ":" + direction2;
    List<String> sortStrings = List.of(sortString1, sortString2);

    Sort sort = DataConverterUtils.convertToSort(sortStrings);

    assertNotNull(sort);
    assertEquals(2, sort.toList().size());
    sort.forEach(
        order -> {
          if (order.getProperty().equals(property1)) {
            assertEquals(order.getDirection(), (Direction.ASC));
          } else if (order.getProperty().equals(property2)) {
            assertEquals(order.getDirection(), (Direction.DESC));
          } else {
            throw new RuntimeException("Unrecoginzed property.");
          }
        });
  }

  @Test
  public void testSort() {
    List<String> stringList = List.of("id: ASC", "name: ASC");
    Sort orderList = DataConverterUtils.convertToSort(stringList);
    assertNotEquals(stringList.toArray().toString(), orderList.get().toArray().toString());
  }

  @Test
  public void testNullSort() {
    Sort orderList = DataConverterUtils.convertToSort(null);
    assertNull(orderList);
  }

  @Test
  public void testErrorSort() {
    List<String> stringList = List.of("id:&*", "name:$%");
    PendingAssociationException exception = assertThrows(PendingAssociationException.class, () -> {
      DataConverterUtils.convertToSort(stringList);
    });
    assertEquals(HttpStatus.BAD_REQUEST, exception.getStatus());
  }

  @Test
  public void testSortWithOnlyName() {
    List<String> stringList = List.of("id");
    Sort orderList = DataConverterUtils.convertToSort(stringList);
    assertNotEquals(stringList.toArray().toString(), orderList.get().toArray().toString());
    List<String> stringList1 = List.of("id", "name");
    Sort orderList1 = DataConverterUtils.convertToSort(stringList1);
    assertNotEquals(stringList.toArray().toString(), orderList.get().toArray().toString());
  }
}
