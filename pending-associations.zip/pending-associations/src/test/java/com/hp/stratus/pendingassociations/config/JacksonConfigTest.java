package com.hp.stratus.pendingassociations.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@Tag("UnitTest")
public class JacksonConfigTest {

  private final JacksonConfig config = new JacksonConfig();

  @Test
  void objectMapper_returnsMapper() {
    ObjectMapper mapper = config.objectMapper();

    assertNotNull(mapper);
    Assertions.assertEquals(mapper.getRegisteredModuleIds().size(), 1);
  }
}
