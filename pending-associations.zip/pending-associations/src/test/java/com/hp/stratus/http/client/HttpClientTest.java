/*
 * Copyright (c) 2021, HP Development Company, L.P. All rights reserved.
 *  This software contains confidential and proprietary information of HP.
 *  The user of this software agrees not to disclose, disseminate or copy
 *  such Confidential Information and shall use the software only in accordance
 *  with the terms of the license agreement the user entered into with HP.
 */

package com.hp.stratus.http.client;

import com.hp.stratus.http.client.utils.HttpClient;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@Tag("UnitTest")
@Tag("ComponentTest")
@ExtendWith(MockitoExtension.class)
class HttpClientTest {
  public static final java.lang.String HEADER_TENANT_ID_KEY = "x-hp-tenant-id";
  private static final String TENANT_ID = "tenantId";
  private static final Map<String, String> requestHeaders = new HashMap<>();
  private HttpClient httpClient;

  @Mock private RestTemplate restTemplate;

  @BeforeAll
  public static void init() {
    requestHeaders.put(HEADER_TENANT_ID_KEY, TENANT_ID);
  }

  @BeforeEach
  void setup() {
    httpClient = new HttpClient(restTemplate);
  }

  @Test
  void getWithUrlString() {
    String url = "https://devicecache.com";
    String token = "token";
    ResponseEntity<String> response = ResponseEntity.ok().build();
    ParameterizedTypeReference<String> type = new ParameterizedTypeReference<>() {};
    doReturn(response).when(restTemplate).exchange(eq(url), eq(HttpMethod.GET), any(), eq(type));

    ResponseEntity<String> result = httpClient.get(url, token, type);

    assertNull(result.getBody());
    assertEquals(HttpStatus.OK, result.getStatusCode());
  }

  @Test
  void getWithUri() {
    URI uri = URI.create("https://devicecache.com");
    String token = "token";
    ResponseEntity<String> response = ResponseEntity.ok().build();
    ParameterizedTypeReference<String> type = new ParameterizedTypeReference<>() {};
    doReturn(response).when(restTemplate).exchange(eq(uri), eq(HttpMethod.GET), any(), eq(type));

    ResponseEntity<String> result = httpClient.get(uri, token, type);

    assertNull(result.getBody());
    assertEquals(HttpStatus.OK, result.getStatusCode());
  }

  @Test
  void testCreateEntity() {
    String body = "body";
    String token = "token";
    String headerKey = "headerKey1";
    String headerValue = "headerValue1";
    Map<String, String> customHeaders = Map.of(headerKey, headerValue);

    HttpEntity<String> entity = httpClient.createEntity(body, customHeaders, token);

    assertEquals(body, entity.getBody());
    assertTrue(entity.getHeaders().containsKey(HttpHeaders.CONTENT_TYPE));
    assertEquals(MediaType.APPLICATION_JSON, entity.getHeaders().getContentType());
    assertTrue(entity.getHeaders().containsKey(HttpHeaders.AUTHORIZATION));
    assertEquals(
        "Bearer " + token,
        Objects.requireNonNull(entity.getHeaders().get(HttpHeaders.AUTHORIZATION)).get(0));
    assertTrue(entity.getHeaders().containsKey(headerKey));
    assertEquals(headerValue, Objects.requireNonNull(entity.getHeaders().get(headerKey)).get(0));

    assertThrows(NullPointerException.class, () -> httpClient.createEntity(body, null, token));
  }

  @Test
  void testCreateEmptyEntity() {
    String token = "token";

    HttpEntity<String> entity = httpClient.createEmptyEntity((token));

    assertNull(entity.getBody());
    assertTrue(entity.getHeaders().containsKey(HttpHeaders.CONTENT_TYPE));
    assertEquals(MediaType.APPLICATION_JSON, entity.getHeaders().getContentType());
    assertTrue(entity.getHeaders().containsKey(HttpHeaders.AUTHORIZATION));
    assertEquals(
        "Bearer " + token,
        Objects.requireNonNull(entity.getHeaders().get(HttpHeaders.AUTHORIZATION)).get(0));
  }

  @Test
  void testPut() {
    String url = "https://devicecache.com";
    String token = "token";
    String data = "data";
    HttpEntity<String> request = httpClient.createEntityWithBody(data, token);
    ResponseEntity<String> response = ResponseEntity.ok().build();
    ParameterizedTypeReference<String> type = new ParameterizedTypeReference<>() {};
    doReturn(response).when(restTemplate).exchange(eq(url), eq(HttpMethod.PUT), any(), eq(type));

    ResponseEntity<String> result = httpClient.put(url, token, request, type);

    assertEquals(HttpStatus.OK, result.getStatusCode());
    assertThrows(NullPointerException.class, () -> httpClient.put(null, token, request, type));
  }

  @Test
  void testPost() {
    String url = "https://devicecache.com";
    String token = "token";
    String data = "data";
    HttpEntity<String> request = httpClient.createEntityWithBody(data, token);
    ResponseEntity<String> response = ResponseEntity.ok().build();
    ParameterizedTypeReference<String> type = new ParameterizedTypeReference<>() {};
    doReturn(response).when(restTemplate).exchange(eq(url), eq(HttpMethod.POST), any(), eq(type));

    ResponseEntity<String> result = httpClient.post(url, token, request, type);

    assertEquals(HttpStatus.OK, result.getStatusCode());
    assertThrows(NullPointerException.class, () -> httpClient.post(null, token, request, type));
  }

  @Test
  void testDelete() {
    String url = "https://devicecache.com";
    String token = "token";
    ResponseEntity<String> response = ResponseEntity.ok().build();
    ParameterizedTypeReference<String> type = new ParameterizedTypeReference<>() {};
    doReturn(response).when(restTemplate).exchange(eq(url), eq(HttpMethod.DELETE), any(), eq(type));

    ResponseEntity<String> result = httpClient.delete(url, token, type);

    assertEquals(HttpStatus.OK, result.getStatusCode());
    assertThrows(NullPointerException.class, () -> httpClient.delete(null, token, type));
  }

  @Test
  void testCreateEntityWithBody() {
    String token = "token";
    String data = "data";
    HttpEntity<String> entity = httpClient.createEntityWithBody(data, token);

    assertNotNull(entity.getBody());
    assertTrue(entity.getHeaders().containsKey(HttpHeaders.CONTENT_TYPE));
    assertEquals(MediaType.APPLICATION_JSON, entity.getHeaders().getContentType());
    assertTrue(entity.getHeaders().containsKey(HttpHeaders.AUTHORIZATION));
    assertEquals(
        "Bearer " + token,
        Objects.requireNonNull(entity.getHeaders().get(HttpHeaders.AUTHORIZATION)).get(0));
  }

  @Test
  void testGet_withCustomerHeader() {
    String url = "https://devicecache.com";
    String token = "token";
    ResponseEntity<String> response = ResponseEntity.ok().build();
    ParameterizedTypeReference<String> type = new ParameterizedTypeReference<>() {};
    doReturn(response).when(restTemplate).exchange(eq(url), eq(HttpMethod.GET), any(), eq(type));

    ResponseEntity<String> result = httpClient.get(url, token, requestHeaders, type);

    assertNull(result.getBody());
    assertEquals(HttpStatus.OK, result.getStatusCode());

    assertThrows(NullPointerException.class, () -> httpClient.get(null, token, null, type));
  }

  @Test
  void testPut_withCustomerHeader() {
    String url = "https://devicecache.com";
    String token = "token";
    String data = "data";
    HttpEntity<String> request = httpClient.createEntity(data, requestHeaders, token);
    ResponseEntity<String> response = ResponseEntity.ok().build();
    ParameterizedTypeReference<String> type = new ParameterizedTypeReference<>() {};
    doReturn(response).when(restTemplate).exchange(eq(url), eq(HttpMethod.PUT), any(), eq(type));

    ResponseEntity<String> result = httpClient.put(url, token, requestHeaders, request, type);

    assertEquals(HttpStatus.OK, result.getStatusCode());
  }

  @Test
  void testPost_withCustomerHeader() {
    String url = "https://devicecache.com";
    String token = "token";
    String data = "data";
    HttpEntity<String> request = httpClient.createEntity(data, requestHeaders, token);
    ResponseEntity<String> response = ResponseEntity.ok().build();
    ParameterizedTypeReference<String> type = new ParameterizedTypeReference<>() {};
    doReturn(response).when(restTemplate).exchange(eq(url), eq(HttpMethod.POST), any(), eq(type));

    ResponseEntity<String> result = httpClient.post(url, token, requestHeaders, request, type);
    assertEquals(HttpStatus.OK, result.getStatusCode());
    assertThrows(
        NullPointerException.class,
        () -> httpClient.post(null, token, requestHeaders, request, type));
    assertThrows(
        NullPointerException.class, () -> httpClient.post(url, token, null, request, type));
  }

  @Test
  void testDelete_withCustomerHeader() {
    String url = "https://devicecache.com";
    String token = "token";
    ResponseEntity<String> response = ResponseEntity.ok().build();
    ParameterizedTypeReference<String> type = new ParameterizedTypeReference<>() {};
    doReturn(response).when(restTemplate).exchange(eq(url), eq(HttpMethod.DELETE), any(), eq(type));

    ResponseEntity<String> result = httpClient.delete(url, token, requestHeaders, type);

    assertEquals(HttpStatus.OK, result.getStatusCode());
    assertThrows(NullPointerException.class, () -> httpClient.delete(null, token, null, type));
  }

  @Test
  void testGet_nullParameter() {
    String url = "https://devicecache.com";
    String token = "token";
    ParameterizedTypeReference<String> type = new ParameterizedTypeReference<>() {};

    assertThrows(NullPointerException.class, () -> httpClient.get(url, token, null, type));
    verify(restTemplate, never()).exchange(eq(url), eq(HttpMethod.GET), any(), eq(type));
  }

  @Test
  void testPost_nullParameter() {
    String url = "https://devicecache.com";
    String token = "token";
    String data = "data";
    HttpEntity<String> request = httpClient.createEntity(data, requestHeaders, token);
    ParameterizedTypeReference<String> type = new ParameterizedTypeReference<>() {};

    assertThrows(
        NullPointerException.class, () -> httpClient.post(url, token, null, request, type));
    verify(restTemplate, never()).exchange(eq(url), eq(HttpMethod.POST), any(), eq(type));

    assertThrows(NullPointerException.class, () -> httpClient.post(null, token, null, type));
  }

  @Test
  void testPut_nullParameter() {
    String url = "https://devicecache.com";
    String token = "token";
    String data = "data";
    HttpEntity<String> request = httpClient.createEntity(data, requestHeaders, token);
    ParameterizedTypeReference<String> type = new ParameterizedTypeReference<>() {};

    assertThrows(NullPointerException.class, () -> httpClient.put(url, token, null, request, type));
    verify(restTemplate, never()).exchange(eq(url), eq(HttpMethod.PUT), any(), eq(type));
    assertThrows(
        NullPointerException.class, () -> httpClient.put(null, token, null, request, type));
  }

  @Test
  void testDelete_nullParameter() {
    String url = "https://devicecache.com";
    String token = "token";
    ParameterizedTypeReference<String> type = new ParameterizedTypeReference<>() {};

    assertThrows(NullPointerException.class, () -> httpClient.delete(url, token, null, type));
    verify(restTemplate, never()).exchange(eq(url), eq(HttpMethod.DELETE), any(), eq(type));
  }

  @Test
  void testPatch() {
    String url = "https://devicecache.com";
    String token = "token";
    ResponseEntity<String> response = ResponseEntity.ok().build();
    String data = "data";
    HttpEntity<String> request = httpClient.createEntityWithBody(data, token);
    ParameterizedTypeReference<String> type = new ParameterizedTypeReference<>() {};
    doReturn(response).when(restTemplate).exchange(eq(url), eq(HttpMethod.PATCH), any(), eq(type));

    ResponseEntity<String> result = httpClient.patch(url, token, request, type);

    assertEquals(HttpStatus.OK, result.getStatusCode());

    assertThrows(NullPointerException.class, () -> httpClient.patch(null, token, request, type));
  }
}
