package com.hp.stratus.pendingassociations.utils;

import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.exceptions.ResourceResolutionException;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.ResourceId;
import com.hp.stratus.pendingassociations.model.ResourceIdType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
class ResourceUtilsTest {
  @JsonValue private static final ObjectMapper objectMapper = new ObjectMapper();

  @Mock ObjectMapper mockObjectMapper;

  @Mock PathResolver mockPathResolver;

  @BeforeEach
  void setup() throws Exception {
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  }
  
  @Test
  void testStringValue() {
    ResourceId id = new ResourceId();
    id.setType(ResourceIdType.STRING);
    id.setValue("TestValue");

    String value =
        ResourceUtils.resolveResource(objectMapper, mockPathResolver, new Association(), id);

    assertEquals("TestValue", value);
  }

  @Test
  void testPointerValue() throws IOException {
    ResourceId id = new ResourceId();
    id.setType(ResourceIdType.POINTER);
    id.setValue("/some/json/pointer/0/irrelevant/to/test/result");
    Association association =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/Association.json"), Association.class);
    try (MockedStatic mocked = mockStatic(PointerUtils.class)) {
      mocked.when(() -> PointerUtils.resolvePointer(any(), any())).thenReturn("resolvedValue");

      String value = ResourceUtils.resolveResource(objectMapper, mockPathResolver, association, id);

      assertEquals("resolvedValue", value);
    }
  }

  @Test
  void testPointerValueNotResolved() throws IOException {
    ResourceId id = new ResourceId();
    id.setType(ResourceIdType.POINTER);
    id.setValue("/some/json/pointer/0/irrelevant/to/test/result");
    Association association =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdate2.json"), Association.class);
    association.setId(UUID.randomUUID());
    assertThrows(
        ResourceResolutionException.class,
        () -> ResourceUtils.resolveResource(objectMapper, mockPathResolver, association, id));
  }

  @Test
  void testPointerValueJsonProcessingException() throws IOException {
    ResourceId id = new ResourceId();
    id.setType(ResourceIdType.POINTER);
    id.setValue("/some/json/pointer/0/irrelevant/to/test/result");
    when(mockObjectMapper.writeValueAsString(any(Object.class)))
        .thenThrow(mock(JsonProcessingException.class));
    Association association =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/Association.json"), Association.class);

    assertThrows(
        ResourceResolutionException.class,
        () -> ResourceUtils.resolveResource(mockObjectMapper, mockPathResolver, association, id));
  }

  @Test
  void testPathValue() throws IOException {
    ResourceId id = new ResourceId();
    id.setType(ResourceIdType.PATH);
    id.setValue("$.some.irrelevant.path");
    Association association =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/Association.json"), Association.class);
    when(mockPathResolver.resolvePath(any(), any())).thenReturn(List.of("resolvedValue"));

    String value = ResourceUtils.resolveResource(objectMapper, mockPathResolver, association, id);

    assertEquals("resolvedValue", value);
  }

  @Test
  void testPathValueNotResolved() throws IOException {
    ResourceId id = new ResourceId();
    id.setType(ResourceIdType.PATH);
    id.setValue("$.some.irrelevant.path");
    Association association =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdate2.json"), Association.class);
    association.setId(UUID.randomUUID());
    assertThrows(
        ResourceResolutionException.class,
        () -> ResourceUtils.resolveResource(objectMapper, mockPathResolver, association, id));
  }

  @Test
  void testPathValueJsonProcessingException() throws IOException {
    ResourceId id = new ResourceId();
    id.setType(ResourceIdType.PATH);
    id.setValue("$.some.irrelevant.path");
    when(mockObjectMapper.writeValueAsString(any(Object.class)))
        .thenThrow(mock(JsonProcessingException.class));
    Association association =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/Association.json"), Association.class);

    assertThrows(
        ResourceResolutionException.class,
        () -> ResourceUtils.resolveResource(mockObjectMapper, mockPathResolver, association, id));
  }
}
