package com.hp.stratus.pendingassociations.auth;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

@Tag("UnitTest")
public class PermitAllPathProviderTest {

  @Test
  void getPathForPermitAll_returnsPaths() {
    PermitAllPathProviderImpl permitAllPathProvider = new PermitAllPathProviderImpl();

    List<String> paths = permitAllPathProvider.getPathForPermitAll();

    Assertions.assertLinesMatch(
        paths,
        Arrays.asList("/ping", "/pending-associations/health", "/pending-associations/spec"));
  }
}
