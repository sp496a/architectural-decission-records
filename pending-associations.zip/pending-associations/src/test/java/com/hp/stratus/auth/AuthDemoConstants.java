package com.hp.stratus.auth;

import com.hp.stratus.pendingassociations.auth.Scope;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class AuthDemoConstants {

  private AuthDemoConstants() {}

  public enum ScopeDemo {
    CREATE("ws-hp.com/pending-associations/association.CREATE"),
    READ("ws-hp.com/pending-associations/association.READ"),
    UPDATE("ws-hp.com/pending-associations/association.UPDATE"),
    DELETE("ws-hp.com/pending-associations/association.DELETE");

    private String value;

    ScopeDemo(String scope) {
      this.value = scope;
    }

    public String toString() {
      return value;
    }

    public static final List<String> ALL =
        Arrays.stream(Scope.values()).map(Scope::toString).collect(Collectors.toUnmodifiableList());
  }
}
