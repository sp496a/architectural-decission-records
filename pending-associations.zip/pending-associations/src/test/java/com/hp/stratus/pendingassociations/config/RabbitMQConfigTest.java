package com.hp.stratus.pendingassociations.config;

import com.hp.stratus.pendingassociations.consumer.MessageConsumer;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.FanoutExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
public class RabbitMQConfigTest {

  @Mock MessageConsumer messageConsumer;

  private final RabbitMQConfig rabbitMQConfig =
      new RabbitMQConfig("testQueue", "testExchange", false);

  @Test
  void queue_returnsQueue() {
    Queue queue = rabbitMQConfig.queue();

    assertNotNull(queue);
    assertFalse(queue.shouldDeclare());
  }

  @Test
  void exchange_returnsExchange() {
    FanoutExchange exchange = rabbitMQConfig.exchange();

    assertNotNull(exchange);
    assertFalse(exchange.shouldDeclare());
  }

  @Test
  void binding_returnsBinding() {
    Binding binding = rabbitMQConfig.binding(rabbitMQConfig.queue(), rabbitMQConfig.exchange());

    assertNotNull(binding);
    assertFalse(binding.shouldDeclare());
  }

  @Test
  void listenerContainer_returnsListenerContainer() {
    SimpleMessageListenerContainer container =
        rabbitMQConfig.listenerContainer(new CachingConnectionFactory(), messageConsumer);

    assertNotNull(container);
    assertEquals(container.getMessageListener(), messageConsumer);
    assertEquals(container.getQueueNames().length, 1);
    assertEquals(container.getQueueNames()[0], rabbitMQConfig.queue().getName());
  }
}
