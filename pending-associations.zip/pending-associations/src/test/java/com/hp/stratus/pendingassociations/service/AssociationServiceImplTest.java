package com.hp.stratus.pendingassociations.service;

import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.dto.*;
import com.hp.stratus.pendingassociations.exceptions.BadGatewayException;
import com.hp.stratus.pendingassociations.exceptions.BadRequestException;
import com.hp.stratus.pendingassociations.exceptions.ConflictException;
import com.hp.stratus.pendingassociations.exceptions.ResourceNotFoundException;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.State;
import com.hp.stratus.pendingassociations.repository.AssociationRepository;
import com.hp.stratus.pendingassociations.service.impl.AssociationServiceImpl;
import com.hp.stratus.pendingassociations.utils.DataConverterUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Sort;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
class AssociationServiceImplTest {
  @JsonValue private static final ObjectMapper objectMapper = new ObjectMapper();
  private List<Association> associationList;

  @InjectMocks private AssociationServiceImpl associationServiceImpl;

  @Mock private AssociationRepository associationRepository;
  @Mock private EventService eventService;

  @BeforeEach
  void setUp() throws IOException {
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    associationServiceImpl = new AssociationServiceImpl(associationRepository, eventService);
    associationList =
        objectMapper.readValue(
            new File("src/test/resources/data/mongo/Associations.json"), new TypeReference<>() {});
  }

  @Test
  void getAssociationById_successTest() {

    // Setup the test
    Association expAssociation = new Association();
    UUID id = UUID.randomUUID();
    expAssociation.setId(id);
    when(associationRepository.findById(id)).thenReturn(expAssociation);

    // Run the test
    AssociationDto associationDto = associationServiceImpl.get(id);

    // Verify the test
    verify(associationRepository, times(1)).findById(id);
    assertEquals(expAssociation.getId().toString(), associationDto.getId().toString());
  }

  @Test
  void getAssociationById_failureTest() {

    // Setup the test
    UUID id = UUID.randomUUID();
    when(associationRepository.findById(id)).thenReturn(null);

    // Run and verify the test
    assertThrows(ResourceNotFoundException.class, () -> associationServiceImpl.get(id));
    verify(associationRepository, times(1)).findById(id);
  }

  @Test
  void getSearchPagedAssociationList_successTest() {

    // Setup the test
    int limit = 2;
    String search = "id:1";
    String property1 = "id";
    String property2 = "name";
    String direction1 = "asc";
    String direction2 = "desc";
    String sortString1 = property1 + ":" + direction1;
    String sortString2 = property2 + ":" + direction2;
    List<String> sortStrings = List.of(sortString1, sortString2);
    Sort sort = DataConverterUtils.convertToSort(sortStrings);
    doReturn(new PageImpl<>(associationList))
        .when(associationRepository)
        .getGenericSearchPagedAssociationList(any(), any(), any());

    // Run the test
    Page<AssociationDto> result =
        associationServiceImpl.getPaginatedAssociationList(0, limit, sort, search);

    // verify the test
    assertNotNull(result);
    assertEquals(associationList.size(), result.getContent().size());
    for (int i = 0; i < associationList.size(); i++) {
      assertEquals(associationList.get(i).getId(), result.getContent().get(i).getId());
    }
  }

  @Test
  void getSearchPagedAssociationList_throwsBadRequestWhenSearchIsInvalid() {
    assertThrows(
        BadRequestException.class,
        () -> associationServiceImpl.getPaginatedAssociationList(0, 1, null, "invalid"));
  }

  @Test
  void createAssociation_Test() throws Exception {

    // Setup the test
    CreateAssociationRequest createAssociationRequest =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdate.json"),
            CreateAssociationRequest.class);
    Association association =
        objectMapper.readValue(
            new File("src/test/resources/data/mongo/Association.json"), Association.class);
    when(associationRepository.insert(any(Association.class))).thenReturn(association);

    // Run the test
    CreateAssociationResponse createAssociationRes =
        associationServiceImpl.create(createAssociationRequest);

    // Verify the test
    assertNotNull(createAssociationRes.getId());
  }

  @Test
  void createAssociation_Test1() throws Exception {

    // Setup the test
    CreateAssociationRequest createAssociationRequest =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdate.json"),
            CreateAssociationRequest.class);
    createAssociationRequest.setState(null);
    Association association =
        objectMapper.readValue(
            new File("src/test/resources/data/mongo/Association.json"), Association.class);
    when(associationRepository.insert(any(Association.class))).thenReturn(association);

    // Run the test
    CreateAssociationResponse createAssociationRes =
        associationServiceImpl.create(createAssociationRequest);

    // Verify the test
    assertNotNull(createAssociationRes.getId());
  }

  @Test
  void deleteAssociationTest_returns0WhenNoAssociationsMatch() {

    // Setup the test
    when(associationRepository.findById(any())).thenReturn(null);

    // Run the test
    long res = associationServiceImpl.delete(UUID.randomUUID());

    // Verify the test
    assertEquals(0, res);
  }

  @Test
  void deleteAssociationTest_cancelledState() {

    // Setup the test
    UUID id = UUID.randomUUID();
    Association association = new Association();
    association.setId(id);
    association.setState(State.CANCELLED);
    when(associationRepository.findById(any())).thenReturn(association);

    // Run the test
    long res = associationServiceImpl.delete(id);

    // Verify the test
    assertEquals(0, res);
  }


  @Test
  void deleteAssociationTest_returns1WhenAnAssociationMatches() {

    // Setup the test
    UUID id = UUID.randomUUID();
    Association association = new Association();
    association.setId(id);
    association.setState(State.PENDING);
    when(associationRepository.findById(any())).thenReturn(association);

    // Run the test
    long res = associationServiceImpl.delete(id);

    // Verify the test
    assertEquals(1, res);
  }

  @Test
  void patchAssociationTest() throws Exception {
    // Setup the test
    PatchAssociationRequest associationUpdate =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdateForPatch.json"),
            PatchAssociationRequest.class);
    Association association =
        objectMapper.readValue(
            new File("src/test/resources/data/mongo/Association.json"), Association.class);
    when(associationRepository.findById(any())).thenReturn(association);
    when(associationRepository.save(any(Association.class))).thenReturn(association);

    // Run the test
    PatchAssociationResponse patchAssociationResponse =
        associationServiceImpl.patch(UUID.randomUUID(), associationUpdate);

    // Verify the test
    assertNotNull(patchAssociationResponse);
  }

  @Test
  void patchAssociationTest1() throws Exception {
    // Setup the test
    PatchAssociationRequest associationUpdate =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdateForPatch.json"),
            PatchAssociationRequest.class);
    associationUpdate.setTenantId(null);
    associationUpdate.setState(null);
    associationUpdate.setCriteria(null);
    associationUpdate.setActions(null);
    associationUpdate.setMetadata(null);
    Association association =
        objectMapper.readValue(
            new File("src/test/resources/data/mongo/Association.json"), Association.class);
    when(associationRepository.findById(any())).thenReturn(association);
    when(associationRepository.save(any(Association.class))).thenReturn(association);

    // Run the test
    PatchAssociationResponse patchAssociationResponse =
        associationServiceImpl.patch(UUID.randomUUID(), associationUpdate);

    // Verify the test
    assertNotNull(patchAssociationResponse);
  }

  @Test
  void patchAssociation_InvalidRequestNullAssociation() {
    // Setup the test
    when(associationRepository.findById(any())).thenReturn(null);

    // Run and Verify the test
    assertThrows(
        ResourceNotFoundException.class,
        () -> associationServiceImpl.patch(UUID.randomUUID(), null));
  }


  @Test
  void patchAssociationConflictExceptionTest() throws Exception {
    // Setup the test
    Association association =
        objectMapper.readValue(
            new File("src/test/resources/data/mongo/Association.json"), Association.class);
    association.setState(State.CANCELLED);
    when(associationRepository.findById(any())).thenReturn(association);

    // Run and Verify the test
    assertThrows(
        ConflictException.class,
        () -> associationServiceImpl.patch(UUID.randomUUID(), null));
  }

  @Test
  void putAssociationByID_successTest() throws Exception {

    // Setup the test
    UUID id = UUID.randomUUID();
    PutAssociationRequest putAssociationRequest =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdateForPatch.json"),
            PutAssociationRequest.class);
    Association association =
        objectMapper.readValue(
            new File("src/test/resources/data/mongo/Association.json"), Association.class);
    when(associationRepository.findById(any(UUID.class))).thenReturn(association);
    when(associationRepository.save(any(Association.class))).thenReturn(association);

    // Run the test
    PutAssociationResponse putAssociationRes =
        associationServiceImpl.put(id, putAssociationRequest);

    // Verify the test
    verify(associationRepository, times(1)).findById(any(UUID.class));
    verify(associationRepository, times(1)).save(any(Association.class));
    assertNotNull(putAssociationRes.getId());
  }

  @Test
  void putAssociationByID_failureTest() throws Exception {

    // Setup the test
    UUID id = UUID.randomUUID();
    PutAssociationRequest putAssociationRequest =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdateForPatch.json"),
            PutAssociationRequest.class);
    when(associationRepository.findById(id)).thenReturn(null);

    // Run test
    assertThrows(
        ResourceNotFoundException.class,
        () -> associationServiceImpl.put(id, putAssociationRequest));

    // Verify the test
    verify(associationRepository, times(1)).findById(any(UUID.class));
    verify(associationRepository, times(0)).save(any(Association.class));
  }

  @Test
  void putAssociationByID_failureTest1() throws Exception {

    // Setup the test
    UUID id = UUID.randomUUID();
    PutAssociationRequest putAssociationRequest =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdateForPatch.json"),
            PutAssociationRequest.class);
    Association association =
        objectMapper.readValue(
            new File("src/test/resources/data/mongo/Association.json"), Association.class);
    association.setState(State.PENDING);
    when(associationRepository.findById(id)).thenReturn(association);

    // Run test
    assertThrows(
        ConflictException.class,
        () -> associationServiceImpl.put(id, putAssociationRequest));

    // Verify the test
    verify(associationRepository, times(1)).findById(any(UUID.class));
    verify(associationRepository, times(0)).save(any(Association.class));
  }

  @Test
  void headAssociationTest() {

    // Setup the test
    String actualContentRange = "2" + "-" + "5" + "/" + "50";
    when(associationRepository.count()).thenReturn(50L);

    // Run the test
    String contentRange = associationServiceImpl.head(2, 3);

    // Verify the test
    assertEquals(contentRange, actualContentRange);
  }

  @Test
  void completeAssociation_savesTheAssociationAndFiresAnEvent() {
    Association association = new Association();

    associationServiceImpl.completeAssociation(association);

    verify(associationRepository, times(1)).save(eq(association));
    //    verify(eventService, times(1)).publishAssociationUpdate(eq(association));
    assertEquals(association.getState(), State.COMPLETED);
  }

  @Test
  void cancelAssociation_savesTheAssociation() {
    Association association = new Association();

    associationServiceImpl.cancelAssociation(association);

    verify(associationRepository, times(1)).save(eq(association));
    assertEquals(association.getState(), State.CANCELLED);
  }

  @Test
  void fireAssociationUpdate_firesPublishAssociationupdate() throws Exception {
    // Setup test data
    UUID associationId = UUID.randomUUID();
    Association association =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/Association.json"), Association.class);

    when(associationRepository.findById(associationId)).thenReturn(association);
    doNothing().when(eventService).publishAssociationUpdate(association);

    // Run Test
    associationServiceImpl.fireAssociationUpdate(associationId);

    // Verify the test
    verify(associationRepository, times(1)).findById(any(UUID.class));
    verify(eventService, times(1)).publishAssociationUpdate(any(Association.class));
  }

  @Test
  void putAssociationByID_successTest1() throws Exception {

    // Setup the test
    UUID id = UUID.randomUUID();
    PutAssociationRequest putAssociationRequest =
        objectMapper.readValue(
            new File("src/test/resources/data/dto/AssociationUpdateForPatch.json"),
            PutAssociationRequest.class);
    putAssociationRequest.setState(null);
    Association association =
        objectMapper.readValue(
            new File("src/test/resources/data/mongo/Association.json"), Association.class);
    when(associationRepository.findById(any(UUID.class))).thenReturn(association);
    when(associationRepository.save(any(Association.class))).thenReturn(association);


    // Run the test
    PutAssociationResponse putAssociationRes =
        associationServiceImpl.put(id, putAssociationRequest);

    // Verify the test
    verify(associationRepository, times(1)).findById(any(UUID.class));
    verify(associationRepository, times(1)).save(any(Association.class));
    assertNotNull(putAssociationRes.getId());
  }

  void fireAssociationUpdate_BadGatewayException() throws Exception{
    //Setup test data
    UUID accociationId = UUID.randomUUID();
    Association association =  objectMapper.readValue(
        new File("src/test/resources/data/dto/Association.json"),
        Association.class);
    when(associationRepository.findById(accociationId)).thenReturn(association);
    doThrow(new BadGatewayException()).when(eventService).publishAssociationUpdate(association);
    // Run and Verify the test
    assertThrows(
        BadGatewayException.class,
        () -> associationServiceImpl.fireAssociationUpdate(accociationId));

    doThrow(new BadGatewayException("Event service thrown 500 error")).when(eventService).publishAssociationUpdate(association);
    // Run and Verify the test
    assertThrows(
        BadGatewayException.class,
        () -> associationServiceImpl.fireAssociationUpdate(accociationId));

    doThrow(new BadGatewayException("Event service thrown 500 error", new RuntimeException())).when(eventService).publishAssociationUpdate(association);
    // Run and Verify the test
    assertThrows(
        BadGatewayException.class,
        () -> associationServiceImpl.fireAssociationUpdate(accociationId));

  }

  @Test
  void fireAssociationUpdate_null() throws Exception{
    //Setup test data
    UUID accociationId = UUID.randomUUID();
    when(associationRepository.findById(accociationId)).thenReturn(null);
    // Run and Verify the test
    associationServiceImpl.fireAssociationUpdate(accociationId);
    verify(eventService, times(0)).publishAssociationUpdate(any(Association.class));
  }

}
