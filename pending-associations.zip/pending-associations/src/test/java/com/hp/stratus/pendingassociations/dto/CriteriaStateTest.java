package com.hp.stratus.pendingassociations.dto;

import static com.hp.stratus.pendingassociations.dto.CriteriaState.fromValue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@Tag("UnitTest")
class CriteriaStateTest {

  @Test
  void fromValueTest() {
    Assertions.assertEquals(CriteriaState.PENDING, fromValue("pending"));
    Assertions.assertEquals(CriteriaState.RESOLVED, fromValue("resolved"));
    Assertions.assertNull(fromValue("invalidCriteriaState"));
  }

}
