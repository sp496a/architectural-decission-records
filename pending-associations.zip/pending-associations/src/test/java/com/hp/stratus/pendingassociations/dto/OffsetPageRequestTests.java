/*
 * Copyright (c) 2021, HP Development Company, L.P. All rights reserved. This software contains
 * confidential and proprietary information of HP. The user of this software agrees not to disclose,
 * disseminate or copy such Confidential Information and shall use the software only in accordance
 * with the terms of the license agreement the user entered into with HP.
 */
package com.hp.stratus.pendingassociations.dto;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.hp.stratus.pendingassociations.utils.DataConverterUtils;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Sort;

@Tag("UnitTest")
class OffsetPageRequestTests {
  @Test
  void testOffsetPageRequest() {
    int offset = 0;
    int limit = 1;
    String property = "id";
    String direction = "asc";
    String sortString = property + ":" + direction;
    List<String> sortStrings = List.of(sortString);

    Sort sort = DataConverterUtils.convertToSort(sortStrings);
    String search = "";
    OffsetSearchPageRequest pageable = new OffsetSearchPageRequest(offset, limit, sort, search);

    assertNotNull(pageable);
    assertNotNull(sort);
    Assertions.assertEquals(0, pageable.getOffset());
    Assertions.assertEquals(1, pageable.getPageSize());
    Assertions.assertEquals(0, pageable.getPageNumber());
    Assertions.assertEquals(pageable.getSort(), sort);
    Assertions.assertFalse(pageable.hasPrevious());
    Assertions.assertNotNull(pageable.getSortOr(sort));
    Assertions.assertTrue(pageable.isPaged());
    Assertions.assertNotNull(pageable.next());
    Assertions.assertFalse(pageable.isUnpaged());
    Assertions.assertNotNull(pageable.previousOrFirst());
    Assertions.assertNotNull(pageable.toOptional());
    Assertions.assertNotNull(pageable.withPage(1));
    Assertions.assertNotNull(pageable.first());
    Assertions.assertNotNull(pageable.previous());

    OffsetSearchPageRequest pageable1 = new OffsetSearchPageRequest(10, 2, null, search);
    Assertions.assertNotNull(pageable1.previous());
    Assertions.assertEquals(8, pageable1.previous().getOffset());
    Assertions.assertNotNull(pageable1.previousOrFirst());
    Assertions.assertNotNull(pageable1.getSort());
  }
}
