package com.hp.stratus.pendingassociations.utils;

import com.hp.stratus.pendingassociations.dto.PagedResponse;
import com.hp.stratus.pendingassociations.model.Association;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNotNull;

/** read file as resources */
public class ResponseUtilsTests {
  @Test
  public void testResponseUtils() {
    int size = 1;
    Association association = new Association();
    UUID id = UUID.randomUUID();
    association.setId(id);
    List<Association> associationList = new ArrayList<>();
    associationList.add(association);
    PagedResponse<Association> pagedResponse =
        ResponseUtils.generatePagedResponse(associationList, size);
    assertNotNull(pagedResponse);
  }
}
