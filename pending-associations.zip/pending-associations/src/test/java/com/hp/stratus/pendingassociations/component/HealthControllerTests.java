package com.hp.stratus.pendingassociations.component;

import com.hp.stratus.auth.conf.SecurityConfig;
import com.hp.stratus.pendingassociations.auth.PermitAllPathProviderImpl;
import com.hp.stratus.pendingassociations.controller.HealthController;
import com.hp.stratus.pendingassociations.service.SpecService;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@Tag("ComponentTest")
@WebMvcTest(value = HealthController.class)
@Import(value = {PermitAllPathProviderImpl.class})
@ImportAutoConfiguration(classes = SecurityConfig.class)
class HealthControllerTests {

  @MockBean private SpecService specService;

  @Autowired private MockMvc mockMvc;

  @Test
  void healthTest() throws Exception {
    mockMvc
        .perform(get("/pending-associations/health"))
        .andDo(print())
        .andExpect(status().isOk())
        .andReturn();
  }

  @Test
  void pingTest() throws Exception {
    mockMvc.perform(get("/ping")).andDo(print()).andExpect(status().isOk()).andReturn();
  }

  @Test
  void specTest() throws Exception {
    mockMvc
        .perform(get("/pending-associations/spec"))
        .andDo(print())
        .andExpect(status().isOk())
        .andReturn();
  }
}
