package com.hp.stratus.pendingassociations.consumer.internal;

import com.hp.stratus.pendingassociations.dto.event.internal.InternalEvent;
import com.hp.stratus.pendingassociations.dto.event.internal.InternalEventType;
import com.hp.stratus.pendingassociations.service.ActionService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
public class CriteriaResolvedConsumerTest {

  @Mock ActionService actionService;

  private CriteriaResolvedConsumer consumer;

  @BeforeEach
  void setup() {
    consumer = new CriteriaResolvedConsumer(actionService);
  }

  @Test
  void eventType_returnsCriteriaResolvedType() {
    Assertions.assertEquals(consumer.eventType(), InternalEventType.CRITERIA_RESOLVED);
  }

  @Test
  void handleEvent_callsTheActionService() {
    InternalEvent event = new InternalEvent(InternalEventType.CRITERIA_RESOLVED, UUID.randomUUID());

    consumer.handleEvent(event);

    verify(actionService, times(1)).beginExecution(eq(event.getAssociation()));
  }
}
