package com.hp.stratus.pendingassociations.utils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import javax.json.Json;
import javax.json.JsonStructure;

@Tag("UnitTest")
public class PointerUtilsTest {

  @Test
  public void resolvePointer_addsPrefix() {
    JsonStructure structure = Json.createObjectBuilder().add("test", "abc").build();

    String value = PointerUtils.resolvePointer("test", structure);

    Assertions.assertEquals(value, "abc");
  }

  @Test
  public void resolvePointer_returnsNullIfNotFound() {
    JsonStructure structure = Json.createObjectBuilder().add("test", "abc").build();

    String value = PointerUtils.resolvePointer("notReal", structure);

    Assertions.assertNull(value);
  }

  @Test
  public void resolvePointer_returnsJsonStringIfValueIsNotAString() {
    JsonStructure structure =
        Json.createObjectBuilder().add("test", Json.createObjectBuilder().add("a", "b")).build();

    String value = PointerUtils.resolvePointer("test", structure);

    Assertions.assertEquals(value, "{\"a\":\"b\"}");
  }

  @Test
  public void resolvePointer_returnsNullWhenReferencingInsideANonObject() {
    JsonStructure structure = Json.createObjectBuilder().add("test", "abc").build();

    String value = PointerUtils.resolvePointer("test/notReal", structure);

    Assertions.assertNull(value);
  }
}
