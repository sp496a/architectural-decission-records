package com.hp.stratus.pendingassociations.repository;

import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.ConditionComparator;
import com.hp.stratus.pendingassociations.model.aggregation.AggregatePointerResult;
import com.hp.stratus.pendingassociations.model.aggregation.ConditionValueField;
import com.hp.stratus.pendingassociations.repository.impl.CriteriaRepositoryImpl;
import com.mongodb.client.result.UpdateResult;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import java.io.File;
import java.io.IOException;
import java.util.List;

import static com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource.FULFILLMENT_TRADE_ORDER;
import static com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType.UPDATED;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
class CriteriaRepositoryImplTest {

  @JsonValue private static final ObjectMapper objectMapper = new ObjectMapper();
  @Mock MongoTemplate mongoTemplate;
  @InjectMocks CriteriaRepositoryImpl criteriaRepository;
  Association association;
  private List<Association> associationList;

  @BeforeEach
  void setUp() throws IOException {
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    association =
        objectMapper.readValue(
            new File("src/test/resources/data/mongo/Association.json"), new TypeReference<>() {});
    associationList =
        objectMapper.readValue(
            new File("src/test/resources/data/mongo/Associations.json"), new TypeReference<>() {});
  }

  @Test
  void findUniquePendingEventPointers_Test() {
    AggregationResults resultMock = mock(AggregationResults.class);
    when(mongoTemplate.aggregate(
            any(Aggregation.class), eq(Association.class), eq(AggregatePointerResult.class)))
        .thenReturn(resultMock);
    Assertions.assertNotNull(
        criteriaRepository.findUniquePendingEventPointers(
            ExternalEventResource.PC_REGISTRATION, ExternalEventType.ADDED));
  }

  @Test
  void findAssociationsWithConditions() {
    when(mongoTemplate.find(any(Query.class), eq(Association.class))).thenReturn(associationList);
    Assertions.assertNotNull(
        criteriaRepository.findAssociationsWithConditions(FULFILLMENT_TRADE_ORDER, UPDATED));
  }

  @Test
  void resolvePendingCriteria_Test() {
    UpdateResult updateResult = mock(UpdateResult.class);
    when(mongoTemplate.updateMulti(any(Query.class), any(Update.class), eq(Association.class)))
        .thenReturn(updateResult);
    Assertions.assertEquals(
        0,
        criteriaRepository.resolvePendingCriteria(
            "pointer", ConditionValueField.value1, ConditionComparator.EQUALS, association));
  }

  @Test
  void getPendingAssociationsWithCompletedCriteria_Test() {
    when(mongoTemplate.find(any(Query.class), eq(Association.class))).thenReturn(associationList);
    Assertions.assertNotNull(criteriaRepository.getPendingAssociationsWithCompletedCriteria());
  }
}
