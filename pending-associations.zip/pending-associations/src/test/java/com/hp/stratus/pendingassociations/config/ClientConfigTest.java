package com.hp.stratus.pendingassociations.config;

import com.hp.stratus.fleet.jwtvalidation.util.JwtGenerator;
import com.hp.stratus.http.client.utils.HttpClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestTemplate;

import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
public class ClientConfigTest {

  @Mock JwtGenerator generator;
  @Mock Environment environment;

  private ClientConfig config;

  @BeforeEach
  void setup() {
    config = new ClientConfig(environment);
  }

  @Test
  void restTemplate_returnsTemplate() {
    RestTemplate template = config.restTemplate();

    assertNotNull(template);
  }

  @Test
  void httpClient_returnsClient() {
    HttpClient client = config.httpClient(config.restTemplate());

    assertNotNull(client);
  }

  @Test
  void jwtSupplier_returnsSupplier() {
    Supplier<String> supplier = config.jwtSupplier(generator);

    assertNotNull(supplier);
  }

  @Test
  void restTemplate_EnvironmentNull() {
    ClientConfig config1 = new ClientConfig(null);
    RestTemplate template = config1.restTemplate();
    assertNotNull(template);
  }
}
