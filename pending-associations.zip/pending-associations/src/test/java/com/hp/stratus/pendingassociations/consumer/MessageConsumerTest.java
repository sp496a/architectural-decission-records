package com.hp.stratus.pendingassociations.consumer;

import com.hp.stratus.pendingassociations.config.JacksonConfig;
import com.hp.stratus.pendingassociations.consumer.external.ExternalEventConsumer;
import com.hp.stratus.pendingassociations.consumer.external.PcClaimAddedConsumer;
import com.hp.stratus.pendingassociations.consumer.internal.InternalEventConsumer;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType;
import com.hp.stratus.pendingassociations.dto.event.internal.InternalEvent;
import com.hp.stratus.pendingassociations.dto.event.internal.InternalEventType;
import com.launchdarkly.shaded.kotlin.text.Charsets;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import software.amazon.awssdk.core.SdkBytes;
import software.amazon.awssdk.services.kms.KmsClient;
import software.amazon.awssdk.services.kms.model.DecryptRequest;
import software.amazon.awssdk.services.kms.model.DecryptResponse;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.List;
import java.util.UUID;

import static org.junit.Assert.assertThrows;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
@Tag("ComponentTest")
public class MessageConsumerTest {

  @Mock KmsClient kmsClient;
  @Mock ExternalEventConsumer mockExternalConsumer;
  @Mock InternalEventConsumer mockInternalConsumer;

  private MessageConsumer messageConsumer;
  @Mock
  PcClaimAddedConsumer pcClaimAddedConsumer;

  @BeforeEach
  void setup() {
    messageConsumer =
        new MessageConsumer(
            new JacksonConfig().objectMapper(),
            List.of(mockExternalConsumer),
            List.of(mockInternalConsumer),
            kmsClient);
  }

  @Test
  void onMessage_internal_throwsAmqpRejectionWhenEventJsonIsInvalid() {

    // Set up the message
    byte[] msgBytes = "invalidJson".getBytes(StandardCharsets.UTF_8);
    MessageProperties msgProperties = new MessageProperties();
    msgProperties.setAppId(InternalEvent.INTERNAL_EVENT_APP_ID);

    // Fire the event
    assertThrows(
        AmqpRejectAndDontRequeueException.class,
        () -> messageConsumer.onMessage(new Message(msgBytes, msgProperties)));
  }

  @Test
  void onMessage_internal_doesntCallNonMatchingConsumers() {

    // Set up the consumer and message
    Mockito.when(mockInternalConsumer.eventType()).thenReturn(InternalEventType.CRITERIA_RESOLVED);
    byte[] msgBytes =
        ("{\"type\": \"EXECUTE_NEXT_ACTION\", \"association\":\"" + UUID.randomUUID() + "\"}")
            .getBytes(StandardCharsets.UTF_8);
    MessageProperties msgProperties = new MessageProperties();
    msgProperties.setAppId(InternalEvent.INTERNAL_EVENT_APP_ID);

    // Fire the event
    messageConsumer.onMessage(new Message(msgBytes, msgProperties));

    Mockito.verify(mockInternalConsumer, Mockito.times(0)).handleEvent(ArgumentMatchers.any());
  }

  @Test
  void onMessage_internal_callsTheMatchingConsumer() {

    // Set up the consumer and message
    Mockito.when(mockInternalConsumer.eventType()).thenReturn(InternalEventType.CRITERIA_RESOLVED);
    byte[] msgBytes =
        ("{\"type\": \"CRITERIA_RESOLVED\", \"association\":\"" + UUID.randomUUID() + "\"}")
            .getBytes(StandardCharsets.UTF_8);
    MessageProperties msgProperties = new MessageProperties();
    msgProperties.setAppId(InternalEvent.INTERNAL_EVENT_APP_ID);

    // Fire the event
    messageConsumer.onMessage(new Message(msgBytes, msgProperties));

    Mockito.verify(mockInternalConsumer, Mockito.times(1)).handleEvent(ArgumentMatchers.any());
  }

  @Test
  void onMessage_external_throwsAmqpRejectionWhenDecryptionFails() {

    // Set up the decryption mock
    Mockito.when(kmsClient.decrypt(ArgumentMatchers.any(DecryptRequest.class)))
        .thenThrow(new NullPointerException("whoops"));

    // Make sure we throw a rejection
    assertThrows(
        AmqpRejectAndDontRequeueException.class,
        () -> messageConsumer.onMessage(new Message(new byte[] {})));
  }

  @Test
  void onMessage_external_throwsAmqpRejectionWhenEventJsonIsInvalid() {

    // Set up the decryption mock
    Mockito.when(kmsClient.decrypt(ArgumentMatchers.any(DecryptRequest.class)))
        .thenReturn(
            DecryptResponse.builder()
                .plaintext(SdkBytes.fromString("invalid JSON", Charsets.UTF_8))
                .build());

    // Make sure we throw a rejection
    assertThrows(
        AmqpRejectAndDontRequeueException.class,
        () -> messageConsumer.onMessage(new Message(new byte[] {})));
  }

  @Test
  void onMessage_external_doesntCallNonMatchingConsumers() throws IOException {

    // Set up the decrypt response
    File event = new File("src/test/resources/data/dto/PrinterRegistrationEvent.json");
    DecryptResponse response =
        DecryptResponse.builder()
            .plaintext(SdkBytes.fromByteArray(Files.readAllBytes(event.toPath())))
            .build();

    // Set up the decryption mock
    Mockito.when(kmsClient.decrypt(ArgumentMatchers.any(DecryptRequest.class)))
        .thenReturn(response);

    // Set up the consumer mock
    Mockito.when(mockExternalConsumer.eventResource())
        .thenReturn(ExternalEventResource.PENDING_ASSOCIATION);
    Mockito.when(mockExternalConsumer.eventType()).thenReturn(ExternalEventType.ADDED);

    messageConsumer.onMessage(new Message(new byte[] {}));

    Mockito.verify(mockExternalConsumer, Mockito.times(0)).handleEvent(ArgumentMatchers.any());
  }

  @Test
  void onMessage_external_callsTheMatchingConsumer() throws IOException {

    // Set up the decrypt response
    File event = new File("src/test/resources/data/dto/PrinterRegistrationEvent.json");
    DecryptResponse response =
        DecryptResponse.builder()
            .plaintext(SdkBytes.fromByteArray(Files.readAllBytes(event.toPath())))
            .build();

    // Set up the decryption mock
    Mockito.when(kmsClient.decrypt(ArgumentMatchers.any(DecryptRequest.class)))
        .thenReturn(response);

    // Set up the consumer mock
    Mockito.when(mockExternalConsumer.eventResource())
        .thenReturn(ExternalEventResource.PRINTER_REGISTRATION);
    Mockito.when(mockExternalConsumer.eventType()).thenReturn(ExternalEventType.ADDED);

    messageConsumer.onMessage(new Message(new byte[] {}));

    Mockito.verify(mockExternalConsumer, Mockito.times(1)).handleEvent(ArgumentMatchers.any());
  }
}
