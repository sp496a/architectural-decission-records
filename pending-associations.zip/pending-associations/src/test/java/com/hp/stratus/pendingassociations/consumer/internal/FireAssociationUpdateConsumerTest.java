package com.hp.stratus.pendingassociations.consumer.internal;

import com.hp.stratus.pendingassociations.dto.event.internal.InternalEvent;
import com.hp.stratus.pendingassociations.dto.event.internal.InternalEventType;
import com.hp.stratus.pendingassociations.exceptions.BadRequestException;
import com.hp.stratus.pendingassociations.service.AssociationService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
public class FireAssociationUpdateConsumerTest {

  @Mock AssociationService associationService;
  private FireAssociationUpdateConsumer consumer;

  @BeforeEach
  void setup() {
    consumer = new FireAssociationUpdateConsumer(associationService);
  }

  @Test
  void eventType_returnsPublishFireAssociationUpdate() {
    Assertions.assertEquals(
        consumer.eventType(), InternalEventType.PUBLISH_FIRE_ASSOCIATION_UPDATE);
  }

  @Test
  void handleEvent_callsTheAssociationService() {
    InternalEvent event =
        new InternalEvent(InternalEventType.PUBLISH_FIRE_ASSOCIATION_UPDATE, UUID.randomUUID());
    consumer.handleEvent(event);

    verify(associationService, times(1)).fireAssociationUpdate(eq(event.getAssociation()));
  }

  @Test
  void handleEvent_BadExceptionTest() {
    InternalEvent event = new InternalEvent(InternalEventType.PUBLISH_FIRE_ASSOCIATION_UPDATE, UUID.randomUUID());
    doThrow(new BadRequestException()).when(associationService).fireAssociationUpdate(any());

    assertThrows(
        AmqpRejectAndDontRequeueException.class,
        () ->  consumer.handleEvent(event));

    verify(associationService, times(1)).fireAssociationUpdate(eq(event.getAssociation()));
  }
}
