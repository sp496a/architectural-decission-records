package com.hp.stratus.auth;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.auth.exception.SecurityFilterExceptionHandler;
import com.hp.stratus.pendingassociations.repository.impl.ActionRepositoryImpl;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.io.IOException;

import static org.mockito.Mockito.*;

@Tag("UnitTest")
@Tag("ComponentTest")
@ExtendWith(MockitoExtension.class)
public class SecurityExceptionHanderTest {

  private SecurityFilterExceptionHandler exceptionHandler;
  private HttpServletRequest request;
  private HttpServletResponse response;

  private AccessDeniedException accessDeniedException;

  @Mock ObjectMapper mockObjectMapper;

  @InjectMocks
  SecurityFilterExceptionHandler exceptionHandler1;

  @BeforeEach
  void setUp() throws IOException {
    request = new MockHttpServletRequest();
    response = new MockHttpServletResponse();
    accessDeniedException = new AccessDeniedException("access denied");
    exceptionHandler = new SecurityFilterExceptionHandler();
  }

  @AfterEach
  void tearDown() throws IOException {
    SecurityContextHolder.clearContext();
  }

  @Test
  void accessDeniedExceptionTest() throws Exception {
    // Setup the test
    Authentication authentication = Mockito.mock(Authentication.class);
    when(authentication.isAuthenticated()).thenReturn(false);

    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);

    // Run the test
    exceptionHandler.handle(request, response, accessDeniedException);

    // Verify the test
    verify(securityContext, times(1)).getAuthentication();
  }

  @Test
  void notAuthenticatedCaseTest() throws Exception {

    Authentication authentication = Mockito.mock(Authentication.class);
    when(authentication.isAuthenticated()).thenReturn(true);

    // Mockito.whens() for your authorization object
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);

    // Run the test
    exceptionHandler.handle(request, response, accessDeniedException);

    // Verify the test
    verify(securityContext, times(1)).getAuthentication();
  }

  @Test
  void notAuthenticatedCaseTest_JsonProcessingException() throws Exception {

    Authentication authentication = Mockito.mock(Authentication.class);
    when(authentication.isAuthenticated()).thenReturn(true);

    // Mockito.whens() for your authorization object
    SecurityContext securityContext = Mockito.mock(SecurityContext.class);
    when(securityContext.getAuthentication()).thenReturn(authentication);
    SecurityContextHolder.setContext(securityContext);
    when(mockObjectMapper.writeValueAsString(any(Object.class)))
        .thenThrow(mock(JsonProcessingException.class));
    // Run the test
    exceptionHandler1.handle(request, response, accessDeniedException);

    // Verify the test
    verify(securityContext, times(1)).getAuthentication();
  }

}
