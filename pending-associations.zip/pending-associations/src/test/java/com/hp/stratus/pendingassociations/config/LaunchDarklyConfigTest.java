package com.hp.stratus.pendingassociations.config;

import com.hp.stratus.pendingassociations.service.EventService;
import com.launchdarkly.sdk.server.LDClient;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.mock.mockito.MockBean;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
public class LaunchDarklyConfigTest {

  @MockBean EventService eventService;

  private LaunchDarklyConfig launchDarklyConfig = new LaunchDarklyConfig("test");

  @Test
  void getLDClientConfig_successTest() {
    LDClient ldClient = launchDarklyConfig.getLaunchdarklyClient();

    assertNotNull(ldClient);
  }

  @Test
  void getLDClientConfig_Close_successTest() throws Exception {
    LDClient ldClient = launchDarklyConfig.getLaunchdarklyClient();

    launchDarklyConfig.destroy();

    assertFalse(ldClient.isInitialized());
  }
}
