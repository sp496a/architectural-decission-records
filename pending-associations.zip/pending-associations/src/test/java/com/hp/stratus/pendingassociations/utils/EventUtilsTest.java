package com.hp.stratus.pendingassociations.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventAttribute;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventEnvelope;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import javax.json.JsonString;
import javax.json.JsonStructure;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@Tag("UnitTest")
public class EventUtilsTest {

  private static final ObjectMapper objectMapper = new ObjectMapper();

  @Test
  void getEventObjectAttribute_returnsTheAttribute() {
    StratusEventEnvelope envelope = new StratusEventEnvelope();
    envelope.setEventAttributeValueMap(Map.of("eventObject", new StratusEventAttribute()));

    assertEquals(
        EventUtils.getEventObjectAttribute(envelope),
        envelope.getEventAttributeValueMap().get("eventObject"));
  }

  @Test
  void getEventAttribute_returnsTheAttribute() {
    StratusEventEnvelope envelope = new StratusEventEnvelope();
    envelope.setEventAttributeValueMap(Map.of("test", new StratusEventAttribute()));

    assertEquals(
        EventUtils.getEventAttribute(envelope, "test"),
        envelope.getEventAttributeValueMap().get("test"));
  }

  @Test
  void getEventDetailStructure_returnsNullWithoutAStringValue() {
    StratusEventAttribute attribute = new StratusEventAttribute();

    assertNull(EventUtils.getEventDetailStructure(attribute));
  }

  @Test
  void getEventDetailStructure_returnsNullIfJSONParsingFails() {
    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setStringValue("invalidJSON");

    assertNull(EventUtils.getEventDetailStructure(attribute));
  }

  @Test
  void getEventDetailStructure_parsesValidJSON() {
    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setStringValue("{\"valid\":\"json\"}");

    JsonStructure result = EventUtils.getEventDetailStructure(attribute);

    assertNotNull(result);
    assertEquals(result.getValue("/valid").toString(), "\"json\"");
  }

  @Test
  void getEventDetailMap_returnsNullWithoutAStringValue() {
    StratusEventAttribute attribute = new StratusEventAttribute();

    assertNull(EventUtils.getEventDetailMap(objectMapper, attribute));
  }

  @Test
  void getEventDetailMap_returnsNullIfJSONParsingFails() {
    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setStringValue("invalidJSON");

    assertNull(EventUtils.getEventDetailMap(objectMapper, attribute));
  }

  @Test
  void getEventDetailMap_parsesValidJSON() {
    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setStringValue("{\"valid\":\"json\"}");

    Map<String, Object> result = EventUtils.getEventDetailMap(objectMapper, attribute);

    assertNotNull(result);
    assertEquals(result.get("valid"), "json");
  }

  @Test
  void getEventAttribute_returnsNull() {
    StratusEventEnvelope envelope = new StratusEventEnvelope();
    assertNull(EventUtils.getEventAttribute(envelope, "test"));
  }

  @Test
  void getEventAttributeMap_mapsJsonFields() {
    StratusEventEnvelope envelope = new StratusEventEnvelope();
    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setStringValue("{\"valid\":\"json\"}");
    envelope.setEventAttributeValueMap(Map.of("test", attribute));

    Map<String, Object> resultingMap = EventUtils.getEventAttributeMap(objectMapper, envelope);

    assertNotNull(resultingMap);
    assertEquals(resultingMap.get("test"), Map.of("valid", "json"));
  }

  @Test
  void getEventAttributeMap_handlesNullValues() {
    StratusEventEnvelope envelope = new StratusEventEnvelope();
    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setStringValue(null);
    envelope.setEventAttributeValueMap(Map.of("test", attribute));

    Map<String, Object> resultingMap = EventUtils.getEventAttributeMap(objectMapper, envelope);

    assertNotNull(resultingMap);
    assertNull(resultingMap.get("test"));
  }

  @Test
  void parseEventAttribute_returnsNullIfNoStringIsPresent() {
    StratusEventAttribute attribute = new StratusEventAttribute();
    assertNull(EventUtils.parseEventAttribute(objectMapper, attribute));
  }

  @Test
  void parseEventAttribute_returnsAMapIfAnObjectIsPresent() {
    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setStringValue("{\"valid\":\"json\"}");

    Object result = EventUtils.parseEventAttribute(objectMapper, attribute);

    assertNotNull(result);
    assertTrue(result instanceof Map);
    assertEquals("json", ((Map<String, Object>) result).get("valid"));
  }

  @Test
  void parseEventAttribute_returnsAListIfAnArrayIsPresent() {
    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setStringValue("[\"valid\"]");

    Object result = EventUtils.parseEventAttribute(objectMapper, attribute);

    assertNotNull(result);
    assertTrue(result instanceof List);
    assertEquals("valid", ((List<Object>) result).get(0));
  }

  @Test
  void parseEventAttribute_returnsAStringIfAStringIsPresent() {
    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setStringValue("valid");

    Object result = EventUtils.parseEventAttribute(objectMapper, attribute);

    assertNotNull(result);
    assertTrue(result instanceof String);
    assertEquals("valid", result);
  }

  @Test
  void convertToJsonStructure_convertsToAStructure() {
    Map<String, Object> map = Map.of("test", "value");

    JsonStructure result = EventUtils.convertToJsonStructure(objectMapper, map);

    assertNotNull(result);
    assertEquals("value", ((JsonString) result.getValue("/test")).getString());
  }
}
