package com.hp.stratus.pendingassociations.exceptions;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;

import org.junit.jupiter.api.Test;

class BadGatewayExceptionTest {

  @Test
  void testConstructor() {
    BadGatewayException actualBadGatewayException = new BadGatewayException();
    assertNull(actualBadGatewayException.getCause());
    assertEquals("com.hp.stratus.pendingassociations.exceptions.BadGatewayException",
        actualBadGatewayException.toString());
    assertEquals(0, actualBadGatewayException.getSuppressed().length);
    assertNull(actualBadGatewayException.getMessage());
    assertNull(actualBadGatewayException.getLocalizedMessage());
  }

  @Test
  void testConstructor2() {
    BadGatewayException actualBadGatewayException = new BadGatewayException("An error occurred");
    assertNull(actualBadGatewayException.getCause());
    assertEquals(
        "com.hp.stratus.pendingassociations.exceptions.BadGatewayException: An error occurred",
        actualBadGatewayException.toString());
    assertEquals(0, actualBadGatewayException.getSuppressed().length);
    assertEquals("An error occurred", actualBadGatewayException.getMessage());
    assertEquals("An error occurred", actualBadGatewayException.getLocalizedMessage());
  }

  @Test
  void testConstructor3() {
    Throwable throwable = new Throwable();
    BadGatewayException actualBadGatewayException = new BadGatewayException("An error occurred",
        throwable);

    Throwable cause = actualBadGatewayException.getCause();
    assertSame(throwable, cause);
    assertEquals(
        "com.hp.stratus.pendingassociations.exceptions.BadGatewayException: An error occurred",
        actualBadGatewayException.toString());
    assertEquals("An error occurred", actualBadGatewayException.getLocalizedMessage());
    Throwable[] suppressed = actualBadGatewayException.getSuppressed();
    assertEquals(0, suppressed.length);
    assertEquals("An error occurred", actualBadGatewayException.getMessage());
    assertNull(cause.getLocalizedMessage());
    assertNull(cause.getCause());
    assertEquals("java.lang.Throwable", cause.toString());
    assertNull(cause.getMessage());
    assertSame(suppressed, cause.getSuppressed());
    assertSame(cause, throwable);
  }
}

