package com.hp.stratus.pendingassociations.service;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.http.client.utils.HttpClient;
import com.hp.stratus.pendingassociations.auth.Scope;
import com.hp.stratus.pendingassociations.config.JacksonConfig;
import com.hp.stratus.pendingassociations.dto.client.EventRegistrationRequest;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventAttribute;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventEnvelope;
import com.hp.stratus.pendingassociations.dto.event.internal.InternalEvent;
import com.hp.stratus.pendingassociations.dto.event.internal.InternalEventType;
import com.hp.stratus.pendingassociations.exceptions.BadGatewayException;
import com.hp.stratus.pendingassociations.exceptions.BadRequestException;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.service.impl.EventServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.core.MessagePropertiesBuilder;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
public class EventServiceImplTest {

  private static final String exchange = "internalExchange";

  @Mock HttpClient httpClient;
  @Mock Supplier<String> jwtSupplier;
  @Mock RabbitTemplate rabbitTemplate;
  @Mock ObjectMapper mockObjectMapper;

  private final ObjectMapper objectMapper = new JacksonConfig().objectMapper();

  private EventServiceImpl eventService;
  private EventServiceImpl eventService1;

  @BeforeEach
  void setup() {
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    eventService =
        new EventServiceImpl(
            objectMapper,
            httpClient,
            rabbitTemplate,
            jwtSupplier,
            "test",
            "http://localhost/",
            "v1/subscribe",
            "v1/publish",
            "topic",
            exchange);

    eventService1 =
        new EventServiceImpl(
            mockObjectMapper,
            httpClient,
            rabbitTemplate,
            jwtSupplier,
            "test",
            "http://localhost/",
            "v1/subscribe",
            "v1/publish",
            "topic",
            exchange);
  }

  @Test
  void subscribeToResource_postsSubscriptionRequest() {
    when(jwtSupplier.get()).thenReturn("jwt");
    when(httpClient.post(any(), any(), anyMap(), any(), any()))
        .thenReturn(new ResponseEntity<>(HttpStatus.OK));

    eventService.subscribeToResource(ExternalEventResource.PRINTER_REGISTRATION);

    verify(httpClient, times(1))
        .post(
            eq("http://localhost/v1/subscribe"),
            eq("jwt"),
            eq(Map.of(HttpHeaders.USER_AGENT, "test")),
            eq(
                EventRegistrationRequest.builder()
                    .protocol("AWSSNS")
                    .topicResourceName("topic")
                    .externalEventResource(ExternalEventResource.PRINTER_REGISTRATION)
                    .build()),
            any());
  }

  @Test
  void registerSubscriptions_doesntThrowOnSubscribeError() {
    when(jwtSupplier.get()).thenReturn("jwt");
    when(httpClient.post(any(), any(), anyMap(), any(), any()))
        .thenReturn(new ResponseEntity<>(HttpStatus.BAD_REQUEST));

    eventService.subscribeToResource(ExternalEventResource.PRINTER_REGISTRATION);

    verify(httpClient, times(1))
        .post(
            eq("http://localhost/v1/subscribe"),
            eq("jwt"),
            eq(Map.of(HttpHeaders.USER_AGENT, "test")),
            eq(
                EventRegistrationRequest.builder()
                    .protocol("AWSSNS")
                    .topicResourceName("topic")
                    .externalEventResource(ExternalEventResource.PRINTER_REGISTRATION)
                    .build()),
            any());
  }

  @Test
  void publishAssociationUpdate_callsEventManagementWithCorrectParameters()
      throws JsonProcessingException {
    when(jwtSupplier.get()).thenReturn("jwt");
    when(httpClient.post(any(), any(), any(), any()))
        .thenReturn(new ResponseEntity<>(HttpStatus.OK));

    Association association = new Association();
    association.setId(UUID.randomUUID());
    association.setTenantId("tenantId");

    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setDataType("String");
    attribute.setStringValue(objectMapper.writeValueAsString(association));

    eventService.publishAssociationUpdate(association);

    verify(httpClient, times(1))
        .post(
            eq("http://localhost/v1/publish"),
            eq("jwt"),
            eq(
                StratusEventEnvelope.builder()
                    .event(ExternalEventType.UPDATED)
                    .fqResourceName(ExternalEventResource.PENDING_ASSOCIATION)
                    .resourceId(association.getId().toString())
                    .tenantResourceId(association.getTenantId())
                    .scopes(List.of(Scope.READ.toString()))
                    .resource(ExternalEventResource.PENDING_ASSOCIATION.toString())
                    .eventAttributeValueMap(Map.of("eventObject", attribute))
                    .build()),
            any());
  }

  @Test
  void publishAssociationUpdate_throwsBadRequestExceptionOnClientErrors()
      throws JsonProcessingException {
    Association association = new Association();
    association.setId(UUID.randomUUID());
    association.setTenantId("tenantId");
    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setDataType("String");
    attribute.setStringValue(objectMapper.writeValueAsString(association));
    when(jwtSupplier.get()).thenReturn("jwt");
    when(httpClient.post(any(), any(), any(), any()))
        .thenThrow(new HttpClientErrorException(HttpStatus.OK));

    assertThrows(
        BadRequestException.class, () -> eventService.publishAssociationUpdate(association));
  }

  @Test
  void publishAssociationUpdate_throwsBadGatewayExceptionOnServerErrors()
      throws JsonProcessingException {
    Association association = new Association();
    association.setId(UUID.randomUUID());
    association.setTenantId("tenantId");
    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setDataType("String");
    attribute.setStringValue(objectMapper.writeValueAsString(association));
    when(jwtSupplier.get()).thenReturn("jwt");
    when(httpClient.post(any(), any(), any(), any()))
        .thenThrow(new HttpServerErrorException(HttpStatus.BAD_GATEWAY));

    assertThrows(
        BadGatewayException.class, () -> eventService.publishAssociationUpdate(association));
  }

  @Test
  void publishAssociationUpdate_throwsBadGatewayExceptionOnNetworkErrors()
      throws JsonProcessingException {
    Association association = new Association();
    association.setId(UUID.randomUUID());
    association.setTenantId("tenantId");
    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setDataType("String");
    attribute.setStringValue(objectMapper.writeValueAsString(association));
    when(jwtSupplier.get()).thenReturn("jwt");
    when(httpClient.post(any(), any(), any(), any())).thenThrow(new RuntimeException());

    assertThrows(
        BadGatewayException.class, () -> eventService.publishAssociationUpdate(association));
  }

  @Test
  void publishAssociationUpdate_JsonProcessErrorWithSuccess() throws JsonProcessingException {
    when(jwtSupplier.get()).thenReturn("jwt");
    when(httpClient.post(any(), any(), any(), any()))
        .thenReturn(new ResponseEntity<>(HttpStatus.OK));

    Association association = new Association();
    association.setId(UUID.randomUUID());
    association.setTenantId("tenantId");

    when(mockObjectMapper.writeValueAsString(any(Object.class)))
        .thenThrow(mock(JsonProcessingException.class));

    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setDataType("String");

    eventService1.publishAssociationUpdate(association);

    verify(httpClient, times(1))
        .post(
            eq("http://localhost/v1/publish"),
            eq("jwt"),
            eq(
                StratusEventEnvelope.builder()
                    .event(ExternalEventType.UPDATED)
                    .fqResourceName(ExternalEventResource.PENDING_ASSOCIATION)
                    .resourceId(association.getId().toString())
                    .tenantResourceId(association.getTenantId())
                    .scopes(List.of(Scope.READ.toString()))
                    .resource(ExternalEventResource.PENDING_ASSOCIATION.toString())
                    .eventAttributeValueMap(Map.of("eventObject", attribute))
                    .build()),
            any());
  }

  @Test
  void publishCriteriaResolved_publishesTheEvent() throws JsonProcessingException {
    UUID associationId = UUID.randomUUID();
    Message msg =
        MessageBuilder.withBody(
                objectMapper.writeValueAsBytes(
                    InternalEvent.builder()
                        .type(InternalEventType.CRITERIA_RESOLVED)
                        .association(associationId)
                        .build()))
            .andProperties(
                MessagePropertiesBuilder.newInstance()
                    .setAppId(InternalEvent.INTERNAL_EVENT_APP_ID)
                    .build())
            .build();

    eventService.publishCriteriaResolved(associationId);

    verify(rabbitTemplate, times(1)).send(eq(exchange), eq(""), eq(msg));
  }

  @Test
  void publishExecuteNextAction_publishesTheEvent() throws JsonProcessingException {
    UUID associationId = UUID.randomUUID();
    Message msg =
        MessageBuilder.withBody(
                objectMapper.writeValueAsBytes(
                    InternalEvent.builder()
                        .type(InternalEventType.EXECUTE_NEXT_ACTION)
                        .association(associationId)
                        .build()))
            .andProperties(
                MessagePropertiesBuilder.newInstance()
                    .setAppId(InternalEvent.INTERNAL_EVENT_APP_ID)
                    .build())
            .build();

    eventService.publishExecuteNextAction(associationId);

    verify(rabbitTemplate, times(1)).send(eq(exchange), eq(""), eq(msg));
  }

  @Test
  void publishCriteriaResolved_JsonProcessError() throws JsonProcessingException {
    UUID associationId = UUID.randomUUID();
    when(mockObjectMapper.writeValueAsBytes(any(Object.class)))
        .thenThrow(mock(JsonProcessingException.class));

    Message msg =
        MessageBuilder.withBody(
            objectMapper.writeValueAsBytes(
                InternalEvent.builder()
                    .type(InternalEventType.CRITERIA_RESOLVED)
                    .association(associationId)
                    .build()))
            .andProperties(
                MessagePropertiesBuilder.newInstance()
                    .setAppId(InternalEvent.INTERNAL_EVENT_APP_ID)
                    .build())
            .build();

    eventService1.publishCriteriaResolved(associationId);

    verify(rabbitTemplate, times(0)).send(eq(exchange), eq(""), eq(msg));
  }

  @Test
  void publishFireAssociationUpdate_test() throws JsonProcessingException {
    UUID associationId = UUID.randomUUID();
    Message msg =
        MessageBuilder.withBody(
            objectMapper.writeValueAsBytes(
                InternalEvent.builder()
                    .type(InternalEventType.PUBLISH_FIRE_ASSOCIATION_UPDATE)
                    .association(associationId)
                    .build()))
            .andProperties(
                MessagePropertiesBuilder.newInstance()
                    .setAppId(InternalEvent.INTERNAL_EVENT_APP_ID)
                    .build())
            .build();

    eventService.publishFireAssociationUpdate(associationId);

    verify(rabbitTemplate, times(1)).send(eq(exchange), eq(""), eq(msg));
  }

  @Test
  void publishAssociationUpdate_throwException() throws JsonProcessingException {
    when(jwtSupplier.get()).thenReturn("jwt");
    when(httpClient.post(any(), any(), any(), any())).thenThrow(new RuntimeException());

    Association association = new Association();
    association.setId(UUID.randomUUID());
    association.setTenantId("tenantId");

    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setDataType("String");
    attribute.setStringValue(objectMapper.writeValueAsString(association));

    // Run and Verify the test
    assertThrows(
        BadGatewayException.class,
        () -> eventService.publishAssociationUpdate(association));
  }

  @Test
  void publishAssociationUpdate_throwException1() throws JsonProcessingException {
    when(jwtSupplier.get()).thenReturn("jwt");
    when(httpClient.post(any(), any(), any(), any())).thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST));
    Association association = new Association();
    association.setId(UUID.randomUUID());
    association.setTenantId("tenantId");

    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setDataType("String");
    attribute.setStringValue(objectMapper.writeValueAsString(association));

    // Run and Verify the test
    assertThrows(
        BadRequestException.class,
        () -> eventService.publishAssociationUpdate(association));
  }

}
