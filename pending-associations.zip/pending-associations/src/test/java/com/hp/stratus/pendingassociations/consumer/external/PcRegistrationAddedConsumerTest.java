package com.hp.stratus.pendingassociations.consumer.external;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.config.JacksonConfig;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventAttribute;
import com.hp.stratus.pendingassociations.dto.event.external.StratusEventEnvelope;
import com.hp.stratus.pendingassociations.service.CriteriaService;
import com.hp.stratus.pendingassociations.service.EventService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;

import javax.json.JsonStructure;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
public class PcRegistrationAddedConsumerTest {
  @Mock CriteriaService criteriaService;
  @Mock EventService eventService;

  private final ObjectMapper mapper = new JacksonConfig().objectMapper();

  private PcRegistrationAddedConsumer consumer;

  @BeforeEach
  void setup() {
    consumer = new PcRegistrationAddedConsumer(criteriaService, eventService, mapper);
  }

  @Test
  void eventResource_returnsPCRegistrationResource() {
    Assertions.assertEquals(consumer.eventResource(), ExternalEventResource.PC_REGISTRATION);
  }

  @Test
  void eventType_returnsAddedType() {
    Assertions.assertEquals(consumer.eventType(), ExternalEventType.ADDED);
  }

  @Test
  void subscribeToResource_callsEventService() {
    consumer.subscribeToResource();

    verify(eventService, times(1)).subscribeToResource(eq(ExternalEventResource.PC_REGISTRATION));
  }

  @Test
  void handleEvent_deadLettersWhenNoEventObjectIsSupplied() {
    assertThrows(
        AmqpRejectAndDontRequeueException.class,
        () ->
            consumer.handleEvent(
                StratusEventEnvelope.builder().eventAttributeValueMap(new HashMap<>()).build()));
  }

  @Test
  void handleEvent_deadLettersWhenEventDetailsCantBeParsed() {
    Map<String, StratusEventAttribute> attributeMap = new HashMap<>();
    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setStringValue("invalid JSON");
    attributeMap.put("eventObject", attribute);

    assertThrows(
        AmqpRejectAndDontRequeueException.class,
        () ->
            consumer.handleEvent(
                StratusEventEnvelope.builder().eventAttributeValueMap(attributeMap).build()));
  }

  @Test
  void handleEvent_deadLettersWhenEventDetailsAreNotAMap() {
    Map<String, StratusEventAttribute> attributeMap = new HashMap<>();
    StratusEventAttribute attribute = new StratusEventAttribute();
    attribute.setStringValue("[\"a\", \"b\", \"c\"]");
    attributeMap.put("eventObject", attribute);

    assertThrows(
        AmqpRejectAndDontRequeueException.class,
        () ->
            consumer.handleEvent(
                StratusEventEnvelope.builder().eventAttributeValueMap(attributeMap).build()));
  }

  @Test
  void handleEvent_callsTheCriteriaService() throws IOException {
    File event = new File("src/test/resources/data/dto/PcRegistrationEvent.json");
    StratusEventEnvelope envelope =
        mapper.readValue(Files.readAllBytes(event.toPath()), StratusEventEnvelope.class);

    consumer.handleEvent(envelope);

    verify(criteriaService, times(1))
        .resolveEventBasedCriteria(
            eq(ExternalEventResource.PC_REGISTRATION),
            eq(ExternalEventType.ADDED),
            any(JsonStructure.class),
            anyMap());
  }
}
