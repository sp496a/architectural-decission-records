package com.hp.stratus.pendingassociations.action.associate;

import com.hp.stratus.pendingassociations.exceptions.ResourceResolutionException;
import com.hp.stratus.pendingassociations.model.*;
import org.apache.commons.lang3.NotImplementedException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
class AssociateExecutorTest {

  @Mock AssociatePcExecutor pcExecutor;
  private AssociateExecutor executor;

  @BeforeEach
  void setup() {
    executor = new AssociateExecutor(List.of(pcExecutor));
  }

  @Test
  void getOperation() {

    // run test
    Operation operationResult = executor.getOperation();

    // verify result
    assertEquals(Operation.ASSOCIATE, operationResult);
  }

  @Test
  void execute_actionResourceIsNull() {

    // Setup testdata
    List<AssociateResourceExecutor> resourceExecutors = new ArrayList<>();
    executor = new AssociateExecutor(resourceExecutors);
    Action action = new Action();
    Association association = new Association();

    // Run test and verify result
    assertThrows(ResourceResolutionException.class, () -> executor.execute(association, action, 0));
  }

  @Test
  void execute_resourceTypeExecuteCalled() {
    Association association = new Association();
    Action action = new Action();
    Resource resource = new Resource();
    resource.setType(ResourceType.PC);
    action.setResource(resource);
    when(pcExecutor.getResourceType()).thenReturn(ResourceType.PC);

    executor.execute(association, action, 1);

    verify(pcExecutor, times(1)).execute(resource, association, 1);
  }

  @Test
  void execute_actionResourceNotImplemented() {
    Association association = new Association();
    Action action = new Action();
    Resource resource = new Resource();
    resource.setType(ResourceType.PRINTER);
    action.setResource(resource);
    when(pcExecutor.getResourceType()).thenReturn(ResourceType.PC);

    assertThrows(NotImplementedException.class, () -> executor.execute(association, action, 1));
  }
}
