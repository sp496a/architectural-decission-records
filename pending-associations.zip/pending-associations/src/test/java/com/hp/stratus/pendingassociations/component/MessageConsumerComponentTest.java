package com.hp.stratus.pendingassociations.component;

import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.action.associate.AssociatePcExecutor;
import com.hp.stratus.pendingassociations.action.associate.AssociatePrinterExecutor;
import com.hp.stratus.pendingassociations.config.JacksonConfig;
import com.hp.stratus.pendingassociations.consumer.MessageConsumer;
import com.hp.stratus.pendingassociations.consumer.external.ExternalEventConsumer;
import com.hp.stratus.pendingassociations.consumer.external.PcClaimAddedConsumer;
import com.hp.stratus.pendingassociations.consumer.external.PcRegistrationAddedConsumer;
import com.hp.stratus.pendingassociations.consumer.external.PrinterClaimAddedConsumer;
import com.hp.stratus.pendingassociations.consumer.external.PrinterRegistrationAddedConsumer;
import com.hp.stratus.pendingassociations.consumer.internal.CriteriaResolvedConsumer;
import com.hp.stratus.pendingassociations.consumer.internal.ExecuteNextActionConsumer;
import com.hp.stratus.pendingassociations.consumer.internal.FireAssociationUpdateConsumer;
import com.hp.stratus.pendingassociations.consumer.internal.InternalEventConsumer;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventResource;
import com.hp.stratus.pendingassociations.dto.event.external.ExternalEventType;
import com.hp.stratus.pendingassociations.dto.event.internal.InternalEvent;
import com.hp.stratus.pendingassociations.exceptions.BadRequestException;
import com.hp.stratus.pendingassociations.service.ActionService;
import com.hp.stratus.pendingassociations.service.AssociationService;
import com.hp.stratus.pendingassociations.service.CriteriaService;
import com.hp.stratus.pendingassociations.service.EventService;
import com.launchdarkly.shaded.kotlin.text.Charsets;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.json.JsonStructure;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import software.amazon.awssdk.core.SdkBytes;
import software.amazon.awssdk.services.kms.KmsClient;
import software.amazon.awssdk.services.kms.model.DecryptRequest;
import software.amazon.awssdk.services.kms.model.DecryptResponse;

@ExtendWith(MockitoExtension.class)
@Tag("ComponentTest")
public class MessageConsumerComponentTest {

  private final ObjectMapper objectMapper = new JacksonConfig().objectMapper();
  @Mock
  private KmsClient kmsClient;
  @Mock
  private ActionService actionService;
  @Mock
  private AssociationService associationService;
  @Mock
  private AssociatePcExecutor associatePcExecutor;
  @Mock
  private EventService eventService;
  @Mock
  private CriteriaService criteriaService;
  @Mock
  private AssociatePrinterExecutor associatePrinterExecutor;

  // Internal consumer
  private CriteriaResolvedConsumer criteriaResolvedConsumer;
  private FireAssociationUpdateConsumer fireAssociationUpdateConsumer;
  private ExecuteNextActionConsumer executeNextActionConsumer;

  // External consumer
  private PcClaimAddedConsumer pcClaimAddedConsumer;
  private PcRegistrationAddedConsumer pcRegistrationAddedConsumer;
  private PrinterClaimAddedConsumer printerClaimAddedConsumer;
  private PrinterRegistrationAddedConsumer printerRegistrationAddedConsumer;

  private MessageConsumer messageConsumer;

  @BeforeEach
  void setup() {

    List<InternalEventConsumer> internalEventConsumers = new ArrayList<>();

    criteriaResolvedConsumer = new CriteriaResolvedConsumer(actionService);
    fireAssociationUpdateConsumer = new FireAssociationUpdateConsumer(associationService);
    executeNextActionConsumer = new ExecuteNextActionConsumer(actionService);
    internalEventConsumers.add(criteriaResolvedConsumer);
    internalEventConsumers.add(fireAssociationUpdateConsumer);
    internalEventConsumers.add(executeNextActionConsumer);

    List<ExternalEventConsumer> externalEventConsumers = new ArrayList<>();

    pcClaimAddedConsumer = new PcClaimAddedConsumer(associatePcExecutor, eventService,
        objectMapper);
    pcRegistrationAddedConsumer = new PcRegistrationAddedConsumer(criteriaService, eventService,
        objectMapper);
    printerClaimAddedConsumer = new PrinterClaimAddedConsumer(associatePrinterExecutor,
        eventService, objectMapper);
    printerRegistrationAddedConsumer = new PrinterRegistrationAddedConsumer(criteriaService,
        eventService, objectMapper);
    externalEventConsumers.add(pcClaimAddedConsumer);
    externalEventConsumers.add(pcRegistrationAddedConsumer);
    externalEventConsumers.add(printerClaimAddedConsumer);
    externalEventConsumers.add(printerRegistrationAddedConsumer);

    messageConsumer =
        new MessageConsumer(
            new JacksonConfig().objectMapper(),
            externalEventConsumers,
            internalEventConsumers,
            kmsClient);
  }

  @Test
  void onMessage_internal_CRITERIA_RESOLVED_Consumer_Success() {

    // Set up the consumer and message
    byte[] msgBytes =
        ("{\"type\": \"CRITERIA_RESOLVED\", \"association\":\"" + UUID.randomUUID() + "\"}")
            .getBytes(StandardCharsets.UTF_8);
    MessageProperties msgProperties = new MessageProperties();
    msgProperties.setAppId(InternalEvent.INTERNAL_EVENT_APP_ID);

    doNothing().when(actionService).beginExecution(any());
    // Fire the event
    messageConsumer.onMessage(new Message(msgBytes, msgProperties));
    // Verify the test
    Mockito.verify(actionService, Mockito.times(1)).beginExecution(any());
  }

  @Test
  void onMessage_internal_PUBLISH_FIRE_ASSOCIATION_UPDATE_Consumer_Success() {

    // Set up the consumer and message
    byte[] msgBytes =
        ("{\"type\": \"PUBLISH_FIRE_ASSOCIATION_UPDATE\", \"association\":\"" + UUID.randomUUID()
            + "\"}")
            .getBytes(StandardCharsets.UTF_8);
    MessageProperties msgProperties = new MessageProperties();
    msgProperties.setAppId(InternalEvent.INTERNAL_EVENT_APP_ID);

    doNothing().when(associationService).fireAssociationUpdate(any());
    // Fire the event
    messageConsumer.onMessage(new Message(msgBytes, msgProperties));
    // Verify the test
    Mockito.verify(associationService, Mockito.times(1)).fireAssociationUpdate(any());
  }

  @Test
  void onMessage_internal_PUBLISH_FIRE_ASSOCIATION_UPDATE_Consumer_Exception() {

    // Set up the consumer and message
    byte[] msgBytes =
        ("{\"type\": \"PUBLISH_FIRE_ASSOCIATION_UPDATE\", \"association\":\"" + UUID.randomUUID()
            + "\"}")
            .getBytes(StandardCharsets.UTF_8);
    MessageProperties msgProperties = new MessageProperties();
    msgProperties.setAppId(InternalEvent.INTERNAL_EVENT_APP_ID);
    doThrow(new BadRequestException())
        .when(associationService)
        .fireAssociationUpdate(any());

    // Fire and Verify the event
    assertThrows(
        AmqpRejectAndDontRequeueException.class,
        () ->
            messageConsumer.onMessage(new Message(msgBytes, msgProperties)));
    Mockito.verify(associationService, Mockito.times(1)).fireAssociationUpdate(any());
  }

  @Test
  void onMessage_internal_EXECUTE_NEXT_ACTION_Consumer_Success() {

    // Set up the consumer and message
    byte[] msgBytes =
        ("{\"type\": \"EXECUTE_NEXT_ACTION\", \"association\":\"" + UUID.randomUUID() + "\"}")
            .getBytes(StandardCharsets.UTF_8);
    MessageProperties msgProperties = new MessageProperties();
    msgProperties.setAppId(InternalEvent.INTERNAL_EVENT_APP_ID);

    doNothing().when(actionService).executeNextAction(any());
    // Fire the event
    messageConsumer.onMessage(new Message(msgBytes, msgProperties));
    // Verify the test
    Mockito.verify(actionService, Mockito.times(1)).executeNextAction(any());
  }


  @Test
  void onMessage_internal_throwsAmqpRejectionWhenEventJsonIsInvalid() {
    // Set up the message
    byte[] msgBytes = "invalidJson".getBytes(StandardCharsets.UTF_8);
    MessageProperties msgProperties = new MessageProperties();
    msgProperties.setAppId(InternalEvent.INTERNAL_EVENT_APP_ID);

    // Fire the event
    assertThrows(
        AmqpRejectAndDontRequeueException.class,
        () -> messageConsumer.onMessage(new Message(msgBytes, msgProperties)));
  }

  @Test
  void onMessage_internal_doesntCallNonMatchingConsumers() {

    // Set up the consumer and message
    byte[] msgBytes =
        ("{\"type\": \"NON_MATCHING_CONSUMER\", \"association\":\"" + UUID.randomUUID() + "\"}")
            .getBytes(StandardCharsets.UTF_8);
    MessageProperties msgProperties = new MessageProperties();
    msgProperties.setAppId(InternalEvent.INTERNAL_EVENT_APP_ID);

    // Fire the event
    messageConsumer.onMessage(new Message(msgBytes, msgProperties));
    // Verify the event
    Mockito.verify(actionService, Mockito.times(0)).beginExecution(any());
  }

  @Test
  void onMessage_external_throwsAmqpRejectionWhenDecryptionFails() {

    // Set up the decryption mock
    when(kmsClient.decrypt(any(DecryptRequest.class)))
        .thenThrow(new NullPointerException("whoops"));

    // Make sure we throw a rejection
    assertThrows(
        AmqpRejectAndDontRequeueException.class,
        () -> messageConsumer.onMessage(new Message(new byte[]{})));
  }

  @Test
  void onMessage_external_throwsAmqpRejectionWhenEventJsonIsInvalid() {

    // Set up the decryption mock
    when(kmsClient.decrypt(any(DecryptRequest.class)))
        .thenReturn(
            DecryptResponse.builder()
                .plaintext(SdkBytes.fromString("invalid JSON", Charsets.UTF_8))
                .build());

    // Make sure we throw a rejection
    assertThrows(
        AmqpRejectAndDontRequeueException.class,
        () -> messageConsumer.onMessage(new Message(new byte[]{})));
  }

  @Test
  void onMessage_external_doesntCallNonMatchingConsumers() throws IOException {

    // Set up the decrypt response
    File event = new File("src/test/resources/data/dto/PrinterClaimEvent.json");
    DecryptResponse response =
        DecryptResponse.builder()
            .plaintext(SdkBytes.fromByteArray(Files.readAllBytes(event.toPath())))
            .build();

    // Set up the decryption mock
    when(kmsClient.decrypt(any(DecryptRequest.class)))
        .thenReturn(response);

    // Fire and verify the event
    messageConsumer.onMessage(new Message(new byte[]{}));
    verify(associatePcExecutor, times(0)).completeClaim(eq("deviceUniqueId"), anyMap());
  }

  @Test
  void onMessage_external_PcClaimAddedConsumer_Success() throws IOException {

    // Set up the decrypt response
    File event = new File("src/test/resources/data/dto/PcClaimEvent.json");
    DecryptResponse response =
        DecryptResponse.builder()
            .plaintext(SdkBytes.fromByteArray(Files.readAllBytes(event.toPath())))
            .build();

    // Set up the decryption mock
    Mockito.when(kmsClient.decrypt(any(DecryptRequest.class)))
        .thenReturn(response);

    // Fire and verify the event
    messageConsumer.onMessage(new Message(new byte[]{}));
    verify(associatePcExecutor, Mockito.times(1)).completeClaim(eq("deviceUniqueId"), anyMap());
  }

  @Test
  void onMessage_external_PcRegistrationAddedConsumer_Success() throws IOException {

    // Set up the decrypt response
    File event = new File("src/test/resources/data/dto/PcRegistrationEvent.json");
    DecryptResponse response =
        DecryptResponse.builder()
            .plaintext(SdkBytes.fromByteArray(Files.readAllBytes(event.toPath())))
            .build();

    // Set up the decryption mock
    Mockito.when(kmsClient.decrypt(any(DecryptRequest.class)))
        .thenReturn(response);

    // Fire and verify the event
    messageConsumer.onMessage(new Message(new byte[]{}));

    verify(criteriaService, times(1))
        .resolveEventBasedCriteria(
            eq(ExternalEventResource.PC_REGISTRATION),
            eq(ExternalEventType.ADDED),
            any(JsonStructure.class),
            anyMap());
  }

  @Test
  void onMessage_external_PrinterClaimAddedConsumer_Success() throws IOException {

    // Set up the decrypt response
    File event = new File("src/test/resources/data/dto/PrinterClaimEvent.json");
    DecryptResponse response =
        DecryptResponse.builder()
            .plaintext(SdkBytes.fromByteArray(Files.readAllBytes(event.toPath())))
            .build();

    // Set up the decryption mock
    Mockito.when(kmsClient.decrypt(any(DecryptRequest.class)))
        .thenReturn(response);

    // Fire and verify the event
    messageConsumer.onMessage(new Message(new byte[]{}));
    verify(associatePrinterExecutor, times(1)).completeClaim(anyString(), anyMap());
  }

  @Test
  void onMessage_external_PrinterRegistrationAddedConsumer_Success() throws IOException {

    // Set up the decrypt response
    File event = new File("src/test/resources/data/dto/PrinterRegistrationEvent.json");
    DecryptResponse response =
        DecryptResponse.builder()
            .plaintext(SdkBytes.fromByteArray(Files.readAllBytes(event.toPath())))
            .build();

    // Set up the decryption mock
    Mockito.when(kmsClient.decrypt(any(DecryptRequest.class)))
        .thenReturn(response);

    // Fire and verify the event
    messageConsumer.onMessage(new Message(new byte[]{}));
    verify(criteriaService, times(1))
        .resolveEventBasedCriteria(
            eq(ExternalEventResource.PRINTER_REGISTRATION),
            eq(ExternalEventType.ADDED),
            any(JsonStructure.class),
            anyMap());
  }
}
