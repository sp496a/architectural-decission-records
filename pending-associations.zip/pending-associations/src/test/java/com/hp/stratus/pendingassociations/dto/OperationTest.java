package com.hp.stratus.pendingassociations.dto;

import static com.hp.stratus.pendingassociations.dto.Operation.fromValue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@Tag("UnitTest")
class OperationTest {

  @Test
  void fromValueTest() {
    Assertions.assertEquals(Operation.ASSOCIATE, fromValue("associate"));
    Assertions.assertNull(fromValue("invalidOperation"));
  }

}
