package com.hp.stratus.pendingassociations.action.associateconsent;

import com.hp.stratus.http.client.utils.HttpClient;
import com.hp.stratus.pendingassociations.dto.client.CmsConsentAssociationRequest;
import com.hp.stratus.pendingassociations.dto.client.PcManufacturingCatalogDevice;
import com.hp.stratus.pendingassociations.dto.client.PcManufacturingCatalogResponse;
import com.hp.stratus.pendingassociations.exceptions.ActionExecutionException;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.ResourceType;
import com.hp.stratus.pendingassociations.repository.ActionRepository;
import com.hp.stratus.pendingassociations.service.EventService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
class AssociateConsentPcExecutorTest {

  private AssociateConsentPcExecutor executor;

  @Mock ActionRepository actionRepository;
  @Mock EventService eventService;
  @Mock HttpClient httpClient;
  @Mock Supplier<String> jwtSupplier;

  @BeforeEach
  void setup() {
    executor =
        new AssociateConsentPcExecutor(
            actionRepository,
            eventService,
            httpClient,
            jwtSupplier,
            "stratusBase/",
            "cmsEndpoint",
            "pcManufacturingBaseUrl/",
            "DeviceEndpoint");
  }

  @Test
  void testDeviceResourceType() {

    // run test
    ResourceType resourceType = executor.getDeviceResourceType();

    // verify result
    assertEquals(ResourceType.PC, resourceType);
  }

  @Test
  void testExecuteSerialNumberNotFound() {
    // test data setup
    List<PcManufacturingCatalogDevice> devices = new ArrayList<>();
    devices.add(new PcManufacturingCatalogDevice());
    PcManufacturingCatalogResponse pcResponse = new PcManufacturingCatalogResponse();
    pcResponse.setDevices(devices);
    Association association = new Association();

    when(httpClient.get(any(), any(), any(), any())).thenThrow(new RuntimeException());

    // Run test and verify result
    assertThrows(
        ActionExecutionException.class,
        () -> executor.execute("userId", "deviceId", association, 1));
  }

  @Test
  void testCmsCallFailed() {
    // test data setup
    List<PcManufacturingCatalogDevice> devices = new ArrayList<>();
    PcManufacturingCatalogDevice device = new PcManufacturingCatalogDevice();
    device.setSerialNumber("testSerialNumber");
    devices.add(device);
    PcManufacturingCatalogResponse pcResponse = new PcManufacturingCatalogResponse();
    pcResponse.setDevices(devices);
    Association association = new Association();

    when(httpClient.get((String) any(), any(), any()))
        .thenReturn(new ResponseEntity<>(pcResponse, HttpStatus.OK));
    when(httpClient.patch(any(), any(), any(), any())).thenThrow(new RuntimeException());
    // Run test and verify result
    assertThrows(
        ActionExecutionException.class,
        () -> executor.execute("userId", "deviceId", association, 1));
  }

  @Test
  void testCmsCallSuccessForResolvedActions() {
    // test data setup
    List<PcManufacturingCatalogDevice> devices = new ArrayList<>();
    PcManufacturingCatalogDevice device = new PcManufacturingCatalogDevice();
    device.setSerialNumber("testSerialNumber");
    devices.add(device);
    PcManufacturingCatalogResponse pcResponse = new PcManufacturingCatalogResponse();
    pcResponse.setDevices(devices);
    Association association = new Association();
    association.setId(UUID.randomUUID());
    when(httpClient.get((String) any(), any(), any()))
        .thenReturn(new ResponseEntity<>(pcResponse, HttpStatus.OK));
    when(httpClient.patch(any(), any(), any(), any()))
        .thenReturn(new ResponseEntity<>(HttpStatus.OK));
    when(actionRepository.resolveAction(any(), anyInt(), any())).thenReturn(false);
    // Run test and verify result
    executor.execute("userId", "deviceId", new Association(), 1);
    verify(eventService, times(0)).publishExecuteNextAction(any());
  }

  @Test
  void testCmsCallSuccesswithNextActions() {
    // test data setup
    List<PcManufacturingCatalogDevice> devices = new ArrayList<>();
    PcManufacturingCatalogDevice device = new PcManufacturingCatalogDevice();
    device.setSerialNumber("testSerialNumber");
    devices.add(device);
    PcManufacturingCatalogResponse pcResponse = new PcManufacturingCatalogResponse();
    pcResponse.setDevices(devices);
    Association association = new Association();
    association.setId(UUID.randomUUID());
    when(httpClient.get((String) any(), any(), any()))
        .thenReturn(new ResponseEntity<>(pcResponse, HttpStatus.OK));
    when(httpClient.patch(any(), any(), any(), any()))
        .thenReturn(new ResponseEntity<>(HttpStatus.OK));
    when(actionRepository.resolveAction(any(), anyInt(), any())).thenReturn(true);
    // Run test and verify result
    executor.execute("userId", "deviceId", new Association(), 1);
    verify(eventService, times(1)).publishExecuteNextAction(any());
  }

  @Test
  void testDeviceUuidLowercasing() {

    // Prepare a PC MFG response with a device UUID in uppercase
    List<PcManufacturingCatalogDevice> devices = new ArrayList<>();
    PcManufacturingCatalogDevice device = new PcManufacturingCatalogDevice();
    device.setUuid("UPPERCASE_UUID");
    devices.add(device);
    PcManufacturingCatalogResponse pcResponse = new PcManufacturingCatalogResponse();
    pcResponse.setDevices(devices);

    // Prepare an association and mock all our API calls
    Association association = new Association();
    association.setId(UUID.randomUUID());
    when(httpClient.get((String) any(), any(), any()))
        .thenReturn(new ResponseEntity<>(pcResponse, HttpStatus.OK));
    when(httpClient.patch(any(), any(), any(), any()))
        .thenReturn(new ResponseEntity<>(HttpStatus.OK));
    when(actionRepository.resolveAction(any(), anyInt(), any())).thenReturn(true);

    // Prepare the expected request to be sent to CMS, with a lowercase UUID
    CmsConsentAssociationRequest modifiedRequest =
        CmsConsentAssociationRequest.builder()
            .userId("userId")
            .tenantId(association.getTenantId())
            .deviceUUID("uppercase_uuid")
            .deviceSerialNumber(device.getSerialNumber())
            .build();

    executor.execute("userId", "deviceId", new Association(), 1);

    verify(httpClient, times(1)).patch(any(), any(), eq(modifiedRequest), any());
  }

  @Test
  void testCmsCallFailStatusCode() {
    // test data setup
    List<PcManufacturingCatalogDevice> devices = new ArrayList<>();
    PcManufacturingCatalogDevice device = new PcManufacturingCatalogDevice();
    device.setSerialNumber("testSerialNumber");
    devices.add(device);
    PcManufacturingCatalogResponse pcResponse = new PcManufacturingCatalogResponse();
    pcResponse.setDevices(devices);
    Association association = new Association();
    association.setId(UUID.randomUUID());
    when(httpClient.get((String) any(), any(), any()))
        .thenReturn(new ResponseEntity<>(pcResponse, HttpStatus.OK));
    when(httpClient.patch(any(), any(), any(), any())).thenThrow(new RuntimeException());

    // Run test and verify result
    assertThrows(
        ActionExecutionException.class,
        () -> executor.execute("userId", "deviceId", association, 1));
    verify(eventService, times(0)).publishExecuteNextAction(any());
  }

  @Test
  void testGetDeviceSerialNumberFail() {
    // test data setup
    List<PcManufacturingCatalogDevice> devices = new ArrayList<>();
    PcManufacturingCatalogDevice device = new PcManufacturingCatalogDevice();
    device.setSerialNumber("invalidSerialNumber");
    devices.add(device);
    PcManufacturingCatalogResponse pcResponse = new PcManufacturingCatalogResponse();
    pcResponse.setDevices(devices);
    when(httpClient.get(any(), any(), any(), any())).thenThrow(new RuntimeException());
    Association association = new Association();

    // Run test and verify result
    assertThrows(
        ActionExecutionException.class,
        () -> executor.execute("userId", "deviceId", association, 1));
    verify(eventService, times(0)).publishExecuteNextAction(any());
  }

  @Test
  void testGetDeviceSerialNumberFail1() {
    // test data setup
    PcManufacturingCatalogDevice device = new PcManufacturingCatalogDevice();
    device.setSerialNumber("invalidSerialNumber");
    when(httpClient.get(any(), any(), any(), any())).thenThrow(new RuntimeException());
    Association association = new Association();

    // Run test and verify result
    assertThrows(
        ActionExecutionException.class,
        () -> executor.execute("userId", "deviceId", association, 1));
    verify(eventService, times(0)).publishExecuteNextAction(any());
  }

  @Test
  void testGetDeviceSerialNumberFail2() {
    // test data setup
    List<PcManufacturingCatalogDevice> devices = new ArrayList<>();
    PcManufacturingCatalogResponse pcResponse = new PcManufacturingCatalogResponse();
    pcResponse.setDevices(devices);
    when(httpClient.get(any(), any(), any(), any())).thenThrow(new RuntimeException());
    Association association = new Association();

    // Run test and verify result
    assertThrows(
        ActionExecutionException.class,
        () -> executor.execute("userId", "deviceId", association, 1));
    verify(eventService, times(0)).publishExecuteNextAction(any());
  }
}
