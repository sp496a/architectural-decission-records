package com.hp.stratus.pendingassociations.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hp.stratus.pendingassociations.action.ActionExecutor;
import com.hp.stratus.pendingassociations.exceptions.ActionExecutionException;
import com.hp.stratus.pendingassociations.exceptions.ResourceResolutionException;
import com.hp.stratus.pendingassociations.model.Action;
import com.hp.stratus.pendingassociations.model.Association;
import com.hp.stratus.pendingassociations.model.Operation;
import com.hp.stratus.pendingassociations.model.Resource;
import com.hp.stratus.pendingassociations.model.ResourceId;
import com.hp.stratus.pendingassociations.model.ResourceIdType;
import com.hp.stratus.pendingassociations.model.ResourceType;
import com.hp.stratus.pendingassociations.model.State;
import com.hp.stratus.pendingassociations.repository.AssociationRepository;
import com.hp.stratus.pendingassociations.service.impl.ActionServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
public class ActionServiceImplTest {

  @Mock RedisTemplate<String, Boolean> redisTemplate;
  @Mock ValueOperations<String, Boolean> valueOperations;
  @Mock ObjectMapper mockObjectMapper;

  @Mock AssociationRepository associationRepository;
  @Mock AssociationService associationService;
  @Mock EventService eventService;
  @Mock ActionExecutor actionExecutor;

  private ActionServiceImpl actionService;
  private ActionServiceImpl actionService1;


  @BeforeEach
  void setup() {
    actionService =
        new ActionServiceImpl(
            redisTemplate,
            eventService,
            associationService,
            associationRepository,
            List.of(actionExecutor));

    actionService1 =
        new ActionServiceImpl(
            redisTemplate,
            eventService,
            associationService,
            associationRepository,
            List.of(actionExecutor));
  }

  @Test
  void beginExecution_doesNothingWhenTheExecutionLockIsAlreadySet() {
    when(redisTemplate.opsForValue()).thenReturn(valueOperations);
    when(valueOperations.setIfAbsent(any(), any())).thenReturn(false);

    actionService.beginExecution(UUID.randomUUID());

    verify(eventService, times(0)).publishExecuteNextAction(any());
  }

  @Test
  void beginExecution_deletesTheExecutionLockWhenTheAssociationIsNotFound() {
    when(redisTemplate.opsForValue()).thenReturn(valueOperations);
    when(valueOperations.setIfAbsent(any(), any())).thenReturn(true);
    when(associationRepository.findById(any())).thenReturn(null);

    actionService.beginExecution(UUID.randomUUID());

    verify(redisTemplate, times(1)).delete(anyString());
    verify(eventService, times(0)).publishExecuteNextAction(any());
  }

  @Test
  void beginExecution_deletesTheExecutionLockWhenTheAssociationIsNotPending() {
    when(redisTemplate.opsForValue()).thenReturn(valueOperations);
    when(valueOperations.setIfAbsent(any(), any())).thenReturn(true);
    Association association = new Association();
    association.setState(State.CANCELLED);
    when(associationRepository.findById(any())).thenReturn(association);

    actionService.beginExecution(UUID.randomUUID());

    verify(redisTemplate, times(1)).delete(anyString());
    verify(eventService, times(0)).publishExecuteNextAction(any());
  }

  @Test
  void beginExecution_publishesExecuteNextAction() {
    when(redisTemplate.opsForValue()).thenReturn(valueOperations);
    when(valueOperations.setIfAbsent(any(), any())).thenReturn(true);
    Association association = new Association();
    association.setState(State.PENDING);
    when(associationRepository.findById(any())).thenReturn(association);

    actionService.beginExecution(UUID.randomUUID());

    verify(eventService, times(1)).publishExecuteNextAction(any());
  }

  @Test
  void executeNextAction_deletesTheExecutionLockWhenTheAssociationIsNotFound() {
    when(associationRepository.findById(any())).thenReturn(null);

    actionService.executeNextAction(UUID.randomUUID());

    verify(redisTemplate, times(1)).delete(anyString());
    verify(associationService, times(0)).completeAssociation(any());
    verify(associationService, times(0)).cancelAssociation(any());
    verify(eventService, times(0)).publishExecuteNextAction(any());
  }

  @Test
  void executeNextAction_deletesTheExecutionLockWhenTheAssociationIsNotPending() {
    Association association = new Association();
    association.setState(State.CANCELLED);
    when(associationRepository.findById(any())).thenReturn(association);

    actionService.executeNextAction(UUID.randomUUID());

    verify(redisTemplate, times(1)).delete(anyString());
    verify(associationService, times(0)).completeAssociation(any());
    verify(associationService, times(0)).cancelAssociation(any());
    verify(eventService, times(0)).publishExecuteNextAction(any());
  }

  @Test
  void executeNextAction_completesTheAssociationWhenThereAreNoMoreActions() {
    Association association = new Association();
    association.setState(State.PENDING);
    association.setActions(new ArrayList<>());
    when(associationRepository.findById(any())).thenReturn(association);

    actionService.executeNextAction(UUID.randomUUID());

    verify(redisTemplate, times(1)).delete(anyString());
    verify(associationService, times(1)).completeAssociation(any());
    verify(associationService, times(0)).cancelAssociation(any());
    verify(eventService, times(0)).publishExecuteNextAction(any());
  }

  @Test
  void executeNextAction_cancelsTheAssociationWhenNoActionExecutorsMatch() {
    Association association = new Association();
    association.setState(State.PENDING);
    Action action = new Action();
    association.setActions(List.of(action));
    when(associationRepository.findById(any())).thenReturn(association);
    when(actionExecutor.getOperation()).thenReturn(Operation.ASSOCIATE);

    actionService.executeNextAction(UUID.randomUUID());

    verify(redisTemplate, times(1)).delete(anyString());
    verify(associationService, times(0)).completeAssociation(any());
    verify(associationService, times(1)).cancelAssociation(any());
    verify(actionExecutor, times(0)).execute(any(), any(), anyInt());
  }

  @Test
  void
      executeNextAction_cancelsTheAssociationWhenActionExecutorThrowsAnUnretryableActionException() {
    Association association = new Association();
    association.setState(State.PENDING);
    Action action = new Action();
    action.setOperation(Operation.ASSOCIATE);
    association.setActions(List.of(action));
    when(associationRepository.findById(any())).thenReturn(association);
    when(actionExecutor.getOperation()).thenReturn(Operation.ASSOCIATE);
    doThrow(new ActionExecutionException(false, "whoops"))
        .when(actionExecutor)
        .execute(any(), any(), anyInt());

    actionService.executeNextAction(UUID.randomUUID());

    verify(redisTemplate, times(1)).delete(anyString());
    verify(associationService, times(0)).completeAssociation(any());
    verify(associationService, times(1)).cancelAssociation(any());
    verify(eventService, times(0)).publishExecuteNextAction(any());
  }

  @Test
  void executeNextAction_throwsAnExceptionWhenActionExecutorThrowsARetryableException() {
    Association association = new Association();
    association.setState(State.PENDING);
    Action action = new Action();
    action.setOperation(Operation.ASSOCIATE);
    association.setActions(List.of(action));
    UUID id = UUID.randomUUID();
    association.setId(id);
    when(associationRepository.findById(any())).thenReturn(association);
    when(actionExecutor.getOperation()).thenReturn(Operation.ASSOCIATE);
    doThrow(new ActionExecutionException(true, "whoops"))
        .when(actionExecutor)
        .execute(any(), any(), anyInt());

    assertThrows(ActionExecutionException.class, () -> actionService.executeNextAction(id));

    verify(redisTemplate, times(0)).delete(anyString());
    verify(associationService, times(0)).completeAssociation(any());
    verify(associationService, times(0)).cancelAssociation(any());
    verify(eventService, times(0)).publishExecuteNextAction(any());
  }

  @Test
  void executeNextAction_cancelsTheAssociationWhenActionExecutorThrowsAnUnretryableException() {
    Association association = new Association();
    association.setState(State.PENDING);
    Action action = new Action();
    action.setOperation(Operation.ASSOCIATE);
    association.setActions(List.of(action));
    when(associationRepository.findById(any())).thenReturn(association);
    when(actionExecutor.getOperation()).thenReturn(Operation.ASSOCIATE);
    doThrow(new ResourceResolutionException("whoops"))
        .when(actionExecutor)
        .execute(any(), any(), anyInt());

    actionService.executeNextAction(UUID.randomUUID());

    verify(redisTemplate, times(1)).delete(anyString());
    verify(associationService, times(0)).completeAssociation(any());
    verify(associationService, times(1)).cancelAssociation(any());
    verify(eventService, times(0)).publishExecuteNextAction(any());
  }

  @Test
  void executeNextAction_callsMatchingExecutorWithAssociationActionAndIndex() {
    Association association = new Association();
    association.setState(State.PENDING);
    Action action = new Action();
    action.setOperation(Operation.ASSOCIATE);
    association.setActions(List.of(action));
    when(associationRepository.findById(any())).thenReturn(association);
    when(actionExecutor.getOperation()).thenReturn(Operation.ASSOCIATE);

    actionService.executeNextAction(UUID.randomUUID());

    verify(redisTemplate, times(0)).delete(anyString());
    verify(associationService, times(0)).completeAssociation(any());
    verify(associationService, times(0)).cancelAssociation(any());
    verify(actionExecutor, times(1)).execute(eq(association), eq(action), eq(0));
  }


  @Test
  void executeNextAction_cancelsTheAssociationWhenTheResourceIdFailsToResolve() {
    Association association = new Association();
    association.setState(State.PENDING);
    Action action = new Action();
    action.setResource(createResource(ResourceIdType.POINTER, "invalidPointer"));
    association.setActions(List.of(action));
    when(associationRepository.findById(any())).thenReturn(association);

    actionService.executeNextAction(UUID.randomUUID());

    verify(associationService, times(0)).completeAssociation(any());
    verify(eventService, times(0)).publishExecuteNextAction(any());
  }

  @Test
  void executeNextAction_jsonProcessingError() throws JsonProcessingException {

    Association association = new Association();
    association.setState(State.PENDING);
    Action action = new Action();
    action.setResource(createResource(ResourceIdType.POINTER, "pointer"));
    association.setActions(List.of(action));
    when(associationRepository.findById(any())).thenReturn(association);
    actionService1.executeNextAction(UUID.randomUUID());

    verify(associationService, times(0)).completeAssociation(any());
    verify(eventService, times(0)).publishExecuteNextAction(any());
  }

  @Test
  void executeNextAction_callsMatchingExecutorWithPointerResource() {
    Association association = new Association();
    association.setId(UUID.randomUUID());
    association.setState(State.PENDING);
    Action action = new Action();
    action.setResource(createResource(ResourceIdType.POINTER, "id"));
    action.setOperation(Operation.ASSOCIATE);
    association.setActions(List.of(action));
    when(associationRepository.findById(any())).thenReturn(association);
    when(actionExecutor.getOperation()).thenReturn(Operation.ASSOCIATE);

    actionService.executeNextAction(UUID.randomUUID());

    verify(redisTemplate, times(0)).delete(anyString());
    verify(associationService, times(0)).completeAssociation(any());
    verify(associationService, times(0)).cancelAssociation(any());
    verify(actionExecutor, times(1))
        .execute(eq(association), eq(action), eq(0));
  }

  @Test
  void executeNextAction_callsMatchingExecutorWithStringResource() {
    Association association = new Association();
    association.setState(State.PENDING);
    Action action = new Action();
    action.setResource(createResource(ResourceIdType.STRING, "testId"));
    action.setOperation(Operation.ASSOCIATE);
    association.setActions(List.of(action));
    when(associationRepository.findById(any())).thenReturn(association);
    when(actionExecutor.getOperation()).thenReturn(Operation.ASSOCIATE);
    actionService.executeNextAction(UUID.randomUUID());

    verify(redisTemplate, times(0)).delete(anyString());
    verify(associationService, times(0)).completeAssociation(any());
    verify(associationService, times(0)).cancelAssociation(any());
    verify(actionExecutor, times(1)).execute(eq(association), eq(action), eq(0));
  }

  private Resource createResource(ResourceIdType type, String value) {
    ResourceId resourceId = new ResourceId();
    resourceId.setType(type);
    resourceId.setValue(value);
    Resource resource = new Resource();
    resource.setType(ResourceType.PRINTER);
    resource.setId(resourceId);
    return resource;
  }

}
