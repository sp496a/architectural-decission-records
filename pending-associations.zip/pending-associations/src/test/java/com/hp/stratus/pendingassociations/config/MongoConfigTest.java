package com.hp.stratus.pendingassociations.config;

import com.mongodb.AuthenticationMechanism;
import com.mongodb.AwsCredential;
import com.mongodb.MongoClientSettings;
import com.mongodb.MongoCredential;
import com.mongodb.client.MongoClient;
import org.apache.commons.lang3.NotImplementedException;
import org.bson.UuidRepresentation;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import software.amazon.awssdk.auth.credentials.AwsSessionCredentials;

import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
@Tag("UnitTest")
public class MongoConfigTest {

  @Mock Supplier<AwsSessionCredentials> sessionCredentialsSupplier;

  private MongoConfig mongoConfig;

  @Test
  void getDatabaseName_returnsConfiguredName() {
    mongoConfig =
        new MongoConfig(
            sessionCredentialsSupplier, "mongodb://localhost", "pending-associations", null, null);
    assertEquals("pending-associations", mongoConfig.getDatabaseName());
  }

  @Test
  void buildMongoSettings_setsBasicSettings() {
    mongoConfig =
        new MongoConfig(
            sessionCredentialsSupplier, "mongodb://localhost", "pending-associations", null, null);

    MongoClientSettings settings = mongoConfig.buildMongoSettings();

    // Validate basic settings
    assertNotNull(settings);
    assertNotNull(settings.getClusterSettings());
    assertNotNull(settings.getClusterSettings().getHosts());
    assertEquals(1, settings.getClusterSettings().getHosts().size());
    assertEquals(UuidRepresentation.JAVA_LEGACY, settings.getUuidRepresentation());

    // Validate the replica set isn't set
    assertNull(settings.getClusterSettings().getRequiredReplicaSetName());

    // Validate the credential mechanism isn't set
    assertNull(settings.getCredential());
  }

  @Test
  void buildMongoSettings_appliesReplicaSetConfigurationWhenSupplied() {
    mongoConfig =
        new MongoConfig(
            sessionCredentialsSupplier,
            "mongodb://localhost",
            "pending-associations",
            "test",
            null);

    MongoClientSettings settings = mongoConfig.buildMongoSettings();

    assertNotNull(settings);
    assertNotNull(settings.getClusterSettings());
    assertEquals("test", settings.getClusterSettings().getRequiredReplicaSetName());
  }

  @Test
  void buildMongoSettings_appliesAwsAuthWhenMechanismIsConfigured() {
    mongoConfig =
        new MongoConfig(
            sessionCredentialsSupplier,
            "mongodb://localhost",
            "pending-associations",
            null,
            AuthenticationMechanism.MONGODB_AWS.getMechanismName());
    Mockito.when(sessionCredentialsSupplier.get())
        .thenReturn(AwsSessionCredentials.create("key", "secret", "token"));

    MongoClientSettings settings = mongoConfig.buildMongoSettings();

    // Validate the mechanism
    assertNotNull(settings);
    assertNotNull(settings.getCredential());
    assertNotNull(settings.getCredential().getMechanism());
    assertEquals(
        AuthenticationMechanism.MONGODB_AWS.getMechanismName(),
        settings.getCredential().getMechanism());

    // Validate the supplier
    Supplier<AwsCredential> supplier =
        settings
            .getCredential()
            .getMechanismProperty(MongoCredential.AWS_CREDENTIAL_PROVIDER_KEY, null);
    assertNotNull(supplier);
    assertEquals("key", supplier.get().getAccessKeyId());
    assertEquals("secret", supplier.get().getSecretAccessKey());
    assertEquals("token", supplier.get().getSessionToken());
  }

  @Test
  void buildMongoSettings_throwsIllegalArgumentWhenAnInvalidMechanismIsConfigured() {
    mongoConfig =
        new MongoConfig(
            sessionCredentialsSupplier,
            "mongodb://localhost",
            "pending-associations",
            null,
            "not a real mechanism");

    assertThrows(IllegalArgumentException.class, () -> mongoConfig.buildMongoSettings());
  }

  @Test
  void buildMongoSettings_throwsNotImplementedWhenAnUnimplementedMechanismIsConfigured() {
    mongoConfig =
        new MongoConfig(
            sessionCredentialsSupplier,
            "mongodb://localhost",
            "pending-associations",
            null,
            AuthenticationMechanism.GSSAPI.getMechanismName());

    assertThrows(NotImplementedException.class, () -> mongoConfig.buildMongoSettings());
  }

  @Test
  void mongoClientTest() {
    mongoConfig =
        new MongoConfig(
            sessionCredentialsSupplier, "mongodb://localhost", "pending-associations", null, null);

    MongoClient settings = mongoConfig.mongoClient();

    // Validate basic settings
    assertNotNull(settings.getDatabase("pending-associations"));
    assertNotNull(settings.listDatabaseNames());
    assertNotNull(mongoConfig.getDatabaseName());
  }

}
