module.exports = {

  // Adds an index on metadata
  async up(db, client) {
    await db.collection('association').createIndex({ "metadata.$**": 1 });
  },

  // Removes the index on metadata
  async down(db, client) {
    await db.collection('association').dropIndex("metadata.$**");
  }
};
