module.exports = {

    // Add indexes on each field below
    async up(db, client) {
        // Adds an index on state
        await db.collection('association').createIndex({
            "state": 1
        });
        // Adds an inddex on criteria.state
        await db.collection('association').createIndex({
            "criteria.state": 1
        });
        // Adds an index on criteria.type
        await db.collection('association').createIndex({
            "criteria.type": 1
        });
        // Adds an index on criteria.details.resource
        await db.collection('association').createIndex({
            "criteria.details.resource": 1
        });
        // Adds an index on criteria.details.type
        await db.collection('association').createIndex({
            "criteria.details.type": 1
        });
        // Adds an index on criteria.condition.value1.type
        await db.collection('association').createIndex({
            "criteria.condition.value1.type": 1
        });
        // Adds an index on criteria.condition.value1.value
        await db.collection('association').createIndex({
            "criteria.condition.value1.value": 1
        });
        // Adds an index on criteria.condition.value2.type
        await db.collection('association').createIndex({
            "criteria.condition.value2.type": 1
        });
        // Adds an index on criteria.condition.value2.value
        await db.collection('association').createIndex({
            "criteria.condition.value2.value": 1
        });
        // Adds an index on criteria.condition.comparator
        await db.collection('association').createIndex({
            "criteria.condition.comparator": 1
        });
    },

    // Removes the index on state and criteria fields
    async down(db, client) {
        await db.collection('association').dropIndex(
            "state"
        );
        await db.collection('association').dropIndex(
            "criteria.state"
        );
        await db.collection('association').dropIndex(
            "criteria.type"
        );
        await db.collection('association').dropIndex(
            "criteria.details.resource"
        );
        await db.collection('association').dropIndex(
            "criteria.details.type"
        );
        await db.collection('association').dropIndex(
            "criteria.condition.value1.type"
        );
        await db.collection('association').dropIndex(
            "criteria.condition.value1.value"
        );
        await db.collection('association').dropIndex(
            "criteria.condition.value2.type"
        );
        await db.collection('association').dropIndex(
            "criteria.condition.value2.value"
        );
        await db.collection('association').dropIndex(
            "criteria.condition.comparator"
        );
    }
};
