# pending-associations 

[![Build Status](https://dev.azure.com/hpcodeway/Stratus/_apis/build/status/stratus.pending-associations?repoName=stratus%2Fpending-associations&branchName=master)](https://dev.azure.com/hpcodeway/Stratus/_build/latest?definitionId=12484&repoName=stratus%2Fpending-associations&branchName=master) <a href="https://sq.corp.hpicloud.net/dashboard?id=Codeway_pending-associations"><img src="https://docs.sonarqube.org/latest/images/SonarQubeIcon.svg" width="80"></a>

# Useful links
* [Tropos docs & user guides](https://pages.github.azc.ext.hp.com/Tropos/docs/)

For details about the API structure, please see the [API specification](swagger.yaml). A JSON representation can be retrieved from a running container using the `/spec` route.

## Pre-requisites

* [Docker](https://docs.docker.com/desktop/windows/install/)
* [Maven](https://maven.apache.org/install.html)
* [Nexus](https://nexus-int.corp.hpicloud.net/):
  * Make sure you're part of the [stratus-dev group](https://directoryworks.hpicorp.net/protected/groups/view/normal/?dn=cn=stratus-dev,ou=Groups,o=hp.com).
  * Set up Nexus authentication for Maven as described [here](https://rndwiki.inc.hpicorp.net/confluence/pages/viewpage.action?spaceKey=softwareathp&title=Set+up+a+Maven+development+environment).
  * (Optional) To view Sonarqube results, add yourself to [Stratus_SQGroup](https://directoryworks.hpicorp.net/protected/groups/view/normal/?dn=cn%3DStratus_SQGroup%2Cou%3DGroups%2Co%3Dhp.com).

#Building
You can build the service with Docker or directly with Maven:

With Docker: docker build -t pending-associations .
With Maven: mvn -Dmaven.test.skip=true install

#Testing
##Unit tests
Unit tests can be run directly with Maven: mvn test.

#Running
The service can be run locally with Docker:


1. Set values for the `PENDING_ASSOCIATIONS_CLIENT_ID`, `PENDING_ASSOCIATIONS_CLIENT_SECRET` and `PENDING_ASSOCIATIONS_LAUNCH_DARKLY_KEY` environment variables
2. Log in with authly
3. Run `docker compose up`.
4. Hit http://localhost:8080/ping in your browser to validate the service is up.
5. Make other API calls to http://localhost:8080 as required.

# Useful commands
1. Start everything in the background: `docker compose up -d`
2. Rebuild and restart the service container, without restarting everything else: `mvn -Dmaven.test.skip=true install && docker compose up --build pending-associations`

# local:
* [health check url](http://localhost:8080/ping "health check url")
* [spec url](http://localhost:8080/pending-associations/spec "spec url")

# dev:
* [health check url](https://stratus-dev.tropos-rnd.com/pending-associations/health "health check url")
* [spec url](https://stratus-dev.tropos-rnd.com/pending-associations/spec "spec url")
